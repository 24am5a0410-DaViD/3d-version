import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { CURRICULUM } from '../lessons/curriculum';
import { X, CheckCircle2, AlertCircle, Award, ArrowRight } from 'lucide-react';

export const QuizModal: React.FC = () => {
  const { currentLessonId, quizModalOpen, setQuizModalOpen, setLesson, setScene } = useAppStore();
  const lesson = CURRICULUM[currentLessonId] || CURRICULUM[0];
  const questions = lesson.quiz;

  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState(false);

  if (!quizModalOpen) return null;

  const handleSelectOption = (qId: string, optIdx: number) => {
    if (submitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [qId]: optIdx }));
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) correct++;
    });
    return correct;
  };

  const handleNextModule = () => {
    setQuizModalOpen(false);
    setSelectedAnswers({});
    setSubmitted(false);
    if (currentLessonId < CURRICULUM.length - 1) {
      const nextId = currentLessonId + 1;
      setLesson(nextId);
      setScene(CURRICULUM[nextId].sceneId);
    }
  };

  const score = calculateScore();
  const allAnswered = questions.every((q) => selectedAnswers[q.id] !== undefined);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl max-w-xl w-full max-h-[85vh] flex flex-col overflow-hidden text-slate-100">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 bg-slate-800/80 border-b border-slate-700">
          <div className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-purple-400" />
            <h2 className="font-bold text-base tracking-wide">
              Module {lesson.id} Knowledge Check
            </h2>
          </div>
          <button
            onClick={() => setQuizModalOpen(false)}
            className="p-1 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Questions */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {questions.map((q, qIdx) => {
            const userChoice = selectedAnswers[q.id];
            const isCorrect = userChoice === q.correctIndex;

            return (
              <div key={q.id} className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="font-semibold text-sm text-slate-200">
                  {qIdx + 1}. {q.question}
                </div>

                <div className="space-y-2">
                  {q.options.map((opt, optIdx) => {
                    const isSelected = userChoice === optIdx;
                    let btnStyle = 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700';

                    if (submitted) {
                      if (optIdx === q.correctIndex) {
                        btnStyle = 'border-emerald-500 bg-emerald-950/60 text-emerald-200';
                      } else if (isSelected && !isCorrect) {
                        btnStyle = 'border-rose-500 bg-rose-950/60 text-rose-200';
                      }
                    } else if (isSelected) {
                      btnStyle = 'border-purple-500 bg-purple-950/60 text-purple-200';
                    }

                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleSelectOption(q.id, optIdx)}
                        disabled={submitted}
                        className={`w-full text-left p-3 rounded-xl border text-xs leading-normal flex items-start space-x-2 transition ${btnStyle}`}
                      >
                        <span className="font-mono font-bold text-slate-500 min-w-[20px]">
                          {String.fromCharCode(65 + optIdx)}.
                        </span>
                        <span className="flex-1">{opt}</span>
                      </button>
                    );
                  })}
                </div>

                {submitted && (
                  <div className={`p-3 rounded-lg text-xs leading-relaxed border ${
                    isCorrect ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300' : 'bg-rose-950/40 border-rose-800/60 text-rose-300'
                  }`}>
                    <div className="font-bold flex items-center space-x-1 mb-1">
                      {isCorrect ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          <span>Correct!</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-4 h-4 text-rose-400" />
                          <span>Explanation:</span>
                        </>
                      )}
                    </div>
                    <div>{q.explanation}</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-800/80 border-t border-slate-700 flex items-center justify-between">
          <div className="text-xs font-semibold text-slate-400">
            {submitted ? (
              <span className="text-purple-300 font-bold">
                Score: {score} / {questions.length} ({Math.round((score / questions.length) * 100)}%)
              </span>
            ) : (
              <span>Answer all questions to submit</span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            {!submitted ? (
              <button
                onClick={() => setSubmitted(true)}
                disabled={!allAnswered}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:hover:bg-purple-600 text-white text-xs font-bold shadow-md transition"
              >
                Submit Answers
              </button>
            ) : (
              <button
                onClick={handleNextModule}
                className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md transition"
              >
                <span>Continue Next Module</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
