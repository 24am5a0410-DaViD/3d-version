/**
 * bb84Engine.ts — Vectorized and deterministic BB84 protocol simulation engine.
 * Mirrors bb84_engine.py from the WISER Education Challenge.
 */

export const RECTILINEAR = 0; // + basis: 0 -> |H> at 0°, 1 -> |V> at 90°
export const DIAGONAL = 1;    // × basis: 0 -> |D> at 45°, 1 -> |A> at 135°

export const BASIS_SYMBOL: Record<number, string> = {
  [RECTILINEAR]: '+',
  [DIAGONAL]: '×',
};

export const BASIS_NAME: Record<number, string> = {
  [RECTILINEAR]: 'rectilinear',
  [DIAGONAL]: 'diagonal',
};

export const STATE_TABLE: Record<string, { ket: string; angle: number }> = {
  '0_0': { ket: '|H⟩', angle: 0 },
  '0_1': { ket: '|V⟩', angle: 90 },
  '1_0': { ket: '|D⟩', angle: 45 },
  '1_1': { ket: '|A⟩', angle: 135 },
};

export const SECURITY_THRESHOLD = 0.11; // Shor-Preskill bound (11%)

export interface RunParams {
  numPhotons: number;
  evePresent: boolean;
  eveProbability: number;
  noiseLevel: number;
  sampleFraction: number;
  seed?: number;
}

export interface PhotonRecord {
  index: number;
  aliceBit: number;
  aliceBasis: number;
  aliceState: string;
  aliceAngle: number;
  eveIntercepted: boolean;
  eveBasis?: number;
  eveBit?: number;
  transitBasis: number;
  transitBit: number;
  bobBasis: number;
  bobBit: number;
  noiseFlipped: boolean;
  basisMatch: boolean;
  sifted: boolean;
  revealed: boolean;
  inFinalKey: boolean;
  error: boolean;
}

export interface RunResult {
  params: RunParams;
  photons: PhotonRecord[];
  siftedLength: number;
  revealedLength: number;
  finalKeyLength: number;
  mismatches: number;
  sampleSize: number;
  qber: number;
  isSecure: boolean;
  verdict: string;
  aliceFinalKey: string;
  bobFinalKey: string;
}

class SimpleRNG {
  private m = 0x80000000;
  private a = 1103515245;
  private c = 12345;
  private state: number;

  constructor(seed?: number) {
    this.state = seed !== undefined ? seed : Math.floor(Math.random() * (this.m - 1));
  }

  next(): number {
    this.state = (this.a * this.state + this.c) % this.m;
    return this.state / (this.m - 1);
  }

  nextBit(): number {
    return this.next() < 0.5 ? 0 : 1;
  }
}

export class BB84Simulator {
  private params: RunParams;
  private rng: SimpleRNG;

  constructor(params: RunParams) {
    this.params = params;
    this.rng = new SimpleRNG(params.seed);
  }

  public run(): RunResult {
    const N = this.params.numPhotons;
    const records: PhotonRecord[] = [];

    // 1. Alice generates bits and random bases
    const aliceBits: number[] = [];
    const aliceBases: number[] = [];
    for (let i = 0; i < N; i++) {
      aliceBits.push(this.rng.nextBit());
      aliceBases.push(this.rng.nextBit());
    }

    // 2. Eve intercepts with probability p (intercept-resend)
    const eveIntercepted: boolean[] = [];
    const eveBases: (number | undefined)[] = [];
    const eveBits: (number | undefined)[] = [];
    const transitBits: number[] = [];
    const transitBases: number[] = [];

    for (let i = 0; i < N; i++) {
      const intercepted = this.params.evePresent && this.rng.next() < this.params.eveProbability;
      eveIntercepted.push(intercepted);

      if (intercepted) {
        const eBasis = this.rng.nextBit();
        eveBases.push(eBasis);
        let eBit: number;
        if (eBasis === aliceBases[i]) {
          eBit = aliceBits[i];
        } else {
          eBit = this.rng.nextBit(); // 50% random collapse
        }
        eveBits.push(eBit);
        transitBases.push(eBasis);
        transitBits.push(eBit);
      } else {
        eveBases.push(undefined);
        eveBits.push(undefined);
        transitBases.push(aliceBases[i]);
        transitBits.push(aliceBits[i]);
      }
    }

    // 3. Bob measures in independent random basis
    const bobBases: number[] = [];
    const bobBits: number[] = [];
    const noiseFlipped: boolean[] = [];

    for (let i = 0; i < N; i++) {
      const bBasis = this.rng.nextBit();
      bobBases.push(bBasis);

      let bBit: number;
      if (bBasis === transitBases[i]) {
        bBit = transitBits[i];
      } else {
        bBit = this.rng.nextBit(); // 50% random collapse
      }

      // Detector noise bit-flip
      const flipped = this.rng.next() < this.params.noiseLevel;
      noiseFlipped.push(flipped);
      if (flipped) {
        bBit = 1 - bBit;
      }
      bobBits.push(bBit);
    }

    // 4. Sifting: Alice and Bob compare bases over classical channel
    const siftedIndices: number[] = [];
    for (let i = 0; i < N; i++) {
      if (aliceBases[i] === bobBases[i]) {
        siftedIndices.push(i);
      }
    }

    // 5. Error estimation: Reveal sampleFraction of sifted bits
    const siftedCount = siftedIndices.length;
    const sampleSize = Math.max(1, Math.round(siftedCount * this.params.sampleFraction));

    // Shuffle sifted indices to pick random sample
    const shuffledSifted = [...siftedIndices];
    for (let i = shuffledSifted.length - 1; i > 0; i--) {
      const j = Math.floor(this.rng.next() * (i + 1));
      [shuffledSifted[i], shuffledSifted[j]] = [shuffledSifted[j], shuffledSifted[i]];
    }

    const sampleSet = new Set(shuffledSifted.slice(0, sampleSize));
    const finalKeySet = new Set(shuffledSifted.slice(sampleSize));

    let mismatches = 0;
    sampleSet.forEach((idx) => {
      if (aliceBits[idx] !== bobBits[idx]) {
        mismatches++;
      }
    });

    const qber = sampleSize > 0 ? mismatches / sampleSize : 0;
    const isSecure = qber <= SECURITY_THRESHOLD;
    const verdict = isSecure
      ? `Channel secure. QBER = ${(qber * 100).toFixed(2)}% ≤ 11.00% (Shor–Preskill bound).`
      : `Eavesdropping detected! QBER = ${(qber * 100).toFixed(2)}% > 11.00%. Key aborted.`;

    let aliceKey = '';
    let bobKey = '';
    shuffledSifted.slice(sampleSize).forEach((idx) => {
      aliceKey += aliceBits[idx];
      bobKey += bobBits[idx];
    });

    // Build per-photon records
    for (let i = 0; i < N; i++) {
      const stateInfo = STATE_TABLE[`${aliceBases[i]}_${aliceBits[i]}`];
      const match = aliceBases[i] === bobBases[i];
      const isSample = sampleSet.has(i);
      const isKey = finalKeySet.has(i);
      const isError = match && aliceBits[i] !== bobBits[i];

      records.push({
        index: i + 1,
        aliceBit: aliceBits[i],
        aliceBasis: aliceBases[i],
        aliceState: stateInfo.ket,
        aliceAngle: stateInfo.angle,
        eveIntercepted: eveIntercepted[i],
        eveBasis: eveBases[i],
        eveBit: eveBits[i],
        transitBasis: transitBases[i],
        transitBit: transitBits[i],
        bobBasis: bobBases[i],
        bobBit: bobBits[i],
        noiseFlipped: noiseFlipped[i],
        basisMatch: match,
        sifted: match,
        revealed: isSample,
        inFinalKey: isKey,
        error: isError,
      });
    }

    return {
      params: this.params,
      photons: records,
      siftedLength: siftedCount,
      revealedLength: sampleSize,
      finalKeyLength: finalKeySet.size,
      mismatches,
      sampleSize,
      qber,
      isSecure,
      verdict,
      aliceFinalKey: aliceKey,
      bobFinalKey: bobKey,
    };
  }
}

/**
 * Sweeps Eve interception probability p from 0 to 1 and compares with QBER = p / 4.
 */
export function runAttackSweep(numPhotons = 300, runsPerStep = 4): { p: number; simQber: number; theoryQber: number }[] {
  const steps = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
  const results: { p: number; simQber: number; theoryQber: number }[] = [];

  for (const p of steps) {
    let sumQber = 0;
    for (let r = 0; r < runsPerStep; r++) {
      const sim = new BB84Simulator({
        numPhotons,
        evePresent: p > 0,
        eveProbability: p,
        noiseLevel: 0.0,
        sampleFraction: 0.5,
      });
      sumQber += sim.run().qber;
    }
    const avgQber = sumQber / runsPerStep;
    results.push({
      p: Math.round(p * 100),
      simQber: +(avgQber * 100).toFixed(2),
      theoryQber: +(p * 25.0).toFixed(2), // p / 4
    });
  }

  return results;
}
