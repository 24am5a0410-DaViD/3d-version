/**
 * Complex Number Implementation for Quantum Linear Algebra
 */
export class Complex {
  readonly r: number; // Real component
  readonly i: number; // Imaginary component

  constructor(r: number = 0, i: number = 0) {
    this.r = r;
    this.i = i;
  }

  static readonly ZERO = new Complex(0, 0);
  static readonly ONE = new Complex(1, 0);
  static readonly I = new Complex(0, 1);

  static fromPolar(r: number, thetaRad: number): Complex {
    return new Complex(r * Math.cos(thetaRad), r * Math.sin(thetaRad));
  }

  add(other: Complex): Complex {
    return new Complex(this.r + other.r, this.i + other.i);
  }

  sub(other: Complex): Complex {
    return new Complex(this.r - other.r, this.i - other.i);
  }

  mul(other: Complex): Complex {
    return new Complex(
      this.r * other.r - this.i * other.i,
      this.r * other.i + this.i * other.r
    );
  }

  scale(factor: number): Complex {
    return new Complex(this.r * factor, this.i * factor);
  }

  div(other: Complex): Complex {
    const denom = other.r * other.r + other.i * other.i;
    if (denom === 0) throw new Error('Complex division by zero');
    return new Complex(
      (this.r * other.r + this.i * other.i) / denom,
      (this.i * other.r - this.r * other.i) / denom
    );
  }

  conj(): Complex {
    return new Complex(this.r, -this.i);
  }

  absSq(): number {
    return this.r * this.r + this.i * this.i;
  }

  abs(): number {
    return Math.hypot(this.r, this.i);
  }

  arg(): number {
    return Math.atan2(this.i, this.r);
  }

  equals(other: Complex, tolerance: number = 1e-7): boolean {
    return Math.abs(this.r - other.r) <= tolerance && Math.abs(this.i - other.i) <= tolerance;
  }

  toString(decimals: number = 3): string {
    const rStr = this.r.toFixed(decimals);
    const iAbs = Math.abs(this.i).toFixed(decimals);
    if (Math.abs(this.i) < 1e-9) return `${rStr}`;
    if (Math.abs(this.r) < 1e-9) return `${this.i < 0 ? '-' : ''}${iAbs}i`;
    return `${rStr} ${this.i >= 0 ? '+' : '-'} ${iAbs}i`;
  }
}
