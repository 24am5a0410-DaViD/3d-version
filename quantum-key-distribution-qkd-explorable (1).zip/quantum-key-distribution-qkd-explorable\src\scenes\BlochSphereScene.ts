import * as THREE from 'three';
import { Vector2 } from '../core/math/vector2';

export class BlochSphereScene {
  readonly scene: THREE.Group;
  private stateArrow: THREE.Group;

  constructor() {
    this.scene = new THREE.Group();
    this.stateArrow = new THREE.Group();
    this.buildBlochSphere();
  }

  private buildBlochSphere(): void {
    const radius = 2.5;

    // Translucent sphere surface
    const sphereGeom = new THREE.SphereGeometry(radius, 32, 32);
    const sphereMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e293b,
      transparent: true,
      opacity: 0.25,
      roughness: 0.2,
      transmission: 0.8,
      wireframe: false,
    });
    const sphere = new THREE.Mesh(sphereGeom, sphereMat);
    this.scene.add(sphere);

    // Equator (XY plane)
    const eqGeom = new THREE.BufferGeometry();
    const eqPts: THREE.Vector3[] = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      eqPts.push(new THREE.Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius));
    }
    eqGeom.setFromPoints(eqPts);
    this.scene.add(new THREE.Line(eqGeom, new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 2 })));

    // Coordinate Axes (X, Y, Z)
    const axisMat = new THREE.LineBasicMaterial({ color: 0x64748b });
    const createAxis = (from: THREE.Vector3, to: THREE.Vector3) => {
      const geom = new THREE.BufferGeometry().setFromPoints([from, to]);
      return new THREE.Line(geom, axisMat);
    };
    this.scene.add(createAxis(new THREE.Vector3(-3.2, 0, 0), new THREE.Vector3(3.2, 0, 0))); // X
    this.scene.add(createAxis(new THREE.Vector3(0, -3.2, 0), new THREE.Vector3(0, 3.2, 0))); // Z
    this.scene.add(createAxis(new THREE.Vector3(0, 0, -3.2), new THREE.Vector3(0, 0, 3.2))); // Y

    // Basis State Marker Spheres
    const createMarker = (pos: THREE.Vector3, color: number, label: string) => {
      const g = new THREE.Group();
      const dot = new THREE.Mesh(
        new THREE.SphereGeometry(0.12, 16, 16),
        new THREE.MeshBasicMaterial({ color })
      );
      g.add(dot);

      // Text billboard canvas
      const canvas = document.createElement('canvas');
      canvas.width = 128;
      canvas.height = 64;
      const ctx = canvas.getContext('2d')!;
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 36px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, 64, 32);

      const tex = new THREE.CanvasTexture(canvas);
      const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex }));
      sprite.scale.set(0.9, 0.45, 1);
      sprite.position.copy(pos.clone().normalize().multiplyScalar(radius + 0.4));
      g.add(sprite);

      g.position.copy(pos);
      return g;
    };

    // Z-basis (Rectilinear: |0> / |1>, |H> / |V>)
    this.scene.add(createMarker(new THREE.Vector3(0, radius, 0), 0x38bdf8, '|0⟩ (|H⟩)'));
    this.scene.add(createMarker(new THREE.Vector3(0, -radius, 0), 0x38bdf8, '|1⟩ (|V⟩)'));

    // X-basis (Diagonal: |+> / |->, |D> / |A>)
    this.scene.add(createMarker(new THREE.Vector3(radius, 0, 0), 0xf59e0b, '|+⟩ (|D⟩)'));
    this.scene.add(createMarker(new THREE.Vector3(-radius, 0, 0), 0xf59e0b, '|-⟩ (|A⟩)'));

    // State Vector Arrow (glowing line with arrowhead cone)
    const shaftGeom = new THREE.CylinderGeometry(0.04, 0.04, radius, 12);
    shaftGeom.translate(0, radius / 2, 0);
    const shaftMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const shaft = new THREE.Mesh(shaftGeom, shaftMat);
    this.stateArrow.add(shaft);

    const tipGeom = new THREE.ConeGeometry(0.15, 0.4, 16);
    tipGeom.translate(0, radius, 0);
    const tip = new THREE.Mesh(tipGeom, new THREE.MeshBasicMaterial({ color: 0xffffff }));
    this.stateArrow.add(tip);

    this.scene.add(this.stateArrow);
    this.setStateVector(Vector2.H);
  }

  public setStateVector(vec: Vector2): void {
    const { x, y, z } = vec.toBlochCoordinates();
    
    // In Three.js: Y is UP (Bloch Z axis), X is Bloch X axis, Z is Bloch Y axis
    const targetDir = new THREE.Vector3(x, z, y).normalize();
    
    // Align stateArrow from default (0, 1, 0) to targetDir
    const defaultUp = new THREE.Vector3(0, 1, 0);
    const quaternion = new THREE.Quaternion().setFromUnitVectors(defaultUp, targetDir);
    this.stateArrow.setRotationFromQuaternion(quaternion);
  }

  public update(timeSeconds: number): void {
    // Subtle breathing or rotation
    this.scene.rotation.y = Math.sin(timeSeconds * 0.2) * 0.1;
  }
}
