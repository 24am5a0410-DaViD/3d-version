export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LessonModule {
  id: number;
  title: string;
  subtitle: string;
  sceneId: 'bb84' | 'satellite' | 'bloch';
  satelliteView?: 'orbit' | 'payload' | 'fiber' | 'ground';
  learningObjectives: string[];
  eli12Intuition: string;
  formalMathTitle: string;
  formalMathLatex: string;
  formalMathDerivation: string[];
  interactiveGoal: string;
  quiz: QuizQuestion[];
  references: { title: string; citation: string; year: number }[];
}

export const CURRICULUM: LessonModule[] = [
  {
    id: 0,
    title: 'Why Quantum Key Distribution?',
    subtitle: 'Computational vs Information-Theoretic Security & The Quantum Threat',
    sceneId: 'bb84',
    learningObjectives: [
      "Understand why modern public-key cryptography (RSA, ECC) is vulnerable to Shor's algorithm.",
      'Distinguish computational security from information-theoretic security (Vernam One-Time Pad).',
      'Discover how quantum mechanics enables provably eavesdropper-detectable key distribution.',
    ],
    eli12Intuition:
      "Today's internet locks secrets behind giant mathematical riddles (factoring huge numbers). Conventional supercomputers cannot solve them in millions of years, but future quantum computers run an algorithm by Peter Shor that solves them in minutes! Quantum Key Distribution (QKD) does not use math puzzles to protect secrets: it uses the laws of physics. If an eavesdropper touches a quantum secret in transit, nature itself sounds the alarm!",
    formalMathTitle: "Shor's Threat & The Shannon One-Time Pad Bound",
    formalMathLatex:
      'H(M|C) = H(M) \\iff H(K) \\ge H(M) \\quad \\text{(Shannon Perfect Secrecy)}',
    formalMathDerivation: [
      'Classical RSA security relies on the hardness of factoring N = p · q (sub-exponential classical time).',
      "Shor's quantum algorithm finds the period r of f(x) = a^x mod N in O((log N)^3) polynomial time on a quantum computer.",
      'The only mathematically unbreakable cipher is the One-Time Pad (Vernam 1926), requiring a shared secret key K as long as the message M: H(M|C) = H(M).',
      'QKD solves the fundamental challenge of the One-Time Pad: how to distribute truly random secret keys over insecure distances without interception.',
    ],
    interactiveGoal: 'Click on the optical bench components to explore Alice and Bob’s tabletop setup.',
    quiz: [
      {
        id: 'q0_1',
        question: "Why does Shor's algorithm threaten RSA and Elliptic Curve Cryptography?",
        options: [
          'It guesses passwords by brute-forcing all combinations.',
          'It computes prime factorization and discrete logarithms in polynomial time using quantum Fourier transforms.',
          'It intercepts fiber optic cables without physical contact.',
          'It breaks AES symmetric encryption instantaneously.',
        ],
        correctIndex: 1,
        explanation:
          "Shor's algorithm (1994) solves order-finding in polynomial time O((log N)^3), rendering factoring-based (RSA) and discrete-log-based (ECC) public key cryptography vulnerable.",
      },
      {
        id: 'q0_2',
        question: 'What is required for the One-Time Pad (Vernam cipher) to guarantee perfect secrecy?',
        options: [
          'A key that is at least as long as the plaintext, truly random, and used only once.',
          'A 256-bit key renewed every 24 hours.',
          'An encrypted public-key handshake over TLS.',
          'A secret quantum algorithm kept hidden from the adversary.',
        ],
        correctIndex: 0,
        explanation:
          'Claude Shannon proved in 1949 that perfect secrecy H(M|C) = H(M) requires the key entropy H(K) >= H(M) and that keys must never be reused.',
      },
    ],
    references: [
      { title: "Algorithms for quantum computation: discrete logarithms and factoring", citation: "P. W. Shor, IEEE FOCS", year: 1994 },
      { title: "Communication Theory of Secrecy Systems", citation: "C. E. Shannon, Bell System Technical Journal", year: 1949 },
    ],
  },
  {
    id: 1,
    title: 'Light as an Information Carrier',
    subtitle: 'Single Photons, Polarization, and Physical States',
    sceneId: 'bb84',
    learningObjectives: [
      'Describe optical polarization as the oscillation direction of the electric field vector.',
      'Identify the four canonical BB84 states: Horizontal (H), Vertical (V), Diagonal (D), Anti-diagonal (A).',
      'Understand why single-photon pulses prevent eavesdroppers from siphoning copies.',
    ],
    eli12Intuition:
      "Think of light as a jump rope vibrating up and down (Vertical) or side to side (Horizontal). You can also wiggle the rope at a 45-degree angle (Diagonal or Anti-diagonal). In QKD, Alice encodes bits into individual particles of light—photons—using these exact vibration directions!",
    formalMathTitle: 'Jones Vector Representation of Polarization States',
    formalMathLatex:
      '|H\\rangle = \\begin{pmatrix}1\\\\0\\end{pmatrix}, \\quad |V\\rangle = \\begin{pmatrix}0\\\\1\\end{pmatrix}, \\quad |D\\rangle = \\frac{1}{\\sqrt{2}}\\begin{pmatrix}1\\\\1\\end{pmatrix}, \\quad |A\\rangle = \\frac{1}{\\sqrt{2}}\\begin{pmatrix}1\\\\-1\\end{pmatrix}',
    formalMathDerivation: [
      'The transverse electric field of a monochromatic wave is E(t) = Re{[E_0x x̂ + E_0y e^(iδ) ŷ] e^(-iωt)}.',
      'In normalized Jones notation: |ψ⟩ = c0|H⟩ + c1|V⟩ where |c0|² + |c1|² = 1.',
      'Rectilinear Basis (Z): {|0⟩ = |H⟩, |1⟩ = |V⟩} forming an orthonormal basis: ⟨H|V⟩ = 0.',
      'Diagonal Basis (X): {|+⟩ = |D⟩, |-⟩ = |A⟩} where |D⟩ = (|H⟩ + |V⟩)/√2 and |A⟩ = (|H⟩ - |V⟩)/√2.',
    ],
    interactiveGoal: 'Select between H, V, D, and A source laser blocks to see the polarization arrow change.',
    quiz: [
      {
        id: 'q1_1',
        question: 'What is the inner product ⟨H|V⟩ between horizontal and vertical polarization states?',
        options: ['1', '1/√2', '0', '-1'],
        correctIndex: 2,
        explanation: '⟨H|V⟩ = [1, 0] · [0, 1]^T = 0. They are mutually orthogonal eigenstates of the rectilinear basis.',
      },
    ],
    references: [
      { title: "A new calculus for the treatment of optical systems", citation: "R. C. Jones, J. Opt. Soc. Am.", year: 1941 },
    ],
  },
  {
    id: 2,
    title: 'Qubits & The Bloch Sphere',
    subtitle: 'Geometric Mapping of Quantum Superposition',
    sceneId: 'bloch',
    learningObjectives: [
      'Map any 2-level quantum state |ψ⟩ = cos(θ/2)|0⟩ + e^(iφ)sin(θ/2)|1⟩ onto the unit Bloch sphere.',
      'Locate the Z-basis {|0⟩, |1⟩} at the poles and the X-basis {|+⟩, |-⟩} along the equator.',
      'See how waveplates rotate state vectors across the sphere.',
    ],
    eli12Intuition:
      "A classical bit is like a coin lying flat on a table: it is either Heads or Tails. A qubit is like a spinning coin floating in 3D space: it can point anywhere on a globe! North Pole is |0⟩, South Pole is |1⟩, and the equator represents 50/50 quantum superpositions.",
    formalMathTitle: 'Bloch Sphere Coordinate Mapping',
    formalMathLatex:
      '|\\psi\\rangle = \\cos\\frac{\\theta}{2}|0\\rangle + e^{i\\phi}\\sin\\frac{\\theta}{2}|1\\rangle \\implies \\vec{r} = (\\sin\\theta\\cos\\phi, \\; \\sin\\theta\\sin\\phi, \\; \\cos\\theta)',
    formalMathDerivation: [
      'Any pure state density matrix ρ = |ψ⟩⟨ψ| can be decomposed in the Pauli basis: ρ = 1/2 (I + r_x σ_x + r_y σ_y + r_z σ_z).',
      'For |0⟩: θ = 0 ⟹ r = (0, 0, 1) (North Pole).',
      'For |1⟩: θ = π ⟹ r = (0, 0, -1) (South Pole).',
      'For |+⟩ = 1/√2(|0⟩ + |1⟩): θ = π/2, φ = 0 ⟹ r = (1, 0, 0) (+X Axis).',
      'For |-⟩ = 1/√2(|0⟩ - |1⟩): θ = π/2, φ = π ⟹ r = (-1, 0, 0) (-X Axis).',
    ],
    interactiveGoal: 'Rotate the Bloch sphere and view how orthogonal states in Hilbert space appear opposite (180°) on the sphere.',
    quiz: [
      {
        id: 'q2_1',
        question: 'What is the angle between |0⟩ and |1⟩ on the Bloch sphere?',
        options: ['90°', '45°', '180°', '0°'],
        correctIndex: 2,
        explanation: 'Orthogonal quantum states (⟨0|1⟩ = 0) are antipodal (180° apart) on the Bloch sphere.',
      },
    ],
    references: [
      { title: "Nuclear Induction", citation: "F. Bloch, Physical Review", year: 1946 },
    ],
  },
  {
    id: 3,
    title: 'Measurement & The Commutator',
    subtitle: 'Why Measuring Disturbs the State: The Security Foundation',
    sceneId: 'bb84',
    learningObjectives: [
      'Evaluate the commutator of measurement operators [M+, M0] = 1/2 [[0, -1], [1, 0]] ≠ 0.',
      'Explain the No-Cloning Theorem (Wootters & Zurek 1982).',
      'Understand why non-commuting measurement observables prevent Eve from measuring without leaving traces.',
    ],
    eli12Intuition:
      "In the everyday world, you can look at a car to see its color without changing the car. But in quantum physics, looking at a photon with the wrong measurement glasses forces the light wave to change its vibration! Because the two bases do not commute, Eve cannot measure both directions simultaneously, and trying to copy an unknown photon is forbidden by the No-Cloning Theorem.",
    formalMathTitle: 'Non-Commuting Measurement Operators from Reference Image 2',
    formalMathLatex:
      '[M_+, M_0] = |+\\rangle\\langle+| |0\\rangle\\langle0| - |0\\rangle\\langle0| |+\\rangle\\langle+| = \\frac{1}{2}\\begin{pmatrix} 0 & -1 \\\\ 1 & 0 \\end{pmatrix} \\neq 0',
    formalMathDerivation: [
      'Measurement projector in the X-basis for bit 0: M_+ = |+⟩⟨+| = 1/2 [ [1, 1], [1, 1] ].',
      'Measurement projector in the Z-basis for bit 0: M_0 = |0⟩⟨0| = [ [1, 0], [0, 0] ].',
      'Product M_+ M_0 = 1/2 [ [1, 1], [1, 1] ] · [ [1, 0], [0, 0] ] = 1/2 [ [1, 0], [1, 0] ].',
      'Product M_0 M_+ = [ [1, 0], [0, 0] ] · 1/2 [ [1, 1], [1, 1] ] = 1/2 [ [1, 1], [0, 0] ].',
      'Commutator [M_+, M_0] = M_+ M_0 - M_0 M_+ = 1/2 [ [0, -1], [1, 0] ] ≠ 0.',
      'Because [M_+, M_0] ≠ 0, these observables do NOT share a common eigenbasis and cannot be measured simultaneously without disturbance.',
    ],
    interactiveGoal: 'Examine the blue math panel and observe how measurement basis non-commutativity protects BB84.',
    quiz: [
      {
        id: 'q3_1',
        question: 'What is the physical meaning of [M+, M0] ≠ 0 in BB84?',
        options: [
          'The measurement apparatus is broken.',
          'The measurement bases do not commute, so measuring in one basis destroys information in the other.',
          'Photons cannot travel through free space.',
          'The secret key will always have 50% errors.',
        ],
        correctIndex: 1,
        explanation: 'Non-zero commutators define complementary quantum observables; measuring in basis X destroys phase coherence in basis Z.',
      },
      {
        id: 'q3_2',
        question: 'What does the No-Cloning Theorem state?',
        options: [
          'It is impossible to build two identical lasers.',
          'An unknown arbitrary quantum state cannot be cloned identically by any unitary physical operation.',
          'You cannot copy files on a quantum computer.',
          'Alice and Bob cannot have identical secret keys.',
        ],
        correctIndex: 1,
        explanation: 'Proven by Wootters & Zurek and Dieks in 1982: linearity of quantum mechanics prevents unitary transformation U(|ψ⟩|0⟩) = |ψ⟩|ψ⟩ for arbitrary |ψ⟩.',
      },
    ],
    references: [
      { title: "A single quantum cannot be cloned", citation: "W. K. Wootters & W. H. Zurek, Nature", year: 1982 },
    ],
  },
  {
    id: 4,
    title: 'BB84 Step-by-Step on the Optical Bench',
    subtitle: 'From Alice’s Transmitter Chain to Bob’s SPAD Detectors',
    sceneId: 'bb84',
    learningObjectives: [
      'Trace Alice’s pulse generation: laser diode -> polarizers -> AM-PM-AM modulation chain.',
      'Trace Bob’s passive/active basis choice using HWP and PBS.',
      'Execute the sifting process: basis reconciliation over the classical channel.',
    ],
    eli12Intuition:
      "Here is how Alice and Bob make a secret key: (1) Alice flips a coin for a bit (0 or 1) and flips another coin for a basis (+ or ×). (2) She shoots a single photon. (3) Bob flips his own coin to choose his basis and detects the photon click. (4) Over a public phone call, they announce ONLY the bases they used, keeping the bits secret. When their bases match, their bits agree!",
    formalMathTitle: 'BB84 Transmission & Sifting Probability Table',
    formalMathLatex:
      'P(\\text{Click } | \\text{ same basis}) = 1, \\quad P(\\text{Click } | \\text{ different basis}) = |\\langle 0 | + \\rangle|^2 = \\frac{1}{2}',
    formalMathDerivation: [
      'Alice transmits random bit a ∈ {0, 1} in basis b_A ∈ {Z, X}.',
      'Bob measures in randomly chosen basis b_B ∈ {Z, X}.',
      'Case 1: b_A = b_B (50% probability): Bob measures Alice’s state exactly with probability 1 (in ideal conditions).',
      'Case 2: b_A ≠ b_B (50% probability): Bob projects onto an unbiased basis, yielding bit 0 or 1 with equal 50% probability.',
      'Sifting phase: Alice and Bob announce b_A and b_B over public channel. They discard all events where b_A ≠ b_B, keeping ~50% of detected bits.',
    ],
    interactiveGoal: 'Press "Step Pulse" to see a single photon travel through the AM-PM-AM chain into Bob’s SPADs.',
    quiz: [
      {
        id: 'q4_1',
        question: 'In BB84, what fraction of raw detected bits are retained during the sifting phase on average?',
        options: ['100%', '50%', '25%', '11%'],
        correctIndex: 1,
        explanation: 'Because Alice and Bob pick bases independently and uniformly from {Z, X}, their bases match with probability P(b_A = b_B) = 0.5 * 0.5 + 0.5 * 0.5 = 50%.',
      },
    ],
    references: [
      { title: "Quantum cryptography: Public key distribution and coin tossing", citation: "C. H. Bennett & G. Brassard, IEEE Conf. Computers, Systems and Signal Processing", year: 1984 },
    ],
  },
  {
    id: 5,
    title: 'Eavesdropping: Intercept-Resend & QBER',
    subtitle: 'Why Eve’s Measurement Inevitably Triggers an 11% Abort Threshold',
    sceneId: 'bb84',
    learningObjectives: [
      'Model an Intercept-Resend attack by Eve.',
      'Derive the theoretical 25% Quantum Bit Error Rate (QBER) caused by full eavesdropping.',
      'Understand the Shor-Preskill unconditional security bound (QBER < 11.0%).',
    ],
    eli12Intuition:
      "Eve tries to intercept Alice’s photons, measure them, and send replacement photons to Bob. But Eve doesn't know Alice's basis! Half the time, Eve guesses wrong, scrambling the photon. When Bob checks against Alice, a 25% error rate appears in their key. Alice and Bob check a sample: seeing errors above 11%, they abort and know an eavesdropper is listening!",
    formalMathTitle: 'QBER Derivation under Intercept-Resend Attack',
    formalMathLatex:
      '\\text{QBER} = P(b_E \\neq b_A) \\cdot P(\\text{Bob error} | b_E \\neq b_A) = \\frac{1}{2} \\times \\frac{1}{2} = 25\\%',
    formalMathDerivation: [
      'Assume Eve intercepts 100% of photons and measures in random basis b_E ∈ {Z, X}.',
      'Bob and Alice only keep sifted events where b_A = b_B.',
      'Sub-event 1: Eve picked b_E = b_A (probability 1/2): Eve measures correct bit, re-sends original state. Bob receives correct bit (0% error).',
      'Sub-event 2: Eve picked b_E ≠ b_A (probability 1/2): Eve measures random outcome and prepares state in wrong basis. Bob measuring in b_B = b_A gets 50% probability of error.',
      'Total Sifted QBER: QBER = 1/2 · 0 + 1/2 · 1/2 = 1/4 = 25%.',
      'Shor-Preskill Security Bound: If QBER exceeds ~11.0%, privacy amplification cannot eliminate Eve’s mutual information, and the protocol must abort!',
    ],
    interactiveGoal: 'Toggle Eve on and drag the Intercept Rate slider to 100%: watch QBER climb to ~25% and the ABORT alert trigger.',
    quiz: [
      {
        id: 'q5_1',
        question: 'What is the expected QBER on the sifted key if Eve intercepts and resends every photon?',
        options: ['0%', '11%', '25%', '50%'],
        correctIndex: 2,
        explanation: 'QBER = P(Eve wrong basis) * P(Bob flip) = 0.5 * 0.5 = 25%.',
      },
      {
        id: 'q5_2',
        question: 'Why is the standard abort threshold in BB84 set to ~11%?',
        options: [
          'Because optical fibers have 11 dB loss.',
          'Because at QBER > 11.0%, Eve’s mutual information with Alice exceeds Bob’s mutual information with Alice (Shor-Preskill bound).',
          'Because detectors stop functioning at 11%.',
          'It is an arbitrary safety margin with no mathematical basis.',
        ],
        correctIndex: 1,
        explanation: 'Shor & Preskill (2000) proved asymptotic security: secret key rate R = 1 - 2*h(QBER). The binary entropy function h(QBER) satisfies 1 - 2*h(0.11) = 0.',
      },
    ],
    references: [
      { title: "Simple Proof of Security of the BB84 Quantum Key Distribution Protocol", citation: "P. W. Shor & J. Preskill, Phys. Rev. Lett.", year: 2000 },
    ],
  },
  {
    id: 6,
    title: 'Post-Processing: Error Correction & Privacy Amplification',
    subtitle: 'Distilling an Information-Theoretically Secure Secret Key',
    sceneId: 'bb84',
    learningObjectives: [
      'Learn how the Cascade / LDPC protocol corrects bit discrepancies via public parity exchanges.',
      'Calculate the parity leakage to Eve: leakage ≈ f · h(QBER).',
      'Apply 2-universal hash functions for privacy amplification to compress Eve’s knowledge to zero.',
    ],
    eli12Intuition:
      "Even without an eavesdropper, real lab equipment has tiny imperfections causing a few bit errors (e.g. 2%). Alice and Bob compare block parities (odd or even) to hunt down and fix these errors. Then, using a mathematical blender called 'Privacy Amplification', they compress the remaining key, destroying every scrap of partial information Eve might have picked up!",
    formalMathTitle: 'Asymptotic Secret Key Fraction (GLLP Formalism)',
    formalMathLatex:
      'R \\ge 1 - h(\\text{QBER}) - f_{\\text{EC}} \\cdot h(\\text{QBER})',
    formalMathDerivation: [
      'Error Correction (EC): Alice and Bob run Cascade or LDPC, exchanging syndrome parities. Classical leakage is at least Shannon limit leak_EC = f_EC · h(QBER) where f_EC ≈ 1.15.',
      'Privacy Amplification (PA): Using Toeplitz hashing matrices or universal-2 hash families, Alice and Bob compress the corrected n-bit key to an m-bit key.',
      'By the Leftover Hash Lemma, Eve’s variational distance from uniform distribution is bounded by 2^(-s), achieving information-theoretic security.',
    ],
    interactiveGoal: 'Simulate a batch of 200 pulses and observe the transformation from raw bits -> sifted bits -> corrected bits -> final hex secret key.',
    quiz: [
      {
        id: 'q6_1',
        question: 'What is the purpose of Privacy Amplification in QKD?',
        options: [
          'To make the key longer.',
          'To compress the key using hash functions to eliminate any partial information leaked to Eve during transmission or error correction.',
          'To encrypt the quantum photons with AES.',
          'To speed up the laser repetition rate.',
        ],
        correctIndex: 1,
        explanation: 'Privacy amplification uses 2-universal hash functions to reduce Eve’s mutual information with the final key to an exponentially small quantity 2^(-s).',
      },
    ],
    references: [
      { title: "Information reconciliation and privacy amplification", citation: "G. Brassard & L. Salvail, EUROCRYPT", year: 1993 },
    ],
  },
  {
    id: 7,
    title: 'Real-World Hardware & Decoy States',
    subtitle: 'Beating the Photon-Number-Splitting (PNS) Attack',
    sceneId: 'satellite',
    satelliteView: 'fiber',
    learningObjectives: [
      'Understand why faint laser pulses have Poisson photon statistics P(n) = e^(-μ) μ^n / n!.',
      'Analyze the Photon-Number-Splitting (PNS) attack on multi-photon pulses (n ≥ 2).',
      'Explain how the Decoy-State method (Hwang 2003, Lo-Ma-Chen 2005) solves the PNS vulnerability.',
    ],
    eli12Intuition:
      "True single-photon lasers are hard to build, so engineers use regular lasers dimmed with an attenuator. But occasionally, a pulse has two photons! An evil spy could steal one photon and let the other pass unnoticed. To catch her, Alice randomly alternates between regular pulses and dimmer 'decoy' pulses. If Eve tries to cherry-pick multi-photon pulses, the decoy statistics will betray her immediately!",
    formalMathTitle: 'Poisson Distribution & Decoy-State Verification',
    formalMathLatex:
      'P(n) = \\frac{\\mu^n e^{-\\mu}}{n!}, \\quad Y_n = \\text{Yield of } n\\text{-photon pulse}',
    formalMathDerivation: [
      'Attenuated coherent state |α⟩ has mean photon number μ = |α|². Photon statistics: P(n) = e^(-μ) μ^n / n!.',
      'Multi-photon fraction: P(n ≥ 2) = 1 - e^(-μ)(1 + μ) ≈ μ²/2 for μ ≪ 1.',
      'In a PNS attack, Eve keeps one photon from n ≥ 2 pulses in quantum memory, measures it after basis announcement, and introduces 0% QBER on those pulses!',
      'Decoy-State Protocol: Alice randomly varies intensity μ ∈ {μ_signal, ν_decoy, ω_vacuum}. Because Eve cannot distinguish pulse intensity, any intensity-dependent tampering violates the linear yield constraints Y_n, exposing Eve.',
    ],
    interactiveGoal: 'Switch between Satellite Payload and Fiber Module to inspect the 850-nm QLD and phase modulators.',
    quiz: [
      {
        id: 'q7_1',
        question: 'Why are weak coherent laser pulses vulnerable to Photon-Number-Splitting (PNS) attacks?',
        options: [
          'Because the laser runs out of battery.',
          'Because Poisson statistics mean some pulses contain 2 or more photons, allowing Eve to steal one without alerting Bob.',
          'Because the laser wavelength drifts.',
          'Because the detectors overheat.',
        ],
        correctIndex: 1,
        explanation: 'Coherent states have Poissonian distribution P(n). If n ≥ 2, Eve can non-destructively split off one photon, measure it after basis announcement, and cause zero error.',
      },
    ],
    references: [
      { title: "Quantum Key Distribution with Blinding of Multi-photon Pulses", citation: "W.-Y. Hwang, Phys. Rev. Lett.", year: 2003 },
      { title: "Decoy State Quantum Key Distribution", citation: "H.-K. Lo, X. Ma, K. Chen, Phys. Rev. Lett.", year: 2005 },
    ],
  },
  {
    id: 8,
    title: 'Satellite-to-Ground QKD (Scene B: Jinan-1)',
    subtitle: 'Why Space? Exponential Fiber Loss vs Free-Space Link Budget',
    sceneId: 'satellite',
    satelliteView: 'orbit',
    learningObjectives: [
      'Compare exponential fiber loss (220 dB / 100 km) with free-space geometric loss (~30 dB / 1000 km).',
      'Explain the multiplexed optical wavelengths in Jinan-1 (Image 1): 850 nm quantum, 812 nm downlink, 1538 nm uplink, 532/785 nm beacons.',
      'Understand Acquisition, Pointing, and Tracking (APT) using Fast Steering Mirrors (FSM1, FSM2) and cameras (CAM1-CAM4).',
    ],
    eli12Intuition:
      "Why shoot lasers to space? Because glass fiber cables absorb light exponentially: after just 100 km, out of 10^22 photons, only 1 gets through! But space is empty vacuum. A satellite flying 500 km overhead loses only ~30 dB of light. Jinan-1 uses green and infrared beacon lasers with high-speed vibrating mirrors to lock onto ground telescopes across hundreds of kilometers, making real-time quantum keys possible worldwide!",
    formalMathTitle: 'Free-Space Geometric Collection & Diffraction Loss',
    formalMathLatex:
      '\\eta_{\\text{geom}} = \\frac{D_{\\text{rx}}^2}{(1.22 \\,\\lambda R / D_{\\text{tx}})^2}, \\quad L_{\\text{fiber}} = 10^{-\\frac{\\alpha d}{10}}',
    formalMathDerivation: [
      'Terrestrial fiber loss @ 850 nm: α = 2.2 dB/km. For d = 100 km, loss = 220 dB (transmittance T = 10^(-22), completely impossible!).',
      'Satellite free space link: Diffraction divergence θ_div ≈ 1.22 λ / D_tx. For D_tx = 0.18 m, λ = 850 nm: θ_div ≈ 5.76 μrad.',
      'Beam spot diameter on ground at R = 550 km: W = θ_div · R ≈ 3.17 meters.',
      'Ground telescope aperture D_rx = 1.0 m: Geometric collection efficiency η_geom ≈ (1.0 / 3.17)² ≈ 0.10 (-10 dB).',
      'Including atmospheric transmission (~1.8 dB), pointing jitter (~2 dB), and optical bench loss (~3.5 dB), total link loss is only ~25-35 dB!',
    ],
    interactiveGoal: 'Use the view switcher to zoom between Earth Orbit (Panel a), Satellite Payload (Panel c), and Ground Station (Panel d).',
    quiz: [
      {
        id: 'q8_1',
        question: 'Why can satellite QKD reach thousands of kilometers while fiber QKD is practically limited to ~100-300 km without quantum repeaters?',
        options: [
          'Satellites have nuclear power generators.',
          'Most of the satellite-to-ground path is vacuum with zero absorption; terrestrial optical fiber attenuates light exponentially with distance.',
          'Quantum states are immune to physics in space.',
          'Fiber optic cables are always tapped by eavesdroppers.',
        ],
        correctIndex: 1,
        explanation: 'In optical fiber, transmission decays exponentially T = 10^(-α d/10). In satellite QKD, light travels through vacuum where α = 0, with only the bottom ~10 km passing through atmosphere.',
      },
      {
        id: 'q8_2',
        question: 'What is the role of the 532-nm and 785-nm beacon lasers in the Jinan-1 architecture (Image 1)?',
        options: [
          'They carry the secret quantum keys.',
          'They heat up the optical components.',
          'They provide high-power optical references for the Acquisition, Pointing, and Tracking (APT) control loops with Fast Steering Mirrors.',
          'They are used for laser radar altimetry only.',
        ],
        correctIndex: 2,
        explanation: 'The 532 nm (satellite downlink) and 785 nm (ground uplink) beacon lasers provide bright optical tracking spots detected by CAM1-CAM4 to drive FSM1/FSM2 with sub-microradian precision.',
      },
    ],
    references: [
      { title: "Real-time key distillation for satellite-to-ground quantum key distribution", citation: "Jinan-1 Research Team, Nature / Nature Photonics", year: 2022 },
    ],
  },
  {
    id: 9,
    title: 'Capstone Sandbox & Mission Control',
    subtitle: 'Break the Protocol, Tune Noise, and Secure Global Satellite QKD',
    sceneId: 'bb84',
    learningObjectives: [
      'Experiment with real-time controls: intercept rate, channel distance, detector dark counts, and abort thresholds.',
      'Observe real-time trade-offs between key generation rate, QBER, and privacy amplification.',
      'Achieve target mission parameters: distil positive secret key under realistic channel noise.',
    ],
    eli12Intuition:
      "You are now the Chief Quantum Engineer! Take full control of the optical lab. Crank up Eve's spying strength to see when Alice and Bob detect her. Change the channel distance to simulate space orbits versus fiber cables. Can you tune the system to maintain a positive secret key rate without tripping the abort alarm?",
    formalMathTitle: 'Asymptotic Key Rate Formula',
    formalMathLatex:
      'K = \\max\\left(0, \\; Q_{\\mu} \\left[ 1 - h(e_{\\mu}) - f \\cdot h(e_{\\mu}) \\right] \\right)',
    formalMathDerivation: [
      'Q_μ: Overall detection rate (gain) of signal states.',
      'e_μ: Overall quantum bit error rate (QBER).',
      'h(x) = -x log2(x) - (1-x) log2(1-x): Binary entropy function.',
      'f: Error correction efficiency factor (typically 1.1 - 1.2).',
      'When e_μ exceeds the critical threshold (e_crit ≈ 11%), the expression inside brackets drops below zero, yielding K = 0 (abort).',
    ],
    interactiveGoal: 'Use the interactive controls to achieve a secret key rate > 0 with at least 5% channel noise.',
    quiz: [
      {
        id: 'q9_1',
        question: 'What happens to the secret key rate K when QBER exceeds the critical threshold e_crit (~11%)?',
        options: [
          'It continues at full speed.',
          'It drops to zero and the protocol must abort because Eve holds more information than Alice and Bob can securely distill.',
          'It switches to classical RSA.',
          'It doubles to compensate for lost bits.',
        ],
        correctIndex: 1,
        explanation: 'At QBER > 11%, the mutual information I(Alice:Eve) exceeds I(Alice:Bob), making secure privacy amplification impossible.',
      },
    ],
    references: [
      { title: "Quantum key distribution: from theory to applications", citation: "V. Scarani et al., Rev. Mod. Phys.", year: 2009 },
    ],
  },
];
