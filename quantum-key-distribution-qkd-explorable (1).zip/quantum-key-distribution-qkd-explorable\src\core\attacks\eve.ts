import { Vector2 } from '../math/vector2';
import { SeededRNG } from '../rng';

export type Basis = 'Z' | 'X'; // Z = Rectilinear {H, V}, X = Diagonal {D, A}
export type Bit = 0 | 1;

export interface AttackResult {
  intercepted: boolean;
  eveBasis?: Basis;
  eveMeasuredBit?: Bit;
  transmittedState: Vector2;
}

export class EveAttacks {
  /**
   * Intercept-Resend Attack:
   * Eve intercepts a photon with probability `interceptRate` (0 to 1),
   * chooses a random basis (Z or X), measures the state, and re-emits a new photon
   * prepared in that measured eigenstate.
   */
  static interceptResend(
    state: Vector2,
    interceptRate: number = 1.0,
    rng: SeededRNG
  ): AttackResult {
    if (rng.next() > interceptRate) {
      return {
        intercepted: false,
        transmittedState: state,
      };
    }

    const eveBasis: Basis = rng.nextBool() ? 'Z' : 'X';
    let eveMeasuredBit: Bit;
    let resendState: Vector2;

    if (eveBasis === 'Z') {
      // Measure in {H, V}
      const probH = state.probabilityOf(Vector2.H);
      eveMeasuredBit = rng.next() < probH ? 0 : 1;
      resendState = eveMeasuredBit === 0 ? Vector2.H : Vector2.V;
    } else {
      // Measure in {D, A}
      const probD = state.probabilityOf(Vector2.D);
      eveMeasuredBit = rng.next() < probD ? 0 : 1;
      resendState = eveMeasuredBit === 0 ? Vector2.D : Vector2.A;
    }

    return {
      intercepted: true,
      eveBasis,
      eveMeasuredBit,
      transmittedState: resendState,
    };
  }

  /**
   * Photon-Number-Splitting (PNS) attack calculation:
   * Given laser mean photon number μ, Poissonian distribution:
   * P(n) = e^(-μ) * μ^n / n!
   * Multi-photon pulses (n >= 2) allow Eve to siphon one photon without alerting Bob,
   * leaving single-photon pulses (n = 1) vulnerable.
   */
  static pnsVulnerability(meanPhotonNumber: number): {
    pZero: number;
    pSingle: number;
    pMulti: number;
    eveInformationBound: number;
  } {
    const mu = Math.max(0.001, meanPhotonNumber);
    const pZero = Math.exp(-mu);
    const pSingle = Math.exp(-mu) * mu;
    const pMulti = 1 - pZero - pSingle;
    const totalSignals = pSingle + pMulti;
    const eveInformationBound = totalSignals > 0 ? pMulti / totalSignals : 0;

    return {
      pZero,
      pSingle,
      pMulti,
      eveInformationBound,
    };
  }
}
