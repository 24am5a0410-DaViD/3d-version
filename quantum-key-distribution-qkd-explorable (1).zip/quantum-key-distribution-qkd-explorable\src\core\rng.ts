/**
 * Mulberry32 seedable pseudo-random number generator.
 * Provides deterministic, reproducible randomness for quantum simulation steps,
 * unit tests, and interactive lesson checkpoints.
 */
export class SeededRNG {
  private state: number;

  constructor(seed: number = 1337) {
    this.state = seed >>> 0;
  }

  /** Returns a pseudorandom float in [0, 1) */
  next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /** Returns a random bit (0 or 1) */
  nextBit(): 0 | 1 {
    return this.next() < 0.5 ? 0 : 1;
  }

  /** Returns a random boolean */
  nextBool(probabilityTrue: number = 0.5): boolean {
    return this.next() < probabilityTrue;
  }

  /** Returns a float in [min, max) */
  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  /** Returns an integer in [min, max] inclusive */
  randInt(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }

  /** Resets state with a new seed */
  setSeed(seed: number): void {
    this.state = seed >>> 0;
  }
}

export const defaultRNG = new SeededRNG(42);
