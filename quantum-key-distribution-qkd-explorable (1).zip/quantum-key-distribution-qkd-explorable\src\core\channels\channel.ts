/**
 * Physical Channel Models: Optical Fiber vs Free-Space Satellite Links.
 */
export interface SatelliteLinkBudget {
  distanceKm: number;
  geometricLossDb: number;
  atmosphericLossDb: number;
  pointingLossDb: number;
  opticsEfficiencyDb: number;
  totalLossDb: number;
  transmittance: number;
  daytimeNoiseHz: number;
  nighttimeNoiseHz: number;
}

export class Channels {
  /**
   * Terrestrial Optical Fiber transmission loss.
   * Typical attenuation coefficient:
   *   α = 0.20 dB/km @ 1550 nm (telecom C-band)
   *   α = 2.20 dB/km @ 850 nm (quantum diode silicon-matched)
   */
  static fiberTransmission(distanceKm: number, wavelengthNm: number = 850): { lossDb: number; transmittance: number } {
    const alpha = wavelengthNm > 1500 ? 0.20 : 2.20;
    const lossDb = alpha * distanceKm;
    const transmittance = Math.pow(10, -lossDb / 10);
    return { lossDb, transmittance };
  }

  /**
   * Satellite-to-Ground Free Space Link Budget (Jinan-1 Specs).
   * @param distanceKm Slant range from satellite to ground telescope (500 km at zenith to ~1200 km at horizon)
   * @param txApertureM Satellite transmitter telescope diameter (e.g. 0.18 m)
   * @param rxApertureM Ground station receiver telescope diameter (e.g. 1.0 m)
   * @param wavelengthNm Quantum channel wavelength (850 nm)
   * @param pointingJitterUrad Satellite pointing precision (e.g. 1.5 μrad with FSM)
   */
  static satelliteLinkBudget(
    distanceKm: number = 550,
    txApertureM: number = 0.18,
    rxApertureM: number = 1.0,
    wavelengthNm: number = 850,
    pointingJitterUrad: number = 1.5
  ): SatelliteLinkBudget {
    const lambdaM = wavelengthNm * 1e-9;
    const rM = distanceKm * 1000;

    // Diffraction beam divergence: θ ≈ 1.22 * λ / D_tx
    const divergenceRad = 1.22 * (lambdaM / txApertureM);
    // Spot radius on ground
    const spotRadiusM = divergenceRad * rM;
    const spotArea = Math.PI * spotRadiusM * spotRadiusM;
    const rxArea = Math.PI * Math.pow(rxApertureM / 2, 2);

    // Geometric collection ratio
    const geomRatio = Math.min(1.0, rxArea / spotArea);
    const geometricLossDb = -10 * Math.log10(Math.max(1e-12, geomRatio));

    // Clear sky zenith atmospheric loss (~1.5 dB @ 850 nm)
    const atmosphericLossDb = 1.8;

    // Pointing jitter loss
    const pointingErrorRad = pointingJitterUrad * 1e-6;
    const pointingRatio = Math.exp(-2 * Math.pow(pointingErrorRad / divergenceRad, 2));
    const pointingLossDb = -10 * Math.log10(Math.max(1e-12, pointingRatio));

    // Optical bench internal component transmission (~3 dB total in Tx + Rx)
    const opticsEfficiencyDb = 3.5;

    const totalLossDb = geometricLossDb + atmosphericLossDb + pointingLossDb + opticsEfficiencyDb;
    const transmittance = Math.pow(10, -totalLossDb / 10);

    // Background sky noise counts (with 0.1 nm filter + 50 μrad FOV)
    const daytimeNoiseHz = 15000;
    const nighttimeNoiseHz = 40;

    return {
      distanceKm,
      geometricLossDb,
      atmosphericLossDb,
      pointingLossDb,
      opticsEfficiencyDb,
      totalLossDb,
      transmittance,
      daytimeNoiseHz,
      nighttimeNoiseHz,
    };
  }
}
