import * as THREE from 'three';

/**
 * Laser Beam & Single-Photon Traveling Pulse Shader Renderer.
 * Simulates traveling wavepackets along 3D optical trajectories.
 */

const BeamVertexShader = `
  varying vec2 vUv;
  varying vec3 vPosition;
  varying vec3 vNormal;

  void main() {
    vUv = uv;
    vNormal = normalize(normalMatrix * normal);
    vPosition = (modelMatrix * vec4(position, 1.0)).xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const BeamFragmentShader = `
  uniform vec3 uColor;
  uniform float uTime;
  uniform float uPulseSpeed;
  uniform float uPulseSpacing;
  uniform float uCoreIntensity;
  uniform float uGlowRadius;

  varying vec2 vUv;
  varying vec3 vNormal;
  varying vec3 vPosition;

  void main() {
    // Traveling pulse coordinate
    float travel = fract(vUv.x * uPulseSpacing - uTime * uPulseSpeed);
    
    // Gaussian-like localized photon envelope
    float pulse = exp(-pow((travel - 0.5) * 6.0, 2.0));
    
    // Core radial glow
    float radial = 1.0 - abs(vUv.y - 0.5) * 2.0;
    radial = pow(radial, uGlowRadius);

    // Combine continuous baseline beam + bright photon pulse
    float intensity = (0.2 + 0.8 * pulse) * radial * uCoreIntensity;

    vec3 finalColor = uColor * intensity + vec3(1.0) * pow(pulse * radial, 3.0) * 0.5;
    float alpha = clamp(intensity, 0.0, 0.95);

    gl_FragColor = vec4(finalColor, alpha);
  }
`;

export interface BeamSegmentOptions {
  start: THREE.Vector3;
  end: THREE.Vector3;
  color: THREE.Color;
  radius?: number;
  pulseSpeed?: number;
  pulseSpacing?: number;
  wavelengthNm?: number;
}

export class LaserBeamRenderer {
  private group: THREE.Group;
  private materials: THREE.ShaderMaterial[] = [];

  constructor() {
    this.group = new THREE.Group();
  }

  getGroup(): THREE.Group {
    return this.group;
  }

  clear(): void {
    while (this.group.children.length > 0) {
      const obj = this.group.children[0];
      this.group.remove(obj);
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
      }
    }
    this.materials.forEach((m) => m.dispose());
    this.materials = [];
  }

  addBeamSegment(options: BeamSegmentOptions): THREE.Mesh {
    const {
      start,
      end,
      color,
      radius = 0.025,
      pulseSpeed = 1.8,
      pulseSpacing = 1.5,
    } = options;

    const dir = new THREE.Vector3().subVectors(end, start);
    const length = dir.length();

    // Create cylinder oriented from start to end
    const geom = new THREE.CylinderGeometry(radius, radius, length, 16, 32, true);
    // Cylinder default is centered and along Y-axis, rotate and shift to start-to-end
    geom.translate(0, length / 2, 0);
    geom.rotateX(Math.PI / 2);

    const material = new THREE.ShaderMaterial({
      vertexShader: BeamVertexShader,
      fragmentShader: BeamFragmentShader,
      uniforms: {
        uColor: { value: color },
        uTime: { value: 0 },
        uPulseSpeed: { value: pulseSpeed },
        uPulseSpacing: { value: pulseSpacing * (length / 2) },
        uCoreIntensity: { value: 2.2 },
        uGlowRadius: { value: 1.8 },
      },
      transparent: true,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      depthWrite: false,
    });

    const mesh = new THREE.Mesh(geom, material);
    mesh.position.copy(start);
    mesh.lookAt(end);

    this.materials.push(material);
    this.group.add(mesh);

    return mesh;
  }

  update(timeSeconds: number): void {
    for (const mat of this.materials) {
      mat.uniforms.uTime.value = timeSeconds;
    }
  }

  /**
   * Helper to convert optical wavelength to accurate RGB color
   */
  static wavelengthToColor(wavelengthNm: number): THREE.Color {
    if (wavelengthNm <= 540) return new THREE.Color(0x10b981); // 532 nm beacon (Emerald Green)
    if (wavelengthNm <= 790) return new THREE.Color(0xf59e0b); // 785 nm beacon (Amber)
    if (wavelengthNm <= 820) return new THREE.Color(0xff6b00); // 812 nm classical downlink (Orange)
    if (wavelengthNm <= 860) return new THREE.Color(0xff2244); // 850 nm quantum channel (Luminous Ruby)
    return new THREE.Color(0xd946ef);                          // 1538 nm classical uplink (Telecom Magenta)
  }
}
