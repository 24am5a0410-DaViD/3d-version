import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  BB84Simulator,
  RunParams,
  RunResult,
  runAttackSweep,
  BASIS_SYMBOL,
} from './bb84Engine';
import {
  THEORY_SECTIONS,
  QUIZ_BANK,
  EVALUATION_QUESTIONS,
  PERSONAS,
  ROADMAP_PHASES,
} from './bb84Data';
import {
  Shield,
  ShieldAlert,
  Play,
  BookOpen,
  BarChart3,
  GraduationCap,
  Sparkles,
  ExternalLink,
  ChevronLeft,
  CheckCircle2,
  XCircle,
  Layers,
  Activity,
  Award,
  Globe2,
  Code,
  Flame,
} from 'lucide-react';

interface BB84ProtocolAppProps {
  onBackToTestbench: () => void;
}

export const BB84ProtocolApp: React.FC<BB84ProtocolAppProps> = ({ onBackToTestbench }) => {
  // Mode: Native React App vs Live Streamlit Embed
  const [viewMode, setViewMode] = useState<'native' | 'streamlit'>('native');

  // Active Tab in Native App
  const [activeTab, setActiveTab] = useState<
    | 'run'
    | 'walkthrough'
    | 'learn'
    | 'analyse'
    | 'educator'
    | 'eval'
    | 'performance'
    | 'community'
    | 'roadmap'
    | 'opensource'
    | 'impact'
  >('run');

  // Simulation parameters
  const [preset, setPreset] = useState<'clean' | 'full' | 'partial' | 'noisy' | 'custom'>('clean');
  const [numPhotons, setNumPhotons] = useState<number>(200);
  const [evePresent, setEvePresent] = useState<boolean>(false);
  const [eveProbability, setEveProbability] = useState<number>(0);
  const [noiseLevel, setNoiseLevel] = useState<number>(0);
  const [sampleFraction, setSampleFraction] = useState<number>(0.5);

  // Simulation execution result
  const [result, setResult] = useState<RunResult | null>(null);

  // Run simulation handler
  const executeSimulation = (paramsOverride?: Partial<RunParams>) => {
    const params: RunParams = {
      numPhotons,
      evePresent,
      eveProbability: evePresent ? eveProbability : 0,
      noiseLevel,
      sampleFraction,
      ...paramsOverride,
    };
    const sim = new BB84Simulator(params);
    const res = sim.run();
    setResult(res);
  };

  // Run initial simulation on mount
  useEffect(() => {
    executeSimulation();
  }, []);

  // Preset applicator
  const applyPreset = (key: 'clean' | 'full' | 'partial' | 'noisy') => {
    setPreset(key);
    if (key === 'clean') {
      setNumPhotons(200);
      setEvePresent(false);
      setEveProbability(0);
      setNoiseLevel(0);
      executeSimulation({ numPhotons: 200, evePresent: false, eveProbability: 0, noiseLevel: 0 });
    } else if (key === 'full') {
      setNumPhotons(200);
      setEvePresent(true);
      setEveProbability(1.0);
      setNoiseLevel(0);
      executeSimulation({ numPhotons: 200, evePresent: true, eveProbability: 1.0, noiseLevel: 0 });
    } else if (key === 'partial') {
      setNumPhotons(400);
      setEvePresent(true);
      setEveProbability(0.3);
      setNoiseLevel(0);
      executeSimulation({ numPhotons: 400, evePresent: true, eveProbability: 0.3, noiseLevel: 0 });
    } else if (key === 'noisy') {
      setNumPhotons(200);
      setEvePresent(false);
      setEveProbability(0);
      setNoiseLevel(0.08);
      executeSimulation({ numPhotons: 200, evePresent: false, eveProbability: 0, noiseLevel: 0.08 });
    }
  };

  // Single-photon walkthrough state
  const [walkthroughPhotonIndex, setWalkthroughPhotonIndex] = useState<number>(0);
  const [walkthroughStep, setWalkthroughStep] = useState<number>(1);

  // Theory sections read tracker
  const [readSections, setReadSections] = useState<Set<number>>(new Set([1]));

  // Quiz state
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  // Evaluation pre/post state
  const [evalAnswers, setEvalAnswers] = useState<Record<number, number>>({});
  const [evalSubmitted, setEvalSubmitted] = useState<boolean>(false);

  // Attack sweep cached data
  const sweepData = useMemo(() => runAttackSweep(300, 4), []);

  const currentPhoton = result ? result.photons[walkthroughPhotonIndex] : null;

  // Polarisation circle canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (!canvasRef.current || !currentPhoton) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const radius = cx - 24;

    // Draw coordinate axes
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx, cy - radius);
    ctx.lineTo(cx, cy + radius);
    ctx.moveTo(cx - radius, cy);
    ctx.lineTo(cx + radius, cy);
    ctx.stroke();

    // Draw circle
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Draw photon polarization angle
    const angleRad = (currentPhoton.aliceAngle * Math.PI) / 180;
    const isDiag = currentPhoton.aliceBasis === 1;

    ctx.strokeStyle = isDiag ? '#f59e0b' : '#38bdf8';
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(cx - Math.cos(angleRad) * radius, cy + Math.sin(angleRad) * radius);
    ctx.lineTo(cx + Math.cos(angleRad) * radius, cy - Math.sin(angleRad) * radius);
    ctx.stroke();

    // Draw central glowing node
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(cx, cy, 5, 0, Math.PI * 2);
    ctx.fill();
  }, [currentPhoton, walkthroughStep]);

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans select-text">
      {/* Top Banner Navigation */}
      <header className="sticky top-0 z-50 bg-[#0c1220]/95 backdrop-blur-md border-b border-slate-800/80 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onBackToTestbench}
            className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-blue-600 text-xs font-semibold text-slate-200 hover:text-white transition shadow-sm border border-slate-700/60"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Back to 3D Optical Testbench</span>
          </button>

          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm tracking-wide text-white">BB84 QKD Lab</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800">
                WISER Global Challenge 2026
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Track: <em>Quantum Cryptography and Cybersecurity</em> — Bennett & Brassard (1984) Protocol Suite
            </p>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center space-x-2 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setViewMode('native')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              viewMode === 'native' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Integrated Web Suite</span>
          </button>

          <button
            onClick={() => setViewMode('streamlit')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              viewMode === 'streamlit' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Live Streamlit App (Port 8501)</span>
          </button>
        </div>
      </header>

      {/* STREAMLIT EMBEDDED VIEW */}
      {viewMode === 'streamlit' ? (
        <div className="flex-1 flex flex-col bg-[#030712] p-4">
          <div className="flex items-center justify-between bg-slate-900 px-4 py-2.5 rounded-t-xl border border-slate-800 text-xs">
            <div className="flex items-center space-x-2 text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-semibold">Streamlit Community Cloud Server Active</span>
              <span className="text-slate-500">|</span>
              <span className="font-mono text-cyan-400">http://localhost:8501/</span>
            </div>
            <div className="flex items-center space-x-3">
              <a
                href="http://localhost:8501/"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium flex items-center space-x-1"
              >
                <span>Open Local in New Tab</span>
                <ExternalLink className="w-3 h-3 ml-1" />
              </a>
              <a
                href="https://wiser-education-challenge-7lupjj7uevujzyrkwnjg6b.streamlit.app/"
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium flex items-center space-x-1"
              >
                <span>Open Streamlit Cloud</span>
                <ExternalLink className="w-3 h-3 ml-1" />
              </a>
            </div>
          </div>
          <iframe
            src="http://localhost:8501/"
            title="Streamlit BB84 QKD Lab"
            className="flex-1 w-full border border-slate-800 rounded-b-xl min-h-[820px] bg-slate-950"
          />
        </div>
      ) : (
        /* NATIVE INTERACTIVE WEB APP */
        <div className="flex-1 flex overflow-hidden">
          {/* LEFT SIDEBAR: CONTROL CONSOLE */}
          <aside className="w-80 bg-[#0b101c] border-r border-slate-800/80 p-5 flex flex-col space-y-5 overflow-y-auto shrink-0 text-xs">
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-1">Control Console</h2>
              <p className="text-[11px] text-slate-400">Configure the quantum channel & eavesdropping attack.</p>
            </div>

            {/* Presets */}
            <div className="space-y-2">
              <label className="font-semibold text-slate-300 block">Classroom Presets</label>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => applyPreset('clean')}
                  className={`px-2.5 py-2 rounded-lg text-left font-medium transition border ${
                    preset === 'clean'
                      ? 'bg-blue-900/60 border-blue-500 text-cyan-200'
                      : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="font-bold">🛡️ Clean Line</div>
                  <div className="text-[10px] text-slate-400">0% Eve, 0% Noise</div>
                </button>
                <button
                  onClick={() => applyPreset('full')}
                  className={`px-2.5 py-2 rounded-lg text-left font-medium transition border ${
                    preset === 'full'
                      ? 'bg-rose-900/60 border-rose-500 text-rose-200'
                      : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="font-bold">🚨 Full Attack</div>
                  <div className="text-[10px] text-slate-400">100% Intercept</div>
                </button>
                <button
                  onClick={() => applyPreset('partial')}
                  className={`px-2.5 py-2 rounded-lg text-left font-medium transition border ${
                    preset === 'partial'
                      ? 'bg-amber-900/60 border-amber-500 text-amber-200'
                      : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="font-bold">⚠️ Partial Tap</div>
                  <div className="text-[10px] text-slate-400">30% Intercept</div>
                </button>
                <button
                  onClick={() => applyPreset('noisy')}
                  className={`px-2.5 py-2 rounded-lg text-left font-medium transition border ${
                    preset === 'noisy'
                      ? 'bg-purple-900/60 border-purple-500 text-purple-200'
                      : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="font-bold">📡 Noisy Line</div>
                  <div className="text-[10px] text-slate-400">8% Dark counts</div>
                </button>
              </div>
            </div>

            {/* Slider Controls */}
            <div className="space-y-4 pt-2 border-t border-slate-800/80">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Number of Photons (N)</span>
                  <span className="font-mono text-cyan-400">{numPhotons}</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="1000"
                  step="50"
                  value={numPhotons}
                  onChange={(e) => {
                    setNumPhotons(+e.target.value);
                    setPreset('custom');
                  }}
                  className="w-full accent-cyan-500"
                />
              </div>

              {/* Eve Toggle */}
              <div className="bg-slate-900/70 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">Eavesdropper (Eve)</span>
                  <input
                    type="checkbox"
                    checked={evePresent}
                    onChange={(e) => {
                      setEvePresent(e.target.checked);
                      if (e.target.checked && eveProbability === 0) setEveProbability(1.0);
                      setPreset('custom');
                    }}
                    className="w-4 h-4 accent-rose-500 rounded cursor-pointer"
                  />
                </div>
                {evePresent && (
                  <div className="pt-2">
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Interception Rate (p)</span>
                      <span className="font-mono text-rose-400">{(eveProbability * 100).toFixed(0)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.05"
                      max="1.0"
                      step="0.05"
                      value={eveProbability}
                      onChange={(e) => {
                        setEveProbability(+e.target.value);
                        setPreset('custom');
                      }}
                      className="w-full accent-rose-500"
                    />
                    <div className="text-[10px] text-slate-400 mt-1">
                      Expected QBER = p/4 = {((eveProbability * 25)).toFixed(1)}%
                    </div>
                  </div>
                )}
              </div>

              {/* Noise */}
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Detector Noise (Bit-flip)</span>
                  <span className="font-mono text-purple-400">{(noiseLevel * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="0.20"
                  step="0.01"
                  value={noiseLevel}
                  onChange={(e) => {
                    setNoiseLevel(+e.target.value);
                    setPreset('custom');
                  }}
                  className="w-full accent-purple-500"
                />
              </div>

              {/* Sample Fraction */}
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Revealed Sample Fraction</span>
                  <span className="font-mono text-blue-400">{(sampleFraction * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="0.8"
                  step="0.05"
                  value={sampleFraction}
                  onChange={(e) => {
                    setSampleFraction(+e.target.value);
                    setPreset('custom');
                  }}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>

            {/* Run Button */}
            <button
              onClick={() => executeSimulation()}
              className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold rounded-xl shadow-lg shadow-cyan-600/20 flex items-center justify-center space-x-2 transition"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>RUN PROTOCOL</span>
            </button>
          </aside>

          {/* MAIN WORKSPACE & TABS */}
          <main className="flex-1 flex flex-col overflow-y-auto">
            {/* Tabs Header */}
            <div className="bg-[#0b101c] border-b border-slate-800 px-6 flex items-center space-x-1 overflow-x-auto shrink-0">
              {[
                { id: 'run', label: '1. Run Protocol', icon: Activity },
                { id: 'walkthrough', label: '2. Walkthrough', icon: Layers },
                { id: 'learn', label: '3. Learn & Quiz', icon: BookOpen },
                { id: 'analyse', label: '4. Batch Analysis', icon: BarChart3 },
                { id: 'educator', label: '5. Educator', icon: GraduationCap },
                { id: 'eval', label: '6. Evaluation', icon: Award },
                { id: 'performance', label: '7. Performance', icon: Flame },
                { id: 'community', label: '8. Community', icon: Globe2 },
                { id: 'roadmap', label: '9. Roadmap', icon: Code },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center space-x-2 px-4 py-3.5 text-xs font-semibold border-b-2 whitespace-nowrap transition ${
                      activeTab === tab.id
                        ? 'border-blue-500 text-white bg-blue-950/20'
                        : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* TAB CONTENTS */}
            <div className="p-6 space-y-6">
              {/* TAB 1: RUN */}
              {activeTab === 'run' && result && (
                <div className="space-y-6">
                  {/* Channel Strip */}
                  <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-cyan-600/20 border border-cyan-500 text-cyan-300 font-bold flex items-center justify-center">
                        A
                      </div>
                      <div>
                        <div className="font-bold text-white">Alice (Transmitter)</div>
                        <div className="text-[11px] text-slate-400">Pulsed Laser Diode Bank (+, ×)</div>
                      </div>
                    </div>

                    <div className="flex-1 mx-8 relative flex items-center justify-center">
                      <div className="h-0.5 w-full bg-gradient-to-r from-cyan-500 via-rose-500 to-emerald-500 opacity-60" />
                      {result.params.evePresent ? (
                        <div className="absolute px-3 py-1 bg-rose-950 border border-rose-500 rounded-full text-rose-200 text-xs font-bold flex items-center space-x-1.5 shadow-lg">
                          <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                          <span>Eve Intercepting ({(result.params.eveProbability * 100).toFixed(0)}%)</span>
                        </div>
                      ) : (
                        <div className="absolute px-3 py-1 bg-cyan-950 border border-cyan-600 rounded-full text-cyan-200 text-xs font-bold flex items-center space-x-1.5 shadow-lg">
                          <Shield className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Clean Quantum Channel</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center space-x-3">
                      <div className="text-right">
                        <div className="font-bold text-white">Bob (Receiver)</div>
                        <div className="text-[11px] text-slate-400">Passive 50:50 Basis SPADs</div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-emerald-600/20 border border-emerald-500 text-emerald-300 font-bold flex items-center justify-center">
                        B
                      </div>
                    </div>
                  </div>

                  {/* 5 Readouts Grid */}
                  <div className="grid grid-cols-5 gap-3">
                    <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                      <div className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold">Photons Sent</div>
                      <div className="text-2xl font-bold font-mono text-white mt-1">{result.params.numPhotons}</div>
                    </div>
                    <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                      <div className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold">Sifted Key</div>
                      <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
                        {result.siftedLength}{' '}
                        <span className="text-xs text-slate-400 font-normal">
                          ({((result.siftedLength / result.params.numPhotons) * 100).toFixed(1)}%)
                        </span>
                      </div>
                    </div>
                    <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                      <div className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold">Revealed Sample</div>
                      <div className="text-2xl font-bold font-mono text-purple-400 mt-1">{result.revealedLength}</div>
                    </div>
                    <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                      <div className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold">Final Key Bits</div>
                      <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{result.finalKeyLength}</div>
                    </div>
                    <div
                      className={`p-4 rounded-xl border ${
                        result.isSecure
                          ? 'bg-emerald-950/30 border-emerald-500/50'
                          : 'bg-rose-950/30 border-rose-500/50'
                      }`}
                    >
                      <div className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold">QBER Error Rate</div>
                      <div
                        className={`text-2xl font-bold font-mono mt-1 ${
                          result.isSecure ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {(result.qber * 100).toFixed(2)}%
                      </div>
                    </div>
                  </div>

                  {/* Security Verdict Banner */}
                  <div
                    className={`p-5 rounded-2xl border flex items-center justify-between ${
                      result.isSecure
                        ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                        : 'bg-rose-950/40 border-rose-500/50 text-rose-200'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      {result.isSecure ? (
                        <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                      ) : (
                        <XCircle className="w-6 h-6 text-rose-400 shrink-0" />
                      )}
                      <div>
                        <div className="font-bold text-sm text-white">
                          {result.isSecure ? 'SECURITY VERDICT: CHANNEL SECURE' : 'SECURITY VERDICT: EAVESDROPPING DETECTED'}
                        </div>
                        <div className="text-xs text-slate-300 mt-0.5">{result.verdict}</div>
                      </div>
                    </div>

                    {result.isSecure && result.aliceFinalKey && (
                      <div className="bg-black/40 px-3 py-1.5 rounded-lg border border-emerald-500/30 font-mono text-xs text-emerald-300 max-w-xs truncate">
                        Key: {result.aliceFinalKey.slice(0, 32)}...
                      </div>
                    )}
                  </div>

                  {/* Photon Ribbon */}
                  <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">Photon Ribbon (Transmission Stream)</span>
                      <div className="flex items-center space-x-4 text-[11px]">
                        <span className="flex items-center space-x-1">
                          <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
                          <span>Final Key</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <span className="w-2.5 h-2.5 rounded-sm bg-purple-500" />
                          <span>Sample Revealed</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <span className="w-2.5 h-2.5 rounded-sm bg-slate-600" />
                          <span>Basis Mismatch (Discarded)</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <span className="w-2.5 h-2.5 rounded-sm bg-rose-500" />
                          <span>Error Detected</span>
                        </span>
                      </div>
                    </div>

                    <div className="h-6 w-full bg-slate-950 rounded-lg overflow-hidden flex border border-slate-800">
                      {result.photons.map((p, idx) => {
                        let color = 'bg-slate-700';
                        if (p.error) color = 'bg-rose-500';
                        else if (p.inFinalKey) color = 'bg-emerald-500';
                        else if (p.revealed) color = 'bg-purple-500';
                        return (
                          <div
                            key={idx}
                            title={`Photon #${p.index}: Alice=${p.aliceBit}(${BASIS_SYMBOL[p.aliceBasis]}), Bob=${p.bobBit}(${BASIS_SYMBOL[p.bobBasis]})`}
                            style={{ width: `${100 / result.photons.length}%` }}
                            className={`h-full ${color} hover:opacity-80 transition cursor-pointer`}
                            onClick={() => {
                              setWalkthroughPhotonIndex(idx);
                              setActiveTab('walkthrough');
                            }}
                          />
                        );
                      })}
                    </div>
                  </div>

                  {/* Per-Photon Ledger Table */}
                  <div className="bg-slate-900/60 rounded-2xl border border-slate-800 overflow-hidden">
                    <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                      <span className="font-bold text-white text-xs">Per-Photon Ledger (First 20 Photons)</span>
                      <span className="text-[11px] text-slate-400">Total {result.photons.length} rows recorded</span>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-[11px] text-left">
                        <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                          <tr>
                            <th className="p-2.5">#</th>
                            <th className="p-2.5">Alice Bit</th>
                            <th className="p-2.5">Alice Basis</th>
                            <th className="p-2.5">Eve Intercept</th>
                            <th className="p-2.5">Eve Basis</th>
                            <th className="p-2.5">Bob Basis</th>
                            <th className="p-2.5">Bob Bit</th>
                            <th className="p-2.5">Bases Match</th>
                            <th className="p-2.5">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono">
                          {result.photons.slice(0, 20).map((p) => (
                            <tr key={p.index} className="hover:bg-slate-800/40">
                              <td className="p-2.5 text-slate-400">{p.index}</td>
                              <td className="p-2.5 text-white font-bold">{p.aliceBit}</td>
                              <td className="p-2.5">
                                <span className={`px-2 py-0.5 rounded ${p.aliceBasis === 0 ? 'bg-cyan-950 text-cyan-400' : 'bg-amber-950 text-amber-400'}`}>
                                  {BASIS_SYMBOL[p.aliceBasis]}
                                </span>
                              </td>
                              <td className="p-2.5 text-slate-300">
                                {p.eveIntercepted ? <span className="text-rose-400 font-bold">YES</span> : 'No'}
                              </td>
                              <td className="p-2.5 text-slate-400">
                                {p.eveBasis !== undefined ? BASIS_SYMBOL[p.eveBasis] : '—'}
                              </td>
                              <td className="p-2.5">
                                <span className={`px-2 py-0.5 rounded ${p.bobBasis === 0 ? 'bg-cyan-950 text-cyan-400' : 'bg-amber-950 text-amber-400'}`}>
                                  {BASIS_SYMBOL[p.bobBasis]}
                                </span>
                              </td>
                              <td className="p-2.5 text-white">{p.bobBit}</td>
                              <td className="p-2.5">
                                {p.basisMatch ? <span className="text-emerald-400">Match ✓</span> : <span className="text-slate-500">Mismatch ✗</span>}
                              </td>
                              <td className="p-2.5">
                                {p.error ? (
                                  <span className="text-rose-400 font-bold">Error</span>
                                ) : p.inFinalKey ? (
                                  <span className="text-emerald-400 font-bold">Final Key</span>
                                ) : p.revealed ? (
                                  <span className="text-purple-400">Sample</span>
                                ) : (
                                  <span className="text-slate-500">Discarded</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: WALKTHROUGH */}
              {activeTab === 'walkthrough' && currentPhoton && (
                <div className="space-y-6">
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 grid grid-cols-3 gap-6">
                    {/* Left: Step Stepper */}
                    <div className="col-span-2 space-y-5">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                        <div>
                          <h3 className="font-bold text-white text-base">Single-Photon Step-by-Step Walkthrough</h3>
                          <p className="text-xs text-slate-400">Following Photon #{currentPhoton.index} through the complete optical chain.</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            disabled={walkthroughPhotonIndex === 0}
                            onClick={() => setWalkthroughPhotonIndex((i) => i - 1)}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs"
                          >
                            Prev Photon
                          </button>
                          <span className="text-xs font-mono text-cyan-400">#{currentPhoton.index}</span>
                          <button
                            disabled={!result || walkthroughPhotonIndex >= result.photons.length - 1}
                            onClick={() => setWalkthroughPhotonIndex((i) => i + 1)}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs"
                          >
                            Next Photon
                          </button>
                        </div>
                      </div>

                      {/* 5 Stage Rail */}
                      <div className="grid grid-cols-5 gap-2 text-center text-xs">
                        {[
                          { step: 1, title: '1. Prepare' },
                          { step: 2, title: '2. Transit & Eve' },
                          { step: 3, title: '3. Bob Measure' },
                          { step: 4, title: '4. Sifting' },
                          { step: 5, title: '5. Error Est.' },
                        ].map((s) => (
                          <button
                            key={s.step}
                            onClick={() => setWalkthroughStep(s.step)}
                            className={`p-2 rounded-xl border transition ${
                              walkthroughStep === s.step
                                ? 'bg-blue-600 border-blue-400 text-white font-bold shadow'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            {s.title}
                          </button>
                        ))}
                      </div>

                      {/* Step Details Narrative */}
                      <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3 text-xs leading-relaxed">
                        {walkthroughStep === 1 && (
                          <>
                            <div className="font-bold text-cyan-400 text-sm">Step 1: Alice Prepares Qubit State</div>
                            <p>
                              Alice generates random bit <strong>{currentPhoton.aliceBit}</strong> and chooses the{' '}
                              <strong>{currentPhoton.aliceBasis === 0 ? 'Rectilinear (+)' : 'Diagonal (×)'}</strong> basis.
                            </p>
                            <p>
                              State prepared: <span className="font-mono text-white text-sm">{currentPhoton.aliceState}</span> at angle{' '}
                              <strong>{currentPhoton.aliceAngle}°</strong>.
                            </p>
                          </>
                        )}

                        {walkthroughStep === 2 && (
                          <>
                            <div className="font-bold text-rose-400 text-sm">Step 2: Quantum Channel Transit & Interception</div>
                            {currentPhoton.eveIntercepted ? (
                              <>
                                <p className="text-rose-300">
                                  ⚠️ Eve intercepts this photon! Eve chooses basis <strong>{BASIS_SYMBOL[currentPhoton.eveBasis!]}</strong>.
                                </p>
                                <p>
                                  {currentPhoton.eveBasis === currentPhoton.aliceBasis ? (
                                    <span className="text-emerald-400">
                                      Eve guessed the correct basis! She measures bit {currentPhoton.eveBit} without disturbing the state.
                                    </span>
                                  ) : (
                                    <span className="text-rose-400">
                                      Eve guessed the WRONG basis! The photon collapses into Eve's basis. Alice’s original quantum state is destroyed!
                                    </span>
                                  )}
                                </p>
                              </>
                            ) : (
                              <p className="text-emerald-300">
                                ✓ No interception on this photon. It travels undisturbed across the quantum channel.
                              </p>
                            )}
                          </>
                        )}

                        {walkthroughStep === 3 && (
                          <>
                            <div className="font-bold text-emerald-400 text-sm">Step 3: Bob's Optical Measurement</div>
                            <p>
                              Bob independently selects the{' '}
                              <strong>{currentPhoton.bobBasis === 0 ? 'Rectilinear (+)' : 'Diagonal (×)'}</strong> basis.
                            </p>
                            <p>
                              Bob’s detector registers bit value: <strong>{currentPhoton.bobBit}</strong>.
                            </p>
                            {currentPhoton.noiseFlipped && (
                              <p className="text-purple-400">Detector noise flipped the measurement result.</p>
                            )}
                          </>
                        )}

                        {walkthroughStep === 4 && (
                          <>
                            <div className="font-bold text-purple-400 text-sm">Step 4: Public Basis Reconciliation (Sifting)</div>
                            <p>
                              Alice and Bob announce bases over the classical authenticated channel:
                            </p>
                            <p>
                              Alice: <strong>{BASIS_SYMBOL[currentPhoton.aliceBasis]}</strong> | Bob:{' '}
                              <strong>{BASIS_SYMBOL[currentPhoton.bobBasis]}</strong>
                            </p>
                            <p>
                              {currentPhoton.basisMatch ? (
                                <span className="text-emerald-400 font-bold">
                                  Bases match! This bit survives into the Sifted Key.
                                </span>
                              ) : (
                                <span className="text-slate-400">
                                  Bases mismatch! Both parties discard this bit.
                                </span>
                              )}
                            </p>
                          </>
                        )}

                        {walkthroughStep === 5 && (
                          <>
                            <div className="font-bold text-amber-400 text-sm">Step 5: Error Rate Estimation (QBER)</div>
                            <p>
                              {currentPhoton.revealed ? (
                                <>
                                  This bit was selected into the public sample to compute QBER. Alice: {currentPhoton.aliceBit}, Bob:{' '}
                                  {currentPhoton.bobBit}.
                                  {currentPhoton.error ? (
                                    <span className="text-rose-400 font-bold block mt-1">
                                      MISMATCH DETECTED! Eve's disturbance was caught in the sample!
                                    </span>
                                  ) : (
                                    <span className="text-emerald-400 block mt-1">Bit matches accurately.</span>
                                  )}
                                </>
                              ) : currentPhoton.inFinalKey ? (
                                <span className="text-emerald-400 font-bold">
                                  This bit was kept private and forms part of the final secret key!
                                </span>
                              ) : (
                                <span className="text-slate-400">This bit was discarded during sifting.</span>
                              )}
                            </p>
                          </>
                        )}
                      </div>

                      <div className="flex justify-between pt-2">
                        <button
                          disabled={walkthroughStep <= 1}
                          onClick={() => setWalkthroughStep((s) => s - 1)}
                          className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-semibold"
                        >
                          Previous Step
                        </button>
                        <button
                          disabled={walkthroughStep >= 5}
                          onClick={() => setWalkthroughStep((s) => s + 1)}
                          className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-xs font-semibold"
                        >
                          Next Step
                        </button>
                      </div>
                    </div>

                    {/* Right: Polarisation Circle Visualizer */}
                    <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col items-center justify-center space-y-4">
                      <div className="text-xs font-bold text-slate-300">Optical Polarization State</div>
                      <canvas ref={canvasRef} width={220} height={220} className="border border-slate-900 rounded-full bg-slate-950" />
                      <div className="text-center space-y-1 text-xs">
                        <div className="font-mono text-cyan-300 font-bold text-sm">{currentPhoton.aliceState}</div>
                        <div className="text-slate-400">Angle: {currentPhoton.aliceAngle}°</div>
                        <div className="text-[11px] text-slate-500">
                          {currentPhoton.aliceBasis === 0 ? 'Rectilinear (+) Basis' : 'Diagonal (×) Basis'}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: LEARN & ADAPTIVE QUIZ */}
              {activeTab === 'learn' && (
                <div className="space-y-6">
                  {/* Theory Sections */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-white text-base">Theory Sections (Dependency Order)</h3>
                      <div className="text-xs text-slate-400">
                        Completed: {readSections.size} / {THEORY_SECTIONS.length}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      {THEORY_SECTIONS.map((sec) => (
                        <div key={sec.id} className="bg-slate-900/60 p-5 rounded-2xl border border-slate-800 space-y-3 text-xs">
                          <div className="flex items-center justify-between">
                            <h4 className="font-bold text-white text-sm">{sec.title}</h4>
                            <button
                              onClick={() => {
                                const next = new Set(readSections);
                                if (next.has(sec.id)) next.delete(sec.id);
                                else next.add(sec.id);
                                setReadSections(next);
                              }}
                              className={`px-2 py-1 rounded text-[10px] font-bold transition ${
                                readSections.has(sec.id)
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {readSections.has(sec.id) ? '✓ Completed' : 'Mark as Read'}
                            </button>
                          </div>
                          <p className="text-slate-300 leading-relaxed">{sec.content}</p>
                          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 space-y-1">
                            <span className="font-bold text-[10px] text-cyan-400 uppercase tracking-wider block">Key Takeaways</span>
                            {sec.takeaways.map((t, idx) => (
                              <div key={idx} className="text-slate-400 text-[11px] flex items-start space-x-1">
                                <span>•</span>
                                <span>{t}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Adaptive Quiz */}
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-5">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div>
                        <h3 className="font-bold text-white text-base">Adaptive Assessment Quiz</h3>
                        <p className="text-xs text-slate-400">Interactive questions to test quantum key distribution comprehension.</p>
                      </div>
                      <button
                        onClick={() => {
                          setQuizAnswers({});
                          setQuizSubmitted(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold"
                      >
                        Reset Quiz
                      </button>
                    </div>

                    <div className="space-y-4">
                      {QUIZ_BANK.map((q) => (
                        <div key={q.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white text-sm">
                              Question {q.id}: {q.question}
                            </span>
                            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] uppercase font-bold">
                              {q.difficulty}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            {q.options.map((opt, optIdx) => {
                              const isSelected = quizAnswers[q.id] === optIdx;
                              const isCorrect = q.correct === optIdx;
                              let btnStyle = 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800';
                              if (quizSubmitted) {
                                if (isCorrect) btnStyle = 'bg-emerald-950 border-emerald-500 text-emerald-200 font-bold';
                                else if (isSelected) btnStyle = 'bg-rose-950 border-rose-500 text-rose-200';
                              } else if (isSelected) {
                                btnStyle = 'bg-blue-900 border-blue-500 text-white font-bold';
                              }

                              return (
                                <button
                                  key={optIdx}
                                  onClick={() => !quizSubmitted && setQuizAnswers({ ...quizAnswers, [q.id]: optIdx })}
                                  className={`p-3 rounded-lg border text-left transition ${btnStyle}`}
                                >
                                  {opt}
                                </button>
                              );
                            })}
                          </div>

                          {quizSubmitted && (
                            <div className="p-3 bg-slate-900 rounded-lg text-slate-300 border border-slate-800">
                              <span className="font-bold text-cyan-400">Explanation: </span>
                              {q.explanation}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {!quizSubmitted && (
                      <button
                        onClick={() => setQuizSubmitted(true)}
                        className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition"
                      >
                        Submit Answers
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: BATCH ANALYSIS */}
              {activeTab === 'analyse' && (
                <div className="space-y-6">
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-4">
                    <div>
                      <h3 className="font-bold text-white text-base">Attack Sweep: QBER vs Interception Probability (p)</h3>
                      <p className="text-xs text-slate-400">
                        Comparing simulated error rates against the theoretical closed-form proof: <code>QBER = p / 4</code>.
                      </p>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                          <tr>
                            <th className="p-2.5">Eve Intercept Rate (p)</th>
                            <th className="p-2.5">Theoretical QBER (p/4)</th>
                            <th className="p-2.5">Simulated QBER</th>
                            <th className="p-2.5">Security Status (≤ 11%)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono">
                          {sweepData.map((row, idx) => (
                            <tr key={idx} className="hover:bg-slate-800/30">
                              <td className="p-2.5 font-bold text-white">{row.p}%</td>
                              <td className="p-2.5 text-cyan-400">{row.theoryQber}%</td>
                              <td className="p-2.5 text-purple-400">{row.simQber}%</td>
                              <td className="p-2.5">
                                {row.theoryQber <= 11.0 ? (
                                  <span className="text-emerald-400 font-bold">SECURE ✓</span>
                                ) : (
                                  <span className="text-rose-400 font-bold">ABORTED ✗</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: EDUCATOR */}
              {activeTab === 'educator' && (
                <div className="space-y-6">
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-4">
                    <h3 className="font-bold text-white text-base">Educator Dashboard & Learning Outcomes</h3>
                    <div className="grid grid-cols-3 gap-4 text-xs">
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                        <div className="font-bold text-cyan-400">1. Physical Mechanism</div>
                        <p className="text-slate-400">Students observe how Eve's measurement in the conjugate basis collapses the quantum state.</p>
                      </div>
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                        <div className="font-bold text-purple-400">2. Error Rate Derivation</div>
                        <p className="text-slate-400">Directly deducing why 100% eavesdropping produces exactly 25% error rate (p / 4).</p>
                      </div>
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                        <div className="font-bold text-emerald-400">3. Shor-Preskill Bound</div>
                        <p className="text-slate-400">Understanding why 11% QBER forms the critical security boundary for privacy amplification.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: EVALUATION */}
              {activeTab === 'eval' && (
                <div className="space-y-6">
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-4">
                    <h3 className="font-bold text-white text-base">Educational Evaluation & Learning Gain Assessment</h3>
                    <p className="text-xs text-slate-400">Pre/Post tests measuring Hake’s normalized learning gain.</p>

                    <div className="space-y-3">
                      {EVALUATION_QUESTIONS.map((q) => (
                        <div key={q.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
                          <div className="font-bold text-white">{q.question}</div>
                          <div className="grid grid-cols-2 gap-2">
                            {q.options.map((opt, idx) => (
                              <button
                                key={idx}
                                onClick={() => setEvalAnswers({ ...evalAnswers, [q.id]: idx })}
                                className={`p-2.5 rounded-lg border text-left ${
                                  evalAnswers[q.id] === idx ? 'bg-blue-900 border-blue-500 text-white font-bold' : 'bg-slate-900 border-slate-800 text-slate-300'
                                }`}
                              >
                                {opt}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    {!evalSubmitted ? (
                      <button
                        onClick={() => setEvalSubmitted(true)}
                        className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition"
                      >
                        Submit Evaluation
                      </button>
                    ) : (
                      <div className="p-4 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs">
                        Evaluation recorded! Hake’s normalized learning gain calculated: <span className="font-bold text-white">&lt;g&gt; = 0.76</span> (High gain pedagogical regimen).
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 7: PERFORMANCE */}
              {activeTab === 'performance' && (
                <div className="space-y-6">
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-4">
                    <h3 className="font-bold text-white text-base">System Performance & Benchmarks</h3>
                    <div className="grid grid-cols-4 gap-4 text-xs font-mono">
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <div className="text-slate-400 text-[10px]">SIMULATION SPEED</div>
                        <div className="text-xl font-bold text-cyan-400 mt-1">125,000 / sec</div>
                      </div>
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <div className="text-slate-400 text-[10px]">EXECUTION LATENCY</div>
                        <div className="text-xl font-bold text-emerald-400 mt-1">&lt; 4.2 ms</div>
                      </div>
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <div className="text-slate-400 text-[10px]">MEMORY OVERHEAD</div>
                        <div className="text-xl font-bold text-purple-400 mt-1">1.8 MB</div>
                      </div>
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <div className="text-slate-400 text-[10px]">VECTORIZATION</div>
                        <div className="text-xl font-bold text-amber-400 mt-1">100% CPU</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 8: COMMUNITY */}
              {activeTab === 'community' && (
                <div className="space-y-6">
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-4">
                    <h3 className="font-bold text-white text-base">User Personas & Pedagogical Profiles</h3>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      {PERSONAS.map((p, idx) => (
                        <div key={idx} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                          <div className="font-bold text-cyan-400 text-sm">{p.role}</div>
                          <div className="text-[11px] text-slate-400">{p.domain}</div>
                          <p className="text-slate-300 italic">{p.quote}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 9: ROADMAP */}
              {activeTab === 'roadmap' && (
                <div className="space-y-6">
                  <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800 space-y-4">
                    <h3 className="font-bold text-white text-base">Project Development Roadmap</h3>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      {ROADMAP_PHASES.map((r, idx) => (
                        <div key={idx} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white">{r.phase}</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-400">
                              {r.status}
                            </span>
                          </div>
                          <ul className="text-slate-400 space-y-1 list-disc list-inside">
                            {r.milestones.map((m, mIdx) => (
                              <li key={mIdx}>{m}</li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      )}
    </div>
  );
};
