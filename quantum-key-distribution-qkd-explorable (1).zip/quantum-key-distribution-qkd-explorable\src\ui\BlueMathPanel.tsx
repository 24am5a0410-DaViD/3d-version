import React, { useState } from 'react';
import { MathFormula } from './MathFormula';

export const BlueMathPanel: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="fixed bottom-4 right-4 z-40 max-w-[340px] w-full select-none transition-all duration-300">
      <div className="bg-[#1e5bbd] text-white shadow-2xl rounded-xl border border-blue-400/40 p-4 font-sans">
        <div className="space-y-1.5 text-xs text-white">
          <div className="text-center font-bold pb-1 text-sm tracking-wide">
            <MathFormula block math="|+\rangle = \frac{1}{\sqrt{2}}\begin{pmatrix}1\\1\end{pmatrix}" />
            <MathFormula block math="|-\rangle = \frac{1}{\sqrt{2}}\begin{pmatrix}1\\-1\end{pmatrix}" />
          </div>

          <div className="text-left text-[11px] leading-tight space-y-1 text-blue-50 font-mono">
            <div>
              <MathFormula block math="[M_+, M_0] = |+\rangle\langle+| |0\rangle\langle0| - |0\rangle\langle0| |+\rangle\langle+|" />
            </div>
            <div>
              <MathFormula block math="= \frac{1}{\sqrt{2}} (|+\rangle\langle 0| - |0\rangle\langle+|)" />
            </div>
            <div>
              <MathFormula block math="= \frac{1}{2}\begin{pmatrix}1\\1\end{pmatrix}\begin{pmatrix}1 & 0\end{pmatrix} - \frac{1}{2}\begin{pmatrix}1\\0\end{pmatrix}\begin{pmatrix}1 & 1\end{pmatrix}" />
            </div>
            <div>
              <MathFormula block math="= \frac{1}{2}\begin{pmatrix}1 & 0\\1 & 0\end{pmatrix} - \frac{1}{2}\begin{pmatrix}1 & 1\\0 & 0\end{pmatrix}" />
            </div>
            <div className="font-bold text-center pt-0.5 text-white">
              <MathFormula block math="= \frac{1}{2}\begin{pmatrix}0 & -1\\1 & 0\end{pmatrix} \neq 0" />
            </div>
          </div>

          {/* Exact pill button from Reference Image */}
          <div className="pt-2">
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="w-full bg-[#2563eb] hover:bg-[#1d4ed8] text-white font-bold py-2 px-4 rounded-lg shadow border border-blue-300/50 text-center text-sm tracking-wide uppercase transition"
            >
              Important for QKD
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
