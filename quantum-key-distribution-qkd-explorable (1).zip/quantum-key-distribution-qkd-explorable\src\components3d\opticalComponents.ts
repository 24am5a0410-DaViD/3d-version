import * as THREE from 'three';

/**
 * Optical Component 3D Factory.
 * Generates realistic, production-quality 3D optical lab and aerospace hardware
 * matching both Scene A (BB84 tabletop) and Scene B (Jinan-1 satellite link).
 */

export interface OpticalObjectUserData {
  id: string;
  name: string;
  subsystem: string;
  type: string;
  description: string;
  eli12: string;
  formulaLatex?: string;
  wavelengthNm?: number;
}

export class OpticalComponentFactory {
  // Shared materials
  public static tableMaterial = new THREE.MeshStandardMaterial({
    color: 0xc8ced6,
    roughness: 0.25,
    metalness: 0.85,
  });

  public static tableBaseMaterial = new THREE.MeshStandardMaterial({
    color: 0x111317,
    roughness: 0.6,
    metalness: 0.2,
  });

  public static blackMatteMaterial = new THREE.MeshStandardMaterial({
    color: 0x181a1f,
    roughness: 0.45,
    metalness: 0.25,
  });

  public static chromeMaterial = new THREE.MeshStandardMaterial({
    color: 0xdce2ec,
    roughness: 0.22,
    metalness: 0.86,
  });

  public static steelMaterial = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.2,
    metalness: 0.88,
  });

  public static brassMaterial = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    roughness: 0.25,
    metalness: 0.85,
  });

  public static cyanBSMaterial = new THREE.MeshPhysicalMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.6,
    roughness: 0.05,
    transmission: 0.85,
    ior: 1.5,
    side: THREE.DoubleSide,
  });

  public static magentaPBSMaterial = new THREE.MeshPhysicalMaterial({
    color: 0xec4899,
    transparent: true,
    opacity: 0.7,
    roughness: 0.05,
    transmission: 0.75,
    ior: 1.6,
  });

  /**
   * High-contrast 2D text rendered flat onto a mesh plane (for tables and floor legends).
   */
  static createFlatText(
    text: string,
    width: number,
    height: number,
    fontSize: number = 96,
    color: string = '#ffffff',
    fontStyle: string = 'normal',
    fontFamily: string = '"Inter", "Segoe UI", sans-serif'
  ): THREE.Mesh {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = color;
    ctx.font = `${fontStyle} 900 ${fontSize}px ${fontFamily}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 16, 128);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    const geom = new THREE.PlaneGeometry(width, height);
    const mat = new THREE.MeshBasicMaterial({
      map: texture,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.rotation.x = -Math.PI / 2;
    return mesh;
  }

  /**
   * Optical breadboard table with silver perforated grid top and black beveled perimeter.
   */
  static createBreadboard(width: number, depth: number, height: number = 0.35): THREE.Group {
    const group = new THREE.Group();

    // Black beveled lower base
    const baseGeom = new THREE.BoxGeometry(width + 0.15, height * 0.4, depth + 0.15);
    const base = new THREE.Mesh(baseGeom, this.tableBaseMaterial);
    base.position.y = height * 0.2;
    group.add(base);

    // Silver perforated metallic top plate
    const topGeom = new THREE.BoxGeometry(width, height * 0.6, depth);
    const top = new THREE.Mesh(topGeom, this.tableMaterial);
    top.position.y = height * 0.7;
    top.receiveShadow = true;
    group.add(top);

    // Fine grid of M6 optical holes
    const grid = new THREE.GridHelper(Math.max(width, depth), Math.round(Math.max(width, depth) * 4), 0x94a3b8, 0x64748b);
    grid.position.y = height + 0.002;
    grid.scale.set(width / Math.max(width, depth), 1, depth / Math.max(width, depth));
    group.add(grid);

    return group;
  }

  /**
   * Mounting post and collar
   */
  static createMountPost(height: number = 0.45, radius: number = 0.045): THREE.Group {
    const postGroup = new THREE.Group();
    const baseGeom = new THREE.CylinderGeometry(radius * 1.8, radius * 2.0, 0.06, 16);
    const baseMesh = new THREE.Mesh(baseGeom, this.chromeMaterial);
    baseMesh.position.y = 0.03;
    postGroup.add(baseMesh);

    const postGeom = new THREE.CylinderGeometry(radius, radius, height, 16);
    const postMesh = new THREE.Mesh(postGeom, this.chromeMaterial);
    postMesh.position.y = height / 2;
    postGroup.add(postMesh);

    return postGroup;
  }

  /**
   * Alice's Laser Source Block (Yellow/Gold cube with H, A, D, V and double arrows).
   * Exact matching of Reference Image: Top labels, directional gray aperture faceplate.
   */
  static createLaserSourceBlock(
    label: 'H' | 'A' | 'D' | 'V',
    facingOrColor?: '+X' | '-X' | '+Z' | '-Z' | number,
    colorHex?: number
  ): THREE.Group {
    const group = new THREE.Group();
    const size = 0.86;
    const opticalHeight = 0.50;

    let facing: '+X' | '-X' | '+Z' | '-Z' = '+X';
    let blockColor = colorHex ?? 0xf59e0b;

    if (typeof facingOrColor === 'number') {
      blockColor = facingOrColor;
    } else if (typeof facingOrColor === 'string') {
      facing = facingOrColor;
    }

    // Dark mounting base plate resting on breadboard
    const basePlateGeom = new THREE.BoxGeometry(size + 0.08, 0.07, size + 0.08);
    const basePlate = new THREE.Mesh(basePlateGeom, this.blackMatteMaterial);
    basePlate.position.y = 0.035;
    group.add(basePlate);

    // Cube body centered at opticalHeight
    const boxGeom = new THREE.BoxGeometry(size, size, size);
    const boxMat = new THREE.MeshStandardMaterial({
      color: blockColor,
      roughness: 0.28,
      metalness: 0.65,
    });
    const box = new THREE.Mesh(boxGeom, boxMat);
    box.position.y = opticalHeight;
    group.add(box);

    // Faceplate and aperture positioned according to facing direction
    const faceplateGroup = new THREE.Group();
    
    // Metallic Faceplate where beam exits
    const faceplateGeom = new THREE.PlaneGeometry(size * 0.88, size * 0.88);
    const faceplateMat = new THREE.MeshStandardMaterial({
      color: 0x64748b,
      roughness: 0.2,
      metalness: 0.85,
    });
    const faceplate = new THREE.Mesh(faceplateGeom, faceplateMat);
    faceplateGroup.add(faceplate);

    // Beam exit aperture bezel
    const apertureGeom = new THREE.CylinderGeometry(0.16, 0.16, 0.06, 24);
    const aperture = new THREE.Mesh(apertureGeom, this.blackMatteMaterial);
    aperture.rotation.x = Math.PI / 2;
    aperture.position.z = 0.03;
    faceplateGroup.add(aperture);

    // Glowing ruby emitter diode core inside aperture
    const coreGeom = new THREE.CircleGeometry(0.09, 16);
    const coreMat = new THREE.MeshBasicMaterial({ color: 0xff1e38 });
    const core = new THREE.Mesh(coreGeom, coreMat);
    core.position.z = 0.062;
    faceplateGroup.add(core);

    // Rotate and position faceplate group based on facing
    faceplateGroup.position.y = opticalHeight;
    if (facing === '+X') {
      faceplateGroup.rotation.y = Math.PI / 2;
      faceplateGroup.position.x = size / 2 + 0.002;
    } else if (facing === '-X') {
      faceplateGroup.rotation.y = -Math.PI / 2;
      faceplateGroup.position.x = -size / 2 - 0.002;
    } else if (facing === '+Z') {
      faceplateGroup.rotation.y = 0;
      faceplateGroup.position.z = size / 2 + 0.002;
    } else if (facing === '-Z') {
      faceplateGroup.rotation.y = Math.PI;
      faceplateGroup.position.z = -size / 2 - 0.002;
    }
    group.add(faceplateGroup);

    // Arrow symbol string mapping
    let arrowSymbol = '↔';
    if (label === 'A') arrowSymbol = '⤢';
    if (label === 'D') arrowSymbol = '↗';
    if (label === 'V') arrowSymbol = '↕';

    // Top face label (facing +Y)
    const canvasTop = document.createElement('canvas');
    canvasTop.width = 256;
    canvasTop.height = 256;
    const ctxT = canvasTop.getContext('2d')!;
    ctxT.clearRect(0, 0, 256, 256);
    ctxT.fillStyle = '#0f172a';
    ctxT.font = '900 110px "Inter", "Segoe UI", sans-serif';
    ctxT.textAlign = 'center';
    ctxT.textBaseline = 'middle';
    ctxT.fillText(label, 128, 88);
    ctxT.font = '900 80px "Inter", "Segoe UI", sans-serif';
    ctxT.fillText(arrowSymbol, 128, 185);

    const texTop = new THREE.CanvasTexture(canvasTop);
    texTop.minFilter = THREE.LinearFilter;
    const labelTop = new THREE.Mesh(
      new THREE.PlaneGeometry(0.68, 0.68),
      new THREE.MeshBasicMaterial({ map: texTop, transparent: true })
    );
    labelTop.rotation.x = -Math.PI / 2;
    labelTop.position.set(0, opticalHeight + size / 2 + 0.005, 0);
    group.add(labelTop);

    group.userData = {
      id: `laser_${label.toLowerCase()}`,
      name: `Alice's Laser [${label}]`,
      subsystem: 'alice',
      type: 'laser_source',
      description: `Generates coherent single-mode pulses prepared in the ${label} polarization state.`,
      eli12: `Shoots laser pulses vibrating in the '${label}' direction.`,
      formulaLatex: label === 'H' ? '|0\\rangle = |H\\rangle' : label === 'V' ? '|1\\rangle = |V\\rangle' : label === 'D' ? '|+\\rangle = \\frac{1}{\\sqrt{2}}(|0\\rangle + |1\\rangle)' : '|-\\rangle = \\frac{1}{\\sqrt{2}}(|0\\rangle - |1\\rangle)',
    } satisfies OpticalObjectUserData;

    return group;
  }

  /**
   * Optical Disc on Post (Polarizer, Filter, Iris, Wave Plate)
   */
  static createOpticalDisc(
    type: 'polarizer' | 'filter' | 'iris' | 'hwp',
    id: string = 'opt_disc'
  ): THREE.Group {
    const group = new THREE.Group();
    const opticalHeight = 0.50;
    group.add(this.createMountPost(opticalHeight - 0.05, 0.035));

    let discMat: THREE.Material;
    let isRing = false;

    if (type === 'polarizer') {
      discMat = new THREE.MeshPhysicalMaterial({
        color: 0x22c55e,
        transparent: true,
        opacity: 0.75,
        roughness: 0.08,
        transmission: 0.82,
      });
    } else if (type === 'filter') {
      discMat = new THREE.MeshPhysicalMaterial({
        color: 0x8b5cf6,
        transparent: true,
        opacity: 0.85,
        roughness: 0.08,
        transmission: 0.65,
      });
    } else if (type === 'iris') {
      isRing = true;
      discMat = new THREE.MeshStandardMaterial({
        color: 0xeab308,
        roughness: 0.3,
        metalness: 0.8,
      });
    } else {
      discMat = new THREE.MeshPhysicalMaterial({
        color: 0xf97316,
        transparent: true,
        opacity: 0.78,
        roughness: 0.08,
        transmission: 0.78,
      });
    }

    if (isRing) {
      const ringGeom = new THREE.TorusGeometry(0.22, 0.05, 16, 32);
      const ring = new THREE.Mesh(ringGeom, discMat);
      ring.position.y = opticalHeight;
      group.add(ring);
    } else {
      const discGeom = new THREE.CylinderGeometry(0.24, 0.24, 0.04, 32);
      const disc = new THREE.Mesh(discGeom, discMat);
      disc.rotation.x = Math.PI / 2;
      disc.position.y = opticalHeight;
      group.add(disc);

      const ringMount = new THREE.Mesh(
        new THREE.TorusGeometry(0.25, 0.025, 12, 32),
        this.brassMaterial
      );
      ringMount.position.y = opticalHeight;
      group.add(ringMount);
    }

    group.userData = {
      id,
      name: type === 'polarizer' ? 'Polarizer' : type === 'filter' ? 'Filter (F)' : type === 'iris' ? 'Iris (I)' : 'Half-Wave Plate (HWP)',
      subsystem: 'optics',
      type,
      description: `Precision passive optical element: ${type.toUpperCase()}.`,
      eli12: `Filters or shapes the light wave as it travels through the optical table.`,
    } satisfies OpticalObjectUserData;

    return group;
  }

  /** Alias for waveplates */
  static createWavePlate(id: string = 'hwp', isQuarter: boolean = false): THREE.Group {
    return this.createOpticalDisc(isQuarter ? 'filter' : 'hwp', id);
  }

  /**
   * 50:50 Non-Polarizing Beam Splitter (NPBS) Cubic Prism (Cyan translucent cube).
   */
  static createBeamSplitterCube(id: string = 'bs'): THREE.Group {
    const group = new THREE.Group();
    const size = 0.74;
    const opticalHeight = 0.50;

    // Dark pedestal mount
    const baseGeom = new THREE.CylinderGeometry(0.40, 0.44, 0.12, 24);
    const base = new THREE.Mesh(baseGeom, this.blackMatteMaterial);
    base.position.y = 0.06;
    group.add(base);

    const cubeGeom = new THREE.BoxGeometry(size, size, size);
    const cube = new THREE.Mesh(cubeGeom, this.cyanBSMaterial);
    cube.position.y = opticalHeight;
    group.add(cube);

    const diagGeom = new THREE.PlaneGeometry(size * Math.SQRT2, size);
    const diagMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
    });
    const diag = new THREE.Mesh(diagGeom, diagMat);
    diag.rotation.y = Math.PI / 4;
    diag.position.y = opticalHeight;
    group.add(diag);

    group.userData = {
      id,
      name: '50:50 Non-Polarizing Beam Splitter (BS)',
      subsystem: 'optics',
      type: 'beam_splitter',
      description: '50:50 Non-Polarizing Beam Splitter (NPBS) cubic prism. Combines independent beam trajectories into a single coaxial TEM00 optical path without spatial mode mismatch.',
      eli12: 'Half-silvered optical cube combining or splitting laser paths with equal probability.',
      formulaLatex: 'U_{BS} = \\frac{1}{\\sqrt{2}}\\begin{pmatrix} 1 & i \\\\ i & 1 \\end{pmatrix}',
    } satisfies OpticalObjectUserData;

    return group;
  }

  static createBeamSplitterPlate(id: string = 'bs'): THREE.Group {
    return this.createBeamSplitterCube(id);
  }

  static createBeamSplitter(id: string = 'bs'): THREE.Group {
    return this.createBeamSplitterCube(id);
  }

  /**
   * Modulation Chain Block (AM, PM, AM black cubes with dual gold pins).
   */
  static createModulator(label: 'AM' | 'PM', idOrIndex: string | number = 1): THREE.Group {
    const group = new THREE.Group();
    const size = 0.82;
    const opticalHeight = 0.50;
    const id = typeof idOrIndex === 'number' ? `${label.toLowerCase()}${idOrIndex}` : idOrIndex;

    // Dark mounting base plate
    const baseGeom = new THREE.BoxGeometry(size + 0.08, 0.08, size + 0.08);
    const base = new THREE.Mesh(baseGeom, this.blackMatteMaterial);
    base.position.y = 0.04;
    group.add(base);

    // Matte black cube body
    const bodyGeom = new THREE.BoxGeometry(size, size, size);
    const body = new THREE.Mesh(bodyGeom, this.blackMatteMaterial);
    body.position.y = opticalHeight;
    group.add(body);

    // Two vertical golden RF pins on top (exact Image 2 detail!)
    for (const offset of [-0.14, 0.14]) {
      const pinGeom = new THREE.CylinderGeometry(0.03, 0.03, 0.28, 12);
      const pin = new THREE.Mesh(pinGeom, this.brassMaterial);
      pin.position.set(0, opticalHeight + size / 2 + 0.14, offset);
      group.add(pin);
    }

    // Front white bold label: AM or PM
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 0, 128, 128);
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 68px "Inter", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, 64, 64);

    const texture = new THREE.CanvasTexture(canvas);
    const labelMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(0.55, 0.55),
      new THREE.MeshBasicMaterial({ map: texture })
    );
    labelMesh.position.set(0, opticalHeight, size / 2 + 0.005);
    group.add(labelMesh);

    group.userData = {
      id,
      name: `${label === 'AM' ? 'Amplitude Modulator' : 'Phase Modulator'} (${label})`,
      subsystem: 'alice',
      type: label === 'AM' ? 'amplitude_modulator' : 'phase_modulator',
      description: label === 'AM'
        ? 'Electro-optic attenuator: attenuates laser pulses down to mean photon number μ ≈ 0.5.'
        : 'Electro-optic phase modulator: imparts phase shift φ.',
      eli12: label === 'AM'
        ? 'Dims the bright laser until single photons pass through one at a time.'
        : 'Adjusts the phase of the quantum wave.',
      formulaLatex: label === 'AM'
        ? 'J_{AM}(T) = \\begin{pmatrix} \\sqrt{T} & 0 \\\\ 0 & \\sqrt{T} \\end{pmatrix}'
        : 'J_{PM}(\\phi) = \\begin{pmatrix} e^{i\\phi} & 0 \\\\ 0 & 1 \\end{pmatrix}',
    } satisfies OpticalObjectUserData;

    return group;
  }

  /**
   * Polarizing Beam Splitter (PBS) - Magenta cubic prism
   */
  static createPBS(id: string = 'pbs'): THREE.Group {
    const group = new THREE.Group();
    const size = 0.75;
    const opticalHeight = 0.50;

    // Dark pedestal mount
    const baseGeom = new THREE.CylinderGeometry(0.40, 0.44, 0.12, 24);
    const base = new THREE.Mesh(baseGeom, this.blackMatteMaterial);
    base.position.y = 0.06;
    group.add(base);

    const cubeGeom = new THREE.BoxGeometry(size, size, size);
    const cube = new THREE.Mesh(cubeGeom, this.magentaPBSMaterial);
    cube.position.y = opticalHeight;
    group.add(cube);

    const diagGeom = new THREE.PlaneGeometry(size * Math.SQRT2, size);
    const diagMat = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      transparent: true,
      opacity: 0.8,
      side: THREE.DoubleSide,
    });
    const diag = new THREE.Mesh(diagGeom, diagMat);
    diag.rotation.y = Math.PI / 4;
    diag.position.y = opticalHeight;
    group.add(diag);

    group.userData = {
      id,
      name: 'Polarizing Beam Splitter (PBS)',
      subsystem: 'bob',
      type: 'polarizing_beam_splitter',
      description: 'Transmits horizontal polarization (H) and reflects vertical polarization (V).',
      eli12: 'Splits light waves: horizontal light goes straight, vertical bounces sideways.',
      formulaLatex: 'P_H = |0\\rangle\\langle 0|, \\quad P_V = |1\\rangle\\langle 1|',
    } satisfies OpticalObjectUserData;

    return group;
  }

  /**
   * Bob's SPAD Detector (Bullet-shaped polished chrome cylinder from Image 2).
   * Forward aperture faces +Z, rear rounded chrome dome points towards -Z.
   */
  static createSPAD(id: string = 'spad'): THREE.Group {
    const group = new THREE.Group();
    const opticalHeight = 0.50;
    const radius = 0.25;
    const bodyHeight = 0.60;

    // Metallic mounting post under SPAD
    const postHeight = opticalHeight - radius;
    const collarGeom = new THREE.CylinderGeometry(0.08, 0.12, postHeight, 16);
    const collar = new THREE.Mesh(collarGeom, this.blackMatteMaterial);
    collar.position.y = postHeight / 2;
    group.add(collar);

    // Polished chrome cylinder body
    const bodyGeom = new THREE.CylinderGeometry(radius, radius, bodyHeight, 32);
    const body = new THREE.Mesh(bodyGeom, this.chromeMaterial);
    body.rotation.x = Math.PI / 2;
    body.position.y = opticalHeight;
    group.add(body);

    // Rounded hemispherical dome cap at REAR (-Z)
    const domeGeom = new THREE.SphereGeometry(radius, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const dome = new THREE.Mesh(domeGeom, this.chromeMaterial);
    dome.rotation.x = Math.PI / 2;
    dome.position.set(0, opticalHeight, -bodyHeight / 2);
    group.add(dome);

    // Front aperture rim (+Z)
    const rimGeom = new THREE.RingGeometry(0.12, radius, 32);
    const rim = new THREE.Mesh(rimGeom, this.chromeMaterial);
    rim.position.set(0, opticalHeight, bodyHeight / 2 + 0.001);
    group.add(rim);

    // Recessed dark optical cavity at front (+Z)
    const cavityGeom = new THREE.CircleGeometry(0.12, 24);
    const cavity = new THREE.Mesh(cavityGeom, this.blackMatteMaterial);
    cavity.position.set(0, opticalHeight, bodyHeight / 2 + 0.001);
    group.add(cavity);

    // Glowing ruby photodiode sensor core
    const sensorCoreGeom = new THREE.CircleGeometry(0.06, 16);
    const sensorCoreMat = new THREE.MeshBasicMaterial({ color: 0xff1e38 });
    const sensorCore = new THREE.Mesh(sensorCoreGeom, sensorCoreMat);
    sensorCore.position.set(0, opticalHeight, bodyHeight / 2 + 0.002);
    group.add(sensorCore);

    group.userData = {
      id,
      name: "Bob's SPAD Detector",
      subsystem: 'bob',
      type: 'spad_detector',
      description: 'Single-Photon Avalanche Diode operated in Geiger mode for picosecond timing.',
      eli12: 'Ultra-sensitive photon detector that clicks every time a single photon arrives.',
      formulaLatex: 'P_{click} = 1 - e^{-\\eta \\cdot n}',
    } satisfies OpticalObjectUserData;

    return group;
  }

  /**
   * Fast Steering Mirror (FSM)
   */
  static createFSM(id: string = 'fsm'): THREE.Group {
    const group = new THREE.Group();
    group.add(this.createMountPost(0.4, 0.05));

    const stageGeom = new THREE.CylinderGeometry(0.28, 0.3, 0.18, 16);
    const stage = new THREE.Mesh(stageGeom, this.blackMatteMaterial);
    stage.position.y = 0.45;
    group.add(stage);

    const mirrorGeom = new THREE.CylinderGeometry(0.24, 0.24, 0.04, 32);
    const mirrorMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.05, metalness: 0.98 });
    const mirror = new THREE.Mesh(mirrorGeom, mirrorMat);
    mirror.position.set(0, 0.58, 0);
    mirror.rotation.set(Math.PI / 4, 0, 0);
    group.add(mirror);

    group.userData = {
      id,
      name: 'Fast Steering Mirror (FSM)',
      subsystem: 'optics',
      type: 'fast_steering_mirror',
      description: 'Piezo tip-tilt mirror for fine beam tracking.',
      eli12: 'Fast robotic mirror compensating vibration.',
    } satisfies OpticalObjectUserData;

    return group;
  }

  /**
   * Telescope (Satellite transmitter or Ground receiver)
   */
  static createTelescope(isSatellite: boolean = true): THREE.Group {
    const group = new THREE.Group();
    const scale = isSatellite ? 1.0 : 1.6;

    const barrelGeom = new THREE.CylinderGeometry(0.9 * scale, 0.95 * scale, 1.8 * scale, 32, 1, true);
    const barrelMat = new THREE.MeshStandardMaterial({
      color: isSatellite ? 0xd0d5dd : 0x1e293b,
      roughness: 0.3,
      metalness: 0.8,
      side: THREE.DoubleSide,
    });
    const barrel = new THREE.Mesh(barrelGeom, barrelMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.y = 1.0 * scale;
    group.add(barrel);

    const mirrorGeom = new THREE.CylinderGeometry(0.85 * scale, 0.85 * scale, 0.1 * scale, 32);
    const mirrorMat = new THREE.MeshStandardMaterial({ color: 0xeeeeee, roughness: 0.02, metalness: 0.99 });
    const mirror = new THREE.Mesh(mirrorGeom, mirrorMat);
    mirror.rotation.x = Math.PI / 2;
    mirror.position.set(0, 1.0 * scale, -0.85 * scale);
    group.add(mirror);

    group.userData = {
      id: isSatellite ? 'sat_telescope' : 'ground_telescope',
      name: isSatellite ? 'Satellite Optical Transmitter (180mm)' : 'Ground Station Telescope (1000mm)',
      subsystem: isSatellite ? 'satellite' : 'ground',
      type: 'telescope',
      description: isSatellite ? '180mm Cassegrain transmitter.' : '1000mm Cassegrain optical antenna.',
      eli12: 'Telescope focusing or collecting laser light.',
    } satisfies OpticalObjectUserData;

    return group;
  }

  /**
   * Tracking Camera (CAM1-CAM4)
   */
  static createTrackingCamera(id: string = 'cam'): THREE.Group {
    const group = new THREE.Group();
    group.add(this.createMountPost(0.35, 0.05));

    const bodyGeom = new THREE.BoxGeometry(0.45, 0.45, 0.6);
    const body = new THREE.Mesh(bodyGeom, this.steelMaterial);
    body.position.y = 0.5;
    group.add(body);

    const lensGeom = new THREE.CylinderGeometry(0.16, 0.16, 0.35, 20);
    const lens = new THREE.Mesh(lensGeom, this.blackMatteMaterial);
    lens.rotation.x = Math.PI / 2;
    lens.position.set(0, 0.5, 0.4);
    group.add(lens);

    group.userData = {
      id,
      name: `Acquisition Camera (${id.toUpperCase()})`,
      subsystem: 'optics',
      type: 'camera_tracker',
      description: 'Camera sensor tracking beacon spots.',
      eli12: 'Digital eye guiding the steering mirror.',
    } satisfies OpticalObjectUserData;

    return group;
  }
}
