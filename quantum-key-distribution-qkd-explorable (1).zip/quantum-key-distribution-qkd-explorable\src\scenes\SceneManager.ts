import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';

import { BB84BenchScene } from './BB84BenchScene';
import { SatelliteScene, SatelliteViewMode } from './SatelliteScene';
import { BlochSphereScene } from './BlochSphereScene';
import { OpticalObjectUserData } from '../components3d/opticalComponents';
import { Vector2 } from '../core/math/vector2';

export type ActiveSceneId = 'bb84' | 'satellite' | 'bloch';

export interface SceneManagerCallbacks {
  onSelectComponent: (data: OpticalObjectUserData | null) => void;
}

export class SceneManager {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private composer: EffectComposer;
  private bloomPass: UnrealBloomPass;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private raycaster: THREE.Raycaster;
  private mouse: THREE.Vector2;

  private rootScene: THREE.Scene;
  public bb84Scene: BB84BenchScene;
  public satelliteScene: SatelliteScene;
  public blochScene: BlochSphereScene;

  private currentSceneId: ActiveSceneId = 'bb84';
  private callbacks: SceneManagerCallbacks;
  private clock: THREE.Clock;
  private animationFrameId: number | null = null;

  constructor(container: HTMLElement, callbacks: SceneManagerCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.clock = new THREE.Clock();
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2(-1000, -1000);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    container.appendChild(this.renderer.domElement);

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 7.5, 12.0);

    // Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2 + 0.05; // Prevent flipping under ground

    // Root Scene & Lighting
    this.rootScene = new THREE.Scene();
    this.rootScene.background = new THREE.Color(0x141820);

    // Ambient light
    const ambient = new THREE.AmbientLight(0xdbeafe, 0.9);
    this.rootScene.add(ambient);

    // Key directional light (top-left studio light)
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
    keyLight.position.set(-4, 16, 12);
    this.rootScene.add(keyLight);

    // Fill light with subtle blue tint
    const fillLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    fillLight.position.set(12, 10, -8);
    this.rootScene.add(fillLight);

    // Secondary rim light from behind
    const rimLight = new THREE.DirectionalLight(0xfff7ed, 0.8);
    rimLight.position.set(-10, 8, -12);
    this.rootScene.add(rimLight);

    // Instantiate Subscenes
    this.bb84Scene = new BB84BenchScene();
    this.satelliteScene = new SatelliteScene();
    this.blochScene = new BlochSphereScene();

    this.rootScene.add(this.bb84Scene.scene);
    this.rootScene.add(this.satelliteScene.scene);
    this.rootScene.add(this.blochScene.scene);

    // Post-processing Bloom Pass
    const renderPass = new RenderPass(this.rootScene, this.camera);
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(width, height),
      0.55, // strength - subtle glow for beams and optics without blowing out text
      0.22, // radius
      0.82  // threshold
    );

    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(renderPass);
    this.composer.addPass(this.bloomPass);

    // Events
    window.addEventListener('resize', this.onResize);
    this.renderer.domElement.addEventListener('mousemove', this.onMouseMove);
    this.renderer.domElement.addEventListener('click', this.onClick);

    this.setScene('bb84');
    this.startLoop();
  }

  public setScene(sceneId: ActiveSceneId): void {
    this.currentSceneId = sceneId;
    this.bb84Scene.scene.visible = sceneId === 'bb84';
    this.satelliteScene.scene.visible = sceneId === 'satellite';
    this.blochScene.scene.visible = sceneId === 'bloch';

    // Camera viewpoints for each scene matching straight reference layout
    if (sceneId === 'bb84') {
      this.camera.fov = 37;
      this.camera.position.set(-0.6, 6.8, 13.2);
      this.controls.target.set(0.2, 0.4, 0.0);
      this.camera.updateProjectionMatrix();
    } else if (sceneId === 'satellite') {
      this.camera.position.set(0, 10, 24);
      this.controls.target.set(0, 2, 0);
    } else if (sceneId === 'bloch') {
      this.camera.position.set(0, 2, 6.5);
      this.controls.target.set(0, 0, 0);
    }
    this.controls.update();
  }

  public setSatelliteZoom(mode: SatelliteViewMode): void {
    this.satelliteScene.setViewMode(mode);
    if (mode === 'orbit') {
      this.camera.position.set(0, 10, 24);
      this.controls.target.set(0, 2, 0);
    } else if (mode === 'payload') {
      this.camera.position.set(50, 5, 8);
      this.controls.target.set(50, 0.5, 0);
    } else if (mode === 'ground') {
      this.camera.position.set(-50, 6, 9);
      this.controls.target.set(-50, 0.5, 0);
    } else if (mode === 'fiber') {
      this.camera.position.set(0, 55, 7);
      this.controls.target.set(0, 50, 0);
    }
    this.controls.update();
  }

  public setBlochState(vec: Vector2): void {
    this.blochScene.setStateVector(vec);
  }

  private onResize = (): void => {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.composer.setSize(width, height);
  };

  private onMouseMove = (event: MouseEvent): void => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  };

  private onClick = (): void => {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    let targets: THREE.Object3D[] = [];
    if (this.currentSceneId === 'bb84') targets = this.bb84Scene.getInteractiveObjects();
    else if (this.currentSceneId === 'satellite') targets = this.satelliteScene.getInteractiveObjects();

    const intersects = this.raycaster.intersectObjects(targets, true);
    if (intersects.length > 0) {
      let curr: THREE.Object3D | null = intersects[0].object;
      while (curr && !curr.userData?.id && curr.parent) {
        curr = curr.parent;
      }
      if (curr && curr.userData?.id) {
        this.callbacks.onSelectComponent(curr.userData as OpticalObjectUserData);
        return;
      }
    }
    this.callbacks.onSelectComponent(null);
  };

  private startLoop(): void {
    const tick = () => {
      this.animationFrameId = requestAnimationFrame(tick);
      const delta = this.clock.getDelta();
      const time = this.clock.getElapsedTime();

      this.controls.update();

      if (this.currentSceneId === 'bb84') {
        this.bb84Scene.update(time, delta);
      } else if (this.currentSceneId === 'satellite') {
        this.satelliteScene.update(time, delta);
      } else if (this.currentSceneId === 'bloch') {
        this.blochScene.update(time);
      }

      this.composer.render();
    };
    tick();
  }

  public dispose(): void {
    if (this.animationFrameId !== null) cancelAnimationFrame(this.animationFrameId);
    window.removeEventListener('resize', this.onResize);
    this.renderer.domElement.removeEventListener('mousemove', this.onMouseMove);
    this.renderer.domElement.removeEventListener('click', this.onClick);
    this.renderer.dispose();
  }
}
