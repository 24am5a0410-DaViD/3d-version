import { Complex } from './complex';

/**
 * 2x2 Complex Matrix for Jones Calculus & Quantum Measurement Operators.
 * Matrix layout:
 * [ [m00, m01],
 *   [m10, m11] ]
 */
export class Matrix2x2 {
  readonly m00: Complex;
  readonly m01: Complex;
  readonly m10: Complex;
  readonly m11: Complex;

  constructor(
    m00: Complex = Complex.ZERO,
    m01: Complex = Complex.ZERO,
    m10: Complex = Complex.ZERO,
    m11: Complex = Complex.ZERO
  ) {
    this.m00 = m00;
    this.m01 = m01;
    this.m10 = m10;
    this.m11 = m11;
  }

  static fromReals(a: number, b: number, c: number, d: number): Matrix2x2 {
    return new Matrix2x2(
      new Complex(a, 0),
      new Complex(b, 0),
      new Complex(c, 0),
      new Complex(d, 0)
    );
  }

  static readonly IDENTITY = new Matrix2x2(Complex.ONE, Complex.ZERO, Complex.ZERO, Complex.ONE);
  static readonly ZERO = new Matrix2x2(Complex.ZERO, Complex.ZERO, Complex.ZERO, Complex.ZERO);

  // Pauli Matrices
  static readonly SIGMA_X = new Matrix2x2(Complex.ZERO, Complex.ONE, Complex.ONE, Complex.ZERO);
  static readonly SIGMA_Y = new Matrix2x2(Complex.ZERO, new Complex(0, -1), new Complex(0, 1), Complex.ZERO);
  static readonly SIGMA_Z = new Matrix2x2(Complex.ONE, Complex.ZERO, Complex.ZERO, new Complex(-1, 0));

  // Hadamard
  static readonly HADAMARD = new Matrix2x2(
    new Complex(1 / Math.SQRT2, 0),
    new Complex(1 / Math.SQRT2, 0),
    new Complex(1 / Math.SQRT2, 0),
    new Complex(-1 / Math.SQRT2, 0)
  );

  add(other: Matrix2x2): Matrix2x2 {
    return new Matrix2x2(
      this.m00.add(other.m00),
      this.m01.add(other.m01),
      this.m10.add(other.m10),
      this.m11.add(other.m11)
    );
  }

  sub(other: Matrix2x2): Matrix2x2 {
    return new Matrix2x2(
      this.m00.sub(other.m00),
      this.m01.sub(other.m01),
      this.m10.sub(other.m10),
      this.m11.sub(other.m11)
    );
  }

  scale(scalar: number | Complex): Matrix2x2 {
    const s = typeof scalar === 'number' ? new Complex(scalar, 0) : scalar;
    return new Matrix2x2(
      this.m00.mul(s),
      this.m01.mul(s),
      this.m10.mul(s),
      this.m11.mul(s)
    );
  }

  mul(other: Matrix2x2): Matrix2x2 {
    return new Matrix2x2(
      this.m00.mul(other.m00).add(this.m01.mul(other.m10)),
      this.m00.mul(other.m01).add(this.m01.mul(other.m11)),
      this.m10.mul(other.m00).add(this.m11.mul(other.m10)),
      this.m10.mul(other.m01).add(this.m11.mul(other.m11))
    );
  }

  /** Conjugate Transpose (Hermitian Adjoint M†) */
  dagger(): Matrix2x2 {
    return new Matrix2x2(
      this.m00.conj(),
      this.m10.conj(),
      this.m01.conj(),
      this.m11.conj()
    );
  }

  trace(): Complex {
    return this.m00.add(this.m11);
  }

  /**
   * Commutator: [A, B] = A * B - B * A
   * Central to QKD: if [M_+, M_0] != 0, the two observables cannot be measured simultaneously.
   */
  static commutator(A: Matrix2x2, B: Matrix2x2): Matrix2x2 {
    return A.mul(B).sub(B.mul(A));
  }

  /**
   * Anti-commutator: {A, B} = A * B + B * A
   */
  static antiCommutator(A: Matrix2x2, B: Matrix2x2): Matrix2x2 {
    return A.mul(B).add(B.mul(A));
  }

  equals(other: Matrix2x2, tolerance: number = 1e-6): boolean {
    return (
      this.m00.equals(other.m00, tolerance) &&
      this.m01.equals(other.m01, tolerance) &&
      this.m10.equals(other.m10, tolerance) &&
      this.m11.equals(other.m11, tolerance)
    );
  }

  isZero(tolerance: number = 1e-6): boolean {
    return (
      this.m00.abs() <= tolerance &&
      this.m01.abs() <= tolerance &&
      this.m10.abs() <= tolerance &&
      this.m11.abs() <= tolerance
    );
  }

  toLatex(decimals: number = 2): string {
    const fmt = (c: Complex) => {
      if (Math.abs(c.i) < 1e-5) return c.r.toFixed(decimals).replace(/\.00$/, '');
      if (Math.abs(c.r) < 1e-5) return `${c.i < 0 ? '-' : ''}${Math.abs(c.i).toFixed(decimals)}i`;
      return `${c.r.toFixed(decimals)}${c.i >= 0 ? '+' : ''}${c.i.toFixed(decimals)}i`;
    };
    return `\\begin{pmatrix} ${fmt(this.m00)} & ${fmt(this.m01)} \\\\ ${fmt(this.m10)} & ${fmt(this.m11)} \\end{pmatrix}`;
  }
}
