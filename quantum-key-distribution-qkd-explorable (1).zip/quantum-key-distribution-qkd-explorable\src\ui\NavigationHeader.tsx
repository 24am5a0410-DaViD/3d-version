import React from 'react';
import { useAppStore } from '../state/store';
import { CURRICULUM } from '../lessons/curriculum';
import { 
  Atom, 
  Satellite, 
  Orbit, 
  Cpu, 
  ChevronLeft, 
  ChevronRight, 
  HelpCircle,
  RotateCcw
} from 'lucide-react';

export const NavigationHeader: React.FC = () => {
  const { 
    currentLessonId, 
    setLesson, 
    activeSceneId, 
    setScene,
    satelliteZoomMode,
    setSatelliteZoom,
    setQuizModalOpen,
    resetProtocol
  } = useAppStore();

  const currentLesson = CURRICULUM[currentLessonId] || CURRICULUM[0];

  const handlePrevLesson = () => {
    if (currentLessonId > 0) {
      const nextId = currentLessonId - 1;
      setLesson(nextId);
      setScene(CURRICULUM[nextId].sceneId);
      if (CURRICULUM[nextId].satelliteView) {
        setSatelliteZoom(CURRICULUM[nextId].satelliteView!);
      }
    }
  };

  const handleNextLesson = () => {
    if (currentLessonId < CURRICULUM.length - 1) {
      const nextId = currentLessonId + 1;
      setLesson(nextId);
      setScene(CURRICULUM[nextId].sceneId);
      if (CURRICULUM[nextId].satelliteView) {
        setSatelliteZoom(CURRICULUM[nextId].satelliteView!);
      }
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#0b1120]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5 flex items-center justify-between text-slate-200">
      {/* Brand & Title */}
      <div className="flex items-center space-x-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
          <Atom className="w-5 h-5 text-white animate-spin-slow" />
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="font-bold text-sm tracking-wide text-white">Quantum Key Distribution (QKD)</h1>
            <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-700/50">
              Interactive 3D
            </span>
          </div>
          <p className="text-xs text-slate-400 hidden sm:block">
            BB84 Tabletop & Satellite-to-Ground Explorable
          </p>
        </div>
      </div>

      {/* Center: Scene Switcher & Satellite Presets */}
      <div className="flex items-center space-x-2 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
        <button
          onClick={() => setScene('bb84')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
            activeSceneId === 'bb84'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>Scene A: BB84 Bench</span>
        </button>

        <button
          onClick={() => setScene('satellite')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
            activeSceneId === 'satellite'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Satellite className="w-3.5 h-3.5" />
          <span>Scene B: Satellite Link</span>
        </button>

        <button
          onClick={() => setScene('bloch')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
            activeSceneId === 'bloch'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Orbit className="w-3.5 h-3.5" />
          <span>Bloch Sphere</span>
        </button>

        {/* Satellite zoom presets when Satellite scene is active */}
        {activeSceneId === 'satellite' && (
          <div className="flex items-center space-x-1 pl-2 border-l border-slate-700/80">
            {(['orbit', 'payload', 'fiber', 'ground'] as const).map((view) => (
              <button
                key={view}
                onClick={() => setSatelliteZoom(view)}
                className={`px-2 py-1 rounded text-[11px] uppercase tracking-wider font-semibold transition ${
                  satelliteZoomMode === view
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {view}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Right: Lesson Stepper & Actions */}
      <div className="flex items-center space-x-2">
        {/* Lesson Stepper */}
        <div className="flex items-center space-x-1 bg-slate-900/80 px-2 py-1 rounded-xl border border-slate-800">
          <button
            onClick={handlePrevLesson}
            disabled={currentLessonId === 0}
            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 transition"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="text-xs font-semibold px-2 text-cyan-300">
            Module {currentLesson.id}: {currentLesson.title}
          </span>

          <button
            onClick={handleNextLesson}
            disabled={currentLessonId === CURRICULUM.length - 1}
            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400 transition"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Take Quiz Button */}
        <button
          onClick={() => setQuizModalOpen(true)}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-purple-600/30 text-purple-300 hover:bg-purple-600/50 border border-purple-500/40 text-xs font-semibold transition"
        >
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Quiz ({currentLesson.quiz.length})</span>
        </button>

        {/* Reset button */}
        <button
          onClick={resetProtocol}
          title="Reset Simulation"
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
