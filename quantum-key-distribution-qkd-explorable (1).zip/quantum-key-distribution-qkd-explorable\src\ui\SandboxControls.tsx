import React from 'react';
import { useAppStore } from '../state/store';
import { 
  Play, 
  Pause, 
  FastForward, 
  Sliders, 
  Eye, 
  EyeOff,
  Zap,
  RotateCcw
} from 'lucide-react';

export const SandboxControls: React.FC = () => {
  const {
    aliceSelectedState,
    setAliceState,
    bobSelectedBasis,
    setBobBasis,
    eveActive,
    setEveActive,
    eveInterceptRate,
    setEveInterceptRate,
    channelLossDb,
    setChannelLossDb,
    stepSinglePulse,
    runBatchSimulation,
    isContinuousRunning,
    toggleContinuous,
    resetProtocol,
  } = useAppStore();

  return (
    <div className="fixed bottom-6 left-6 z-30 max-w-xl w-full bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-2xl p-4 text-slate-100 pointer-events-auto">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-xs uppercase tracking-wider text-slate-200">
            Interactive Quantum Sandbox & Attack Lab
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={stepSinglePulse}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs shadow-md shadow-cyan-600/20 transition"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Step 1</span>
          </button>

          <button
            onClick={() => runBatchSimulation(100)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs shadow-md shadow-blue-600/20 transition"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>Batch 100</span>
          </button>

          <button
            onClick={toggleContinuous}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl font-medium text-xs transition ${
              isContinuousRunning
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-md shadow-amber-600/20 animate-pulse'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
          >
            {isContinuousRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isContinuousRunning ? 'Stop' : 'Loop'}</span>
          </button>

          <button
            onClick={resetProtocol}
            title="Reset to default baseline"
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-3">
        {/* Alice Polarization Encoder */}
        <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400 mb-1.5 flex items-center justify-between">
            <span>Alice State (Encoder)</span>
            <span className="text-cyan-400 font-mono">[{aliceSelectedState}]</span>
          </div>
          <div className="grid grid-cols-4 gap-1">
            {(['H', 'V', 'D', 'A'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setAliceState(s)}
                className={`py-1 rounded-lg text-xs font-mono font-bold transition ${
                  aliceSelectedState === s
                    ? 'bg-cyan-500 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Bob Measurement Basis */}
        <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400 mb-1.5 flex items-center justify-between">
            <span>Bob Basis (HWP)</span>
            <span className="text-purple-400 font-mono">[{bobSelectedBasis === 'Z' ? 'Z (+)' : 'X (×)'}]</span>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={() => setBobBasis('Z')}
              className={`py-1 rounded-lg text-xs font-medium transition ${
                bobSelectedBasis === 'Z'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Z {`{|0⟩, |1⟩}`}
            </button>
            <button
              onClick={() => setBobBasis('X')}
              className={`py-1 rounded-lg text-xs font-medium transition ${
                bobSelectedBasis === 'X'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              X {`{|+⟩, |-⟩}`}
            </button>
          </div>
        </div>

        {/* Eve Eavesdropper & Channel Loss */}
        <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 space-y-2">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] uppercase font-bold text-rose-400 flex items-center space-x-1">
                {eveActive ? <Eye className="w-3 h-3 text-rose-400" /> : <EyeOff className="w-3 h-3 text-slate-500" />}
                <span>Eve Attack ({Math.round(eveInterceptRate * 100)}%)</span>
              </span>
              <button
                onClick={() => setEveActive(!eveActive)}
                className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full transition ${
                  eveActive ? 'bg-rose-900 text-rose-200 border border-rose-600' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {eveActive ? 'ON' : 'OFF'}
              </button>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={eveInterceptRate}
              onChange={(e) => setEveInterceptRate(parseFloat(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-[9px] text-slate-400 font-mono mb-1">
              <span>Channel Loss:</span>
              <span className="text-amber-400">{channelLossDb.toFixed(1)} dB</span>
            </div>
            <input
              type="range"
              min="0"
              max="30"
              step="1"
              value={channelLossDb}
              onChange={(e) => setChannelLossDb(parseFloat(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
