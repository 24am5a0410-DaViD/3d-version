import { create } from 'zustand';
import { OpticalObjectUserData } from '../components3d/opticalComponents';
import { BB84Engine, BB84SimulationResult, PulseRecord } from '../core/protocol/bb84';
import { ActiveSceneId } from '../scenes/SceneManager';
import { SatelliteViewMode } from '../scenes/SatelliteScene';

export interface AppState {
  // Navigation & Curriculum
  currentLessonId: number;
  activeSceneId: ActiveSceneId;
  satelliteZoomMode: SatelliteViewMode;
  dualDepthMode: 'eli12' | 'math';
  quizModalOpen: boolean;
  selectedComponent: OpticalObjectUserData | null;

  // Quantum Protocol State
  aliceSelectedState: 'H' | 'V' | 'D' | 'A';
  bobSelectedBasis: 'Z' | 'X';
  eveActive: boolean;
  eveInterceptRate: number;
  channelLossDb: number;
  detectorEfficiency: number;
  abortThreshold: number;

  // Live Telemetry & Distilled Key
  simulationResult: BB84SimulationResult | null;
  recentPulses: PulseRecord[];
  isContinuousRunning: boolean;
  seed: number;

  // Actions
  setLesson: (id: number) => void;
  setScene: (sceneId: ActiveSceneId) => void;
  setSatelliteZoom: (mode: SatelliteViewMode) => void;
  setDualDepthMode: (mode: 'eli12' | 'math') => void;
  setQuizModalOpen: (open: boolean) => void;
  setSelectedComponent: (comp: OpticalObjectUserData | null) => void;

  setAliceState: (state: 'H' | 'V' | 'D' | 'A') => void;
  setBobBasis: (basis: 'Z' | 'X') => void;
  setEveActive: (active: boolean) => void;
  setEveInterceptRate: (rate: number) => void;
  setChannelLossDb: (loss: number) => void;
  setAbortThreshold: (thresh: number) => void;

  stepSinglePulse: () => void;
  runBatchSimulation: (count?: number) => void;
  toggleContinuous: () => void;
  resetProtocol: () => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  currentLessonId: 0,
  activeSceneId: 'bb84',
  satelliteZoomMode: 'orbit',
  dualDepthMode: 'eli12',
  quizModalOpen: false,
  selectedComponent: null,

  aliceSelectedState: 'H',
  bobSelectedBasis: 'Z',
  eveActive: false,
  eveInterceptRate: 0.0,
  channelLossDb: 2.0,
  detectorEfficiency: 0.65,
  abortThreshold: 0.11,

  simulationResult: null,
  recentPulses: [],
  isContinuousRunning: false,
  seed: 42,

  setLesson: (id: number) => set({ currentLessonId: id }),
  setScene: (sceneId: ActiveSceneId) => set({ activeSceneId: sceneId }),
  setSatelliteZoom: (mode: SatelliteViewMode) => set({ satelliteZoomMode: mode }),
  setDualDepthMode: (mode: 'eli12' | 'math') => set({ dualDepthMode: mode }),
  setQuizModalOpen: (open: boolean) => set({ quizModalOpen: open }),
  setSelectedComponent: (comp: OpticalObjectUserData | null) => set({ selectedComponent: comp }),

  setAliceState: (state: 'H' | 'V' | 'D' | 'A') => set({ aliceSelectedState: state }),
  setBobBasis: (basis: 'Z' | 'X') => set({ bobSelectedBasis: basis }),
  setEveActive: (active: boolean) => {
    set({ eveActive: active, eveInterceptRate: active ? 1.0 : 0.0 });
    get().runBatchSimulation(100);
  },
  setEveInterceptRate: (rate: number) => {
    set({ eveInterceptRate: rate, eveActive: rate > 0 });
    get().runBatchSimulation(100);
  },
  setChannelLossDb: (loss: number) => {
    set({ channelLossDb: loss });
    get().runBatchSimulation(100);
  },
  setAbortThreshold: (thresh: number) => {
    set({ abortThreshold: thresh });
    get().runBatchSimulation(100);
  },

  stepSinglePulse: () => {
    const { aliceSelectedState, bobSelectedBasis, eveActive, eveInterceptRate, channelLossDb, detectorEfficiency, abortThreshold, seed } = get();
    const nextSeed = seed + 1;
    const res = BB84Engine.runSimulation({
      pulseCount: 1,
      eveInterceptRate: eveActive ? Math.max(0.1, eveInterceptRate) : 0,
      channelLossDb,
      detectorEfficiency,
      darkCountRate: 1e-4,
      abortThreshold,
      seed: nextSeed,
    });

    const newPulse = res.pulses[0];
    // Apply user selected manual state & basis
    const aBit = (aliceSelectedState === 'H' || aliceSelectedState === 'D') ? 0 : 1;
    const aBasis = (aliceSelectedState === 'H' || aliceSelectedState === 'V') ? 'Z' : 'X';
    newPulse.aliceBit = aBit;
    newPulse.aliceBasis = aBasis;
    newPulse.bobBasis = bobSelectedBasis;
    newPulse.basesMatch = aBasis === bobSelectedBasis;

    const prevPulses = get().recentPulses.slice(0, 15);
    set({
      seed: nextSeed,
      recentPulses: [newPulse, ...prevPulses],
      simulationResult: res,
    });
  },

  runBatchSimulation: (count: number = 100) => {
    const { eveActive, eveInterceptRate, channelLossDb, detectorEfficiency, abortThreshold, seed } = get();
    const nextSeed = seed + 7;
    const res = BB84Engine.runSimulation({
      pulseCount: count,
      eveInterceptRate: eveActive ? Math.max(0.1, eveInterceptRate) : 0,
      channelLossDb,
      detectorEfficiency,
      darkCountRate: 1e-4,
      abortThreshold,
      seed: nextSeed,
    });

    set({
      seed: nextSeed,
      simulationResult: res,
      recentPulses: res.pulses.slice(0, 16),
    });
  },

  toggleContinuous: () => {
    set((state) => ({ isContinuousRunning: !state.isContinuousRunning }));
  },

  resetProtocol: () => {
    const res = BB84Engine.runSimulation({
      pulseCount: 100,
      eveInterceptRate: 0.0,
      channelLossDb: 2.0,
      detectorEfficiency: 0.65,
      darkCountRate: 1e-4,
      abortThreshold: 0.11,
      seed: 42,
    });
    set({
      seed: 42,
      eveActive: false,
      eveInterceptRate: 0.0,
      simulationResult: res,
      recentPulses: res.pulses.slice(0, 16),
      isContinuousRunning: false,
    });
  },
}));
