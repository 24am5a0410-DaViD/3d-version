import * as THREE from 'three';
import { OpticalComponentFactory } from '../components3d/opticalComponents';
import { LaserBeamRenderer } from '../render/beamRenderer';

export type SatelliteViewMode = 'orbit' | 'payload' | 'fiber' | 'ground';

export class SatelliteScene {
  readonly scene: THREE.Group;
  private beamRenderer: LaserBeamRenderer;
  private interactiveObjects: THREE.Object3D[] = [];
  
  // Scene components
  private earthGroup: THREE.Group;
  private satelliteMesh: THREE.Group;
  private groundStationMesh: THREE.Group;
  private payloadTable: THREE.Group;
  private groundTable: THREE.Group;
  private fiberModuleGroup: THREE.Group;

  private orbitAngle: number = 0;
  private currentMode: SatelliteViewMode = 'orbit';

  constructor() {
    this.scene = new THREE.Group();
    this.beamRenderer = new LaserBeamRenderer();
    this.scene.add(this.beamRenderer.getGroup());

    this.earthGroup = new THREE.Group();
    this.satelliteMesh = new THREE.Group();
    this.groundStationMesh = new THREE.Group();
    this.payloadTable = new THREE.Group();
    this.groundTable = new THREE.Group();
    this.fiberModuleGroup = new THREE.Group();

    this.buildOrbitView();
    this.buildSatellitePayloadBench();
    this.buildGroundStationBench();
    this.buildFiberOpticsModule();

    this.setViewMode('orbit');
  }

  private buildOrbitView(): void {
    // 1. Earth globe with atmosphere shader/material
    const earthRadius = 14;
    const earthGeom = new THREE.SphereGeometry(earthRadius, 64, 64);
    const earthMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a, // Deep ocean blue
      roughness: 0.6,
      metalness: 0.1,
    });
    const earth = new THREE.Mesh(earthGeom, earthMat);
    earth.position.set(0, -earthRadius, 0);
    this.earthGroup.add(earth);

    // Continent silhouettes
    const continentMat = new THREE.MeshStandardMaterial({
      color: 0x15803d,
      roughness: 0.8,
    });
    for (let i = 0; i < 8; i++) {
      const patch = new THREE.Mesh(new THREE.DodecahedronGeometry(2.5 + Math.random() * 2), continentMat);
      patch.position.set(
        Math.sin(i * 1.2) * (earthRadius - 0.2),
        -earthRadius + Math.cos(i * 1.5) * (earthRadius - 0.2),
        Math.cos(i * 1.2) * (earthRadius - 0.2)
      );
      this.earthGroup.add(patch);
    }

    // Atmosphere halo
    const atmosMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.25,
      side: THREE.BackSide,
    });
    const atmos = new THREE.Mesh(new THREE.SphereGeometry(earthRadius + 0.8, 64, 64), atmosMat);
    atmos.position.copy(earth.position);
    this.earthGroup.add(atmos);

    // 2. Ground Station on Earth Zenith
    this.groundStationMesh = new THREE.Group();
    const domeGeom = new THREE.SphereGeometry(0.8, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const domeMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.3, metalness: 0.7 });
    const dome = new THREE.Mesh(domeGeom, domeMat);
    this.groundStationMesh.add(dome);

    const telescopeAperture = OpticalComponentFactory.createTelescope(false);
    telescopeAperture.scale.set(0.35, 0.35, 0.35);
    telescopeAperture.position.set(0, 0.4, 0);
    telescopeAperture.rotation.x = -Math.PI / 4;
    this.groundStationMesh.add(telescopeAperture);
    this.groundStationMesh.position.set(0, 0.0, 0);

    this.earthGroup.add(this.groundStationMesh);
    this.scene.add(this.earthGroup);

    // 3. Satellite Model (LEO at ~500km altitude)
    this.satelliteMesh = new THREE.Group();
    // Satellite main bus
    const busGeom = new THREE.BoxGeometry(1.2, 0.8, 0.9);
    const busMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.2, metalness: 0.85 }); // Gold MLI thermal foil
    const bus = new THREE.Mesh(busGeom, busMat);
    this.satelliteMesh.add(bus);

    // Solar panels
    const panelGeom = new THREE.BoxGeometry(2.4, 0.05, 0.8);
    const panelMat = new THREE.MeshStandardMaterial({ color: 0x1e1b4b, roughness: 0.1, metalness: 0.9 });
    const leftPanel = new THREE.Mesh(panelGeom, panelMat);
    leftPanel.position.set(-2.0, 0, 0);
    this.satelliteMesh.add(leftPanel);

    const rightPanel = new THREE.Mesh(panelGeom, panelMat);
    rightPanel.position.set(2.0, 0, 0);
    this.satelliteMesh.add(rightPanel);

    // Satellite optical antenna
    const satScope = OpticalComponentFactory.createTelescope(true);
    satScope.scale.set(0.3, 0.3, 0.3);
    satScope.position.set(0, -0.4, 0);
    satScope.rotation.x = Math.PI / 2;
    this.satelliteMesh.add(satScope);

    this.satelliteMesh.position.set(4, 9, 0);
    this.scene.add(this.satelliteMesh);
  }

  /**
   * Panel c: Satellite Optical Payload Bench
   */
  private buildSatellitePayloadBench(): void {
    const table = OpticalComponentFactory.createBreadboard(7.0, 4.5);
    this.payloadTable.add(table);

    // Cassegrain transmitter telescope (Image 1 panel c)
    const tel = OpticalComponentFactory.createTelescope(true);
    tel.position.set(2.4, 0, 0);
    tel.rotation.y = -Math.PI / 2;
    this.payloadTable.add(tel);
    this.interactiveObjects.push(tel);

    // Fast Steering Mirror 1 (FSM1)
    const fsm1 = OpticalComponentFactory.createFSM('fsm1');
    fsm1.position.set(0.8, 0, 0);
    this.payloadTable.add(fsm1);
    this.interactiveObjects.push(fsm1);

    // Dichroic Mirrors DM1, DM2
    const dm1 = OpticalComponentFactory.createBeamSplitter('dm1');
    dm1.position.set(-0.8, 0, 0.6);
    this.payloadTable.add(dm1);
    this.interactiveObjects.push(dm1);

    const dm2 = OpticalComponentFactory.createBeamSplitter('dm2');
    dm2.position.set(-0.8, 0, -0.6);
    this.payloadTable.add(dm2);
    this.interactiveObjects.push(dm2);

    // Tracking cameras CAM1, CAM2
    const cam1 = OpticalComponentFactory.createTrackingCamera('cam1');
    cam1.position.set(1.5, 0, 1.4);
    this.payloadTable.add(cam1);
    this.interactiveObjects.push(cam1);

    const cam2 = OpticalComponentFactory.createTrackingCamera('cam2');
    cam2.position.set(-0.8, 0, 1.4);
    this.payloadTable.add(cam2);
    this.interactiveObjects.push(cam2);

    // Waveplates (WPs) and Attenuator (ATT)
    const wps = OpticalComponentFactory.createWavePlate('wps_payload');
    wps.position.set(-2.2, 0, -0.6);
    this.payloadTable.add(wps);
    this.interactiveObjects.push(wps);

    // 532-nm Beacon laser
    const beacon532 = OpticalComponentFactory.createLaserSourceBlock('V', 0x10b981);
    beacon532.position.set(1.5, 0, 2.2);
    beacon532.scale.set(0.6, 0.6, 0.6);
    this.payloadTable.add(beacon532);
    this.interactiveObjects.push(beacon532);

    this.payloadTable.position.set(50, 0, 0); // Positioned in separate coordinate space for zoom view
    this.scene.add(this.payloadTable);
  }

  /**
   * Panel d: Ground Station Optical Receiver Bench
   */
  private buildGroundStationBench(): void {
    const table = OpticalComponentFactory.createBreadboard(7.5, 5.0);
    this.groundTable.add(table);

    // Primary 1-meter receiver telescope
    const tel = OpticalComponentFactory.createTelescope(false);
    tel.position.set(-2.5, 0, 0);
    tel.rotation.y = Math.PI / 2;
    this.groundTable.add(tel);
    this.interactiveObjects.push(tel);

    // Fast Steering Mirror FSM2
    const fsm2 = OpticalComponentFactory.createFSM('fsm2');
    fsm2.position.set(1.8, 0, 0);
    this.groundTable.add(fsm2);
    this.interactiveObjects.push(fsm2);

    // Dichroic mirror DM3
    const dm3 = OpticalComponentFactory.createBeamSplitter('dm3');
    dm3.position.set(0.2, 0, 0);
    this.groundTable.add(dm3);
    this.interactiveObjects.push(dm3);

    // Tracking cameras CAM3, CAM4
    const cam3 = OpticalComponentFactory.createTrackingCamera('cam3');
    cam3.position.set(-1.0, 0, 1.8);
    this.groundTable.add(cam3);
    this.interactiveObjects.push(cam3);

    const cam4 = OpticalComponentFactory.createTrackingCamera('cam4');
    cam4.position.set(1.8, 0, 1.8);
    this.groundTable.add(cam4);
    this.interactiveObjects.push(cam4);

    // Quantum receiver path: HWP -> PBS -> SPAD detectors (ports III, IV, V)
    const hwp = OpticalComponentFactory.createWavePlate('ground_hwp');
    hwp.position.set(0.2, 0, -1.0);
    this.groundTable.add(hwp);
    this.interactiveObjects.push(hwp);

    const pbs = OpticalComponentFactory.createPBS('ground_pbs');
    pbs.position.set(0.2, 0, -2.0);
    this.groundTable.add(pbs);
    this.interactiveObjects.push(pbs);

    const spadH = OpticalComponentFactory.createSPAD('ground_spad_h');
    spadH.position.set(0.2, 0, -3.0);
    this.groundTable.add(spadH);
    this.interactiveObjects.push(spadH);

    const spadV = OpticalComponentFactory.createSPAD('ground_spad_v');
    spadV.position.set(1.2, 0, -2.0);
    spadV.rotation.y = -Math.PI / 2;
    this.groundTable.add(spadV);
    this.interactiveObjects.push(spadV);

    // 785-nm Uplink Beacon Laser
    const beacon785 = OpticalComponentFactory.createLaserSourceBlock('H', 0xeab308);
    beacon785.position.set(-1.0, 0, 2.6);
    beacon785.scale.set(0.6, 0.6, 0.6);
    this.groundTable.add(beacon785);
    this.interactiveObjects.push(beacon785);

    this.groundTable.position.set(-50, 0, 0);
    this.scene.add(this.groundTable);
  }

  /**
   * Panel b: Fibre Optics Module (850 QLD, PM1, PM2, WDM, CLD)
   */
  private buildFiberOpticsModule(): void {
    const table = OpticalComponentFactory.createBreadboard(6.0, 3.5);
    this.fiberModuleGroup.add(table);

    // 850-nm Quantum Laser Diode (QLD)
    const qld = OpticalComponentFactory.createLaserSourceBlock('H', 0xff2244);
    qld.position.set(-2.2, 0, 0.8);
    qld.scale.set(0.7, 0.7, 0.7);
    this.fiberModuleGroup.add(qld);
    this.interactiveObjects.push(qld);

    // Phase modulators PM1, PM2
    const pm1 = OpticalComponentFactory.createModulator('PM', 1);
    pm1.position.set(0.2, 0, 0.8);
    this.fiberModuleGroup.add(pm1);
    this.interactiveObjects.push(pm1);

    const pm2 = OpticalComponentFactory.createModulator('PM', 2);
    pm2.position.set(0.2, 0, -0.8);
    this.fiberModuleGroup.add(pm2);
    this.interactiveObjects.push(pm2);

    // WDM multiplexer & circulator (PCIR)
    const wdm = OpticalComponentFactory.createModulator('AM', 1);
    wdm.position.set(-0.8, 0, 0);
    this.fiberModuleGroup.add(wdm);
    this.interactiveObjects.push(wdm);

    this.fiberModuleGroup.position.set(0, 50, 0);
    this.scene.add(this.fiberModuleGroup);
  }

  public setViewMode(mode: SatelliteViewMode): void {
    this.currentMode = mode;
    this.earthGroup.visible = mode === 'orbit';
    this.satelliteMesh.visible = mode === 'orbit';
    this.payloadTable.visible = mode === 'payload';
    this.groundTable.visible = mode === 'ground';
    this.fiberModuleGroup.visible = mode === 'fiber';

    this.updateBeamsForCurrentMode();
  }

  private updateBeamsForCurrentMode(): void {
    this.beamRenderer.clear();

    if (this.currentMode === 'orbit') {
      const satPos = this.satelliteMesh.position;
      const groundPos = new THREE.Vector3(0, 0.6, 0);

      // Panel a: 3 Multiplexed beams + beacons
      // 1. 850-nm Quantum Channel (Downlink: Satellite -> Ground)
      this.beamRenderer.addBeamSegment({
        start: satPos,
        end: groundPos,
        color: LaserBeamRenderer.wavelengthToColor(850),
        radius: 0.04,
        pulseSpeed: 2.5,
      });

      // 2. 812-nm Classical Downlink
      this.beamRenderer.addBeamSegment({
        start: new THREE.Vector3(satPos.x + 0.1, satPos.y, satPos.z + 0.1),
        end: new THREE.Vector3(groundPos.x + 0.1, groundPos.y, groundPos.z + 0.1),
        color: LaserBeamRenderer.wavelengthToColor(812),
        radius: 0.03,
        pulseSpeed: 3.2,
      });

      // 3. 1,538-nm Classical Uplink (Ground -> Satellite)
      this.beamRenderer.addBeamSegment({
        start: groundPos,
        end: satPos,
        color: LaserBeamRenderer.wavelengthToColor(1538),
        radius: 0.035,
        pulseSpeed: -2.8,
      });

      // 4. 532-nm Green Beacon
      this.beamRenderer.addBeamSegment({
        start: satPos,
        end: groundPos,
        color: LaserBeamRenderer.wavelengthToColor(532),
        radius: 0.02,
        pulseSpeed: 4.0,
      });
    } else if (this.currentMode === 'payload') {
      const p = this.payloadTable.position;
      this.beamRenderer.addBeamSegment({
        start: new THREE.Vector3(p.x - 2.2, 0.55, -0.6),
        end: new THREE.Vector3(p.x + 2.4, 0.55, 0),
        color: LaserBeamRenderer.wavelengthToColor(850),
      });
    } else if (this.currentMode === 'ground') {
      const g = this.groundTable.position;
      this.beamRenderer.addBeamSegment({
        start: new THREE.Vector3(g.x - 2.5, 0.55, 0),
        end: new THREE.Vector3(g.x + 0.2, 0.55, -2.0),
        color: LaserBeamRenderer.wavelengthToColor(850),
      });
    }
  }

  public update(timeSeconds: number, delta: number): void {
    this.beamRenderer.update(timeSeconds);

    if (this.currentMode === 'orbit') {
      // Orbiting motion of satellite across the sky
      this.orbitAngle += delta * 0.15;
      const orbitRadius = 11.5;
      this.satelliteMesh.position.x = Math.sin(this.orbitAngle) * orbitRadius;
      this.satelliteMesh.position.y = Math.cos(this.orbitAngle) * 4.5 + 8.5;
      this.satelliteMesh.position.z = Math.cos(this.orbitAngle) * 3.0;

      // Keep satellite pointed at ground telescope
      this.satelliteMesh.lookAt(0, 0.5, 0);

      this.updateBeamsForCurrentMode();
    }
  }

  public getInteractiveObjects(): THREE.Object3D[] {
    return this.interactiveObjects;
  }
}
