import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { MathFormula } from './MathFormula';
import { X, Sparkles, BookOpen, Layers } from 'lucide-react';

export const ComponentInspector: React.FC = () => {
  const { selectedComponent, setSelectedComponent } = useAppStore();
  const [tab, setTab] = useState<'eli12' | 'specs'>('eli12');

  if (!selectedComponent) return null;

  return (
    <div className="fixed top-16 right-6 z-30 max-w-sm w-full bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100 animate-in fade-in slide-in-from-right-4 duration-200">
      {/* Header */}
      <div className="flex items-center justify-between p-3.5 bg-slate-800/80 border-b border-slate-700">
        <div className="flex items-center space-x-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <h3 className="font-bold text-sm tracking-wide">{selectedComponent.name}</h3>
        </div>
        <button
          onClick={() => setSelectedComponent(null)}
          className="p-1 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-3">
        {/* Subsystem Tag */}
        <div className="flex items-center space-x-2">
          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800">
            {selectedComponent.subsystem}
          </span>
          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
            {selectedComponent.type.replace('_', ' ')}
          </span>
        </div>

        {/* Mathematical Transformation / Jones Matrix */}
        {selectedComponent.formulaLatex && (
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">Jones Operator:</span>
            <div className="text-center py-1">
              <MathFormula block math={selectedComponent.formulaLatex} />
            </div>
          </div>
        )}

        {/* Dual-Depth Tabs */}
        <div className="flex border-b border-slate-800 text-xs">
          <button
            onClick={() => setTab('eli12')}
            className={`flex items-center space-x-1.5 pb-2 px-2 font-medium border-b-2 transition ${
              tab === 'eli12'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Intuition (ELI12)</span>
          </button>
          <button
            onClick={() => setTab('specs')}
            className={`flex items-center space-x-1.5 pb-2 px-2 font-medium border-b-2 transition ${
              tab === 'specs'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-blue-400" />
            <span>Technical Specs</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="text-xs leading-relaxed text-slate-300">
          {tab === 'eli12' ? (
            <p className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 italic">
              "{selectedComponent.eli12}"
            </p>
          ) : (
            <div className="space-y-2">
              <p>{selectedComponent.description}</p>
              <div className="text-[11px] text-slate-400 font-mono space-y-1 bg-slate-950/50 p-2 rounded-lg border border-slate-800">
                <div>• Alignment: Sub-microradian precision</div>
                <div>• Reflection/Transmission: Dielectric thin-film AR coated</div>
                <div>• Operating Wavelength: 850 nm / 812 nm / 1538 nm</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
