import * as THREE from 'three';
import { OpticalComponentFactory } from '../components3d/opticalComponents';
import { LaserBeamRenderer } from '../render/beamRenderer';

export class BB84BenchScene {
  readonly scene: THREE.Group;
  private beamRenderer: LaserBeamRenderer;
  private photonMesh: THREE.Group;
  private interactiveObjects: THREE.Object3D[] = [];
  private photonProgress: number = 0;
  private activeStateLabel: 'H' | 'V' | 'D' | 'A' = 'H';
  private bobBasis: 'Z' | 'X' = 'Z';
  private bobHwpGroup: THREE.Group | null = null;

  constructor() {
    this.scene = new THREE.Group();
    this.beamRenderer = new LaserBeamRenderer();
    this.scene.add(this.beamRenderer.getGroup());

    this.photonMesh = this.createPhotonVisualizer();
    this.scene.add(this.photonMesh);

    this.buildExactTestBench();
  }

  private createPhotonVisualizer(): THREE.Group {
    const group = new THREE.Group();
    
    // Glowing core sphere
    const sphereMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.045, 16, 16), sphereMat);
    group.add(sphere);

    // Outer halo
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0xff2244,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });
    const halo = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 16), haloMat);
    group.add(halo);

    // Polarization direction indicator arrow
    const arrowGeom = new THREE.CylinderGeometry(0.018, 0.018, 0.38, 8);
    const arrowMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const arrow = new THREE.Mesh(arrowGeom, arrowMat);
    group.add(arrow);

    group.position.set(-7.2, 0.82, 0.7);
    return group;
  }

  /**
   * Builds the 3D test bench matching all specifications:
   * 4 Laser Sources, 4 Polarizers, 3 BS Cyan Cubes, 3 Modulators (AM, PM, AM), Output F & I,
   * Bob Passive 50:50 BS, 2 PBS Magenta Cubes, 4 SPADs, and HWP at 22.5° in diagonal arm.
   */
  private buildExactTestBench(): void {
    // 0. Dark reflective slate laboratory table with subtle organic marble grain
    const floorCanvas = document.createElement('canvas');
    floorCanvas.width = 1024;
    floorCanvas.height = 1024;
    const fctx = floorCanvas.getContext('2d')!;
    fctx.fillStyle = '#1c232e';
    fctx.fillRect(0, 0, 1024, 1024);

    // Soft organic cloudy mottling
    for (let i = 0; i < 35; i++) {
      const cx = Math.random() * 1024;
      const cy = Math.random() * 1024;
      const rad = 80 + Math.random() * 160;
      const grad = fctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
      grad.addColorStop(0, 'rgba(255, 255, 255, 0.045)');
      grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      fctx.fillStyle = grad;
      fctx.beginPath();
      fctx.arc(cx, cy, rad, 0, Math.PI * 2);
      fctx.fill();
    }

    // Delicate meandering marble veins
    fctx.strokeStyle = 'rgba(255, 255, 255, 0.075)';
    fctx.lineWidth = 1.4;
    for (let i = 0; i < 22; i++) {
      fctx.beginPath();
      const startX = Math.random() * 1024;
      const startY = Math.random() * 1024;
      fctx.moveTo(startX, startY);
      fctx.bezierCurveTo(
        startX + (Math.random() * 200 - 100),
        startY + (Math.random() * 200 - 100),
        startX + (Math.random() * 400 - 200),
        startY + (Math.random() * 300 - 150),
        startX + (Math.random() * 600 - 300),
        startY + (Math.random() * 400 - 200)
      );
      fctx.stroke();
    }

    const floorTexture = new THREE.CanvasTexture(floorCanvas);
    floorTexture.wrapS = THREE.RepeatWrapping;
    floorTexture.wrapT = THREE.RepeatWrapping;
    floorTexture.repeat.set(2, 2);

    const floorGeom = new THREE.PlaneGeometry(140, 90);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: floorTexture,
      roughness: 0.26,
      metalness: 0.35,
    });
    const floor = new THREE.Mesh(floorGeom, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, -0.01, -10);
    floor.receiveShadow = true;
    this.scene.add(floor);

    // Seamless laboratory studio backdrop wall
    const wallGeom = new THREE.PlaneGeometry(140, 45);
    const wallMat = new THREE.MeshStandardMaterial({
      color: 0x141820,
      roughness: 0.9,
      metalness: 0.1,
    });
    const wall = new THREE.Mesh(wallGeom, wallMat);
    wall.position.set(0, 16, -26);
    this.scene.add(wall);

    const tableHeight = 0.32;

    // ==========================================
    // 1. ALICE'S OPTICAL BREADBOARD (LEFT, STRAIGHT ALONG Z = 0)
    // ==========================================
    const aliceWidth = 8.6;
    const aliceDepth = 3.6;
    const aliceTable = OpticalComponentFactory.createBreadboard(aliceWidth, aliceDepth, tableHeight);
    aliceTable.position.set(-3.7, 0, 0);
    this.scene.add(aliceTable);

    // Printed signature "Alice" directly on breadboard surface under modulation line
    const aliceText = OpticalComponentFactory.createFlatText(
      'Alice',
      2.5,
      0.8,
      115,
      '#050810',
      'italic',
      '"Times New Roman", "Playfair Display", Georgia, serif'
    );
    aliceText.position.set(-0.6, tableHeight + 0.008, 1.25);
    this.scene.add(aliceText);

    // ------------------------------------------
    // 1.1 Four Laser Sources (Bright Yellow Cubes in 2x2 Geometry)
    // ------------------------------------------
    // FRONT ROW:
    // H (Horizontal: Bottom-Left Front, fires +X, marked with ↔)
    const sourceH = OpticalComponentFactory.createLaserSourceBlock('H', '+X');
    sourceH.position.set(-7.2, tableHeight, 0.7);
    this.scene.add(sourceH);
    this.interactiveObjects.push(sourceH);

    // V (Vertical: Bottom-Center, fires -Z into BS1 front port, marked with ↕)
    const sourceV = OpticalComponentFactory.createLaserSourceBlock('V', '-Z');
    sourceV.position.set(-5.0, tableHeight, 1.55);
    this.scene.add(sourceV);
    this.interactiveObjects.push(sourceV);

    // BACK ROW:
    // A (Anti-diagonal: Back-Left, fires +X, marked with ⤢)
    const sourceA = OpticalComponentFactory.createLaserSourceBlock('A', '+X');
    sourceA.position.set(-7.2, tableHeight, -0.7);
    this.scene.add(sourceA);
    this.interactiveObjects.push(sourceA);

    // D (Diagonal: Back-Center, fires +Z into BS2 rear port, marked with ↗)
    const sourceD = OpticalComponentFactory.createLaserSourceBlock('D', '+Z');
    sourceD.position.set(-5.0, tableHeight, -1.55);
    this.scene.add(sourceD);
    this.interactiveObjects.push(sourceD);

    // ------------------------------------------
    // 1.2 Four Linear Polarizers (Translucent Green Discs on Posts)
    // Mounted directly in front of each laser diode aperture
    // ------------------------------------------
    const polH = OpticalComponentFactory.createOpticalDisc('polarizer', 'pol_h');
    polH.position.set(-6.4, tableHeight, 0.7);
    polH.rotation.y = Math.PI / 2;
    this.scene.add(polH);
    this.interactiveObjects.push(polH);

    const polV = OpticalComponentFactory.createOpticalDisc('polarizer', 'pol_v');
    polV.position.set(-5.0, tableHeight, 1.12);
    polV.rotation.y = 0;
    this.scene.add(polV);
    this.interactiveObjects.push(polV);

    const polA = OpticalComponentFactory.createOpticalDisc('polarizer', 'pol_a');
    polA.position.set(-6.4, tableHeight, -0.7);
    polA.rotation.y = Math.PI / 2;
    this.scene.add(polA);
    this.interactiveObjects.push(polA);

    const polD = OpticalComponentFactory.createOpticalDisc('polarizer', 'pol_d');
    polD.position.set(-5.0, tableHeight, -1.12);
    polD.rotation.y = 0;
    this.scene.add(polD);
    this.interactiveObjects.push(polD);

    // ------------------------------------------
    // 1.3 Beam Splitter Tree (3× Cyan / Light-Blue Cubic Prisms Marked BS)
    // 50:50 Non-Polarizing Beam Splitters combining 4 beam trajectories into 1 coaxial path
    // ------------------------------------------
    // BS 1: Combines H (+X) and V (-Z) trajectories into +X path along z = 0.7
    const bs1 = OpticalComponentFactory.createBeamSplitterCube('alice_bs1');
    bs1.position.set(-5.0, tableHeight, 0.7);
    this.scene.add(bs1);
    this.interactiveObjects.push(bs1);

    // BS 2: Combines A (+X) and D (+Z) trajectories into +X path along z = -0.7
    const bs2 = OpticalComponentFactory.createBeamSplitterCube('alice_bs2');
    bs2.position.set(-5.0, tableHeight, -0.7);
    this.scene.add(bs2);
    this.interactiveObjects.push(bs2);

    // BS 3: Final Combiner merging front and back branches into central collinear axis (z = 0)
    const bs3 = OpticalComponentFactory.createBeamSplitterCube('alice_bs3');
    bs3.position.set(-2.8, tableHeight, 0.0);
    this.scene.add(bs3);
    this.interactiveObjects.push(bs3);

    // ------------------------------------------
    // 1.4 Decoy & Phase Modulation Modules (3× In-line Matte Black Cubes)
    // AM (Intensity/Decoy) -> PM (Phase Randomization) -> AM (VOA / Attenuation)
    // ------------------------------------------
    const am1 = OpticalComponentFactory.createModulator('AM', 'am1');
    am1.position.set(-1.6, tableHeight, 0.0);
    this.scene.add(am1);
    this.interactiveObjects.push(am1);

    const pm = OpticalComponentFactory.createModulator('PM', 'pm');
    pm.position.set(-0.5, tableHeight, 0.0);
    this.scene.add(pm);
    this.interactiveObjects.push(pm);

    const am2 = OpticalComponentFactory.createModulator('AM', 'am2');
    am2.position.set(0.6, tableHeight, 0.0);
    this.scene.add(am2);
    this.interactiveObjects.push(am2);

    // ------------------------------------------
    // 1.5 Output Conditioning Optics
    // F (Narrow Bandpass Filter) & I (Iris Spatial Mode Filter)
    // ------------------------------------------
    const exitF = OpticalComponentFactory.createOpticalDisc('filter', 'exit_f');
    exitF.position.set(1.4, tableHeight, 0.0);
    exitF.rotation.y = Math.PI / 2;
    this.scene.add(exitF);
    this.interactiveObjects.push(exitF);

    const exitI = OpticalComponentFactory.createOpticalDisc('iris', 'exit_i');
    exitI.position.set(2.0, tableHeight, 0.0);
    exitI.rotation.y = Math.PI / 2;
    this.scene.add(exitI);
    this.interactiveObjects.push(exitI);

    // ==========================================
    // 2. 3D TEXT LEGENDS ON THE FLOOR TABLE
    // ==========================================
    const legendTilt = -Math.PI / 2 + 0.60;

    // Left Floor Legend (In front of Alice's Table):
    // Mini models placed at x = -3.2, text centered at x = -1.5 (left edge at -2.8, safely to the right of models)
    const miniLaser = OpticalComponentFactory.createLaserSourceBlock('H', '+X');
    miniLaser.scale.set(0.38, 0.38, 0.38);
    miniLaser.position.set(-3.4, 0, 2.3);
    this.scene.add(miniLaser);

    const legendAliceLaser = OpticalComponentFactory.createFlatText("Alice's Laser", 2.6, 0.45, 96, '#ffffff');
    legendAliceLaser.position.set(-1.7, 0.05, 2.3);
    legendAliceLaser.rotation.x = legendTilt;
    this.scene.add(legendAliceLaser);

    const miniPol = OpticalComponentFactory.createOpticalDisc('polarizer');
    miniPol.scale.set(0.42, 0.42, 0.42);
    miniPol.position.set(-3.4, 0, 2.85);
    this.scene.add(miniPol);

    const legendPol = OpticalComponentFactory.createFlatText('Polarizer', 2.6, 0.45, 96, '#ffffff');
    legendPol.position.set(-1.7, 0.05, 2.85);
    legendPol.rotation.x = legendTilt;
    this.scene.add(legendPol);

    const miniBS = OpticalComponentFactory.createBeamSplitterCube();
    miniBS.scale.set(0.42, 0.42, 0.42);
    miniBS.position.set(-3.4, 0, 3.4);
    this.scene.add(miniBS);

    const legendBS = OpticalComponentFactory.createFlatText('BS', 2.6, 0.45, 96, '#ffffff');
    legendBS.position.set(-1.7, 0.05, 3.4);
    legendBS.rotation.x = legendTilt;
    this.scene.add(legendBS);

    const miniF = OpticalComponentFactory.createOpticalDisc('filter');
    miniF.scale.set(0.42, 0.42, 0.42);
    miniF.position.set(-3.4, 0, 3.95);
    this.scene.add(miniF);

    const legendF = OpticalComponentFactory.createFlatText('F', 2.6, 0.45, 96, '#ffffff');
    legendF.position.set(-1.7, 0.05, 3.95);
    legendF.rotation.x = legendTilt;
    this.scene.add(legendF);

    const miniI = OpticalComponentFactory.createOpticalDisc('iris');
    miniI.scale.set(0.42, 0.42, 0.42);
    miniI.position.set(-3.4, 0, 4.5);
    this.scene.add(miniI);

    const legendI = OpticalComponentFactory.createFlatText('I', 2.6, 0.45, 96, '#ffffff');
    legendI.position.set(-1.7, 0.05, 4.5);
    legendI.rotation.x = legendTilt;
    this.scene.add(legendI);

    // Right Floor Legend (In front of gap and Bob's table):
    // Mini models placed at x = 1.4, text centered at x = 3.1 (left edge at 1.8)
    const miniSpad = OpticalComponentFactory.createSPAD();
    miniSpad.scale.set(0.38, 0.38, 0.38);
    miniSpad.position.set(1.4, 0, 2.3);
    miniSpad.rotation.y = Math.PI / 2;
    this.scene.add(miniSpad);

    const legendSpad = OpticalComponentFactory.createFlatText("Bob's SPAD", 2.6, 0.45, 96, '#ffffff');
    legendSpad.position.set(3.0, 0.05, 2.3);
    legendSpad.rotation.x = legendTilt;
    this.scene.add(legendSpad);

    const miniPBS = OpticalComponentFactory.createPBS();
    miniPBS.scale.set(0.38, 0.38, 0.38);
    miniPBS.position.set(1.4, 0, 2.9);
    this.scene.add(miniPBS);

    const legendPBS = OpticalComponentFactory.createFlatText('PBS', 2.6, 0.45, 96, '#ffffff');
    legendPBS.position.set(3.0, 0.05, 2.9);
    legendPBS.rotation.x = legendTilt;
    this.scene.add(legendPBS);

    const miniHWP = OpticalComponentFactory.createOpticalDisc('hwp');
    miniHWP.scale.set(0.42, 0.42, 0.42);
    miniHWP.position.set(1.4, 0, 3.5);
    this.scene.add(miniHWP);

    const legendHWP = OpticalComponentFactory.createFlatText('HWP', 2.6, 0.45, 96, '#ffffff');
    legendHWP.position.set(3.0, 0.05, 3.5);
    legendHWP.rotation.x = legendTilt;
    this.scene.add(legendHWP);

    // ==========================================
    // 3. BOB'S OPTICAL BREADBOARD (RIGHT, STRAIGHT ALONG Z = 0)
    // ==========================================
    const bobWidth = 5.8;
    const bobDepth = 3.8;
    const bobTable = OpticalComponentFactory.createBreadboard(bobWidth, bobDepth, tableHeight);
    bobTable.position.set(5.2, 0, 0);
    this.scene.add(bobTable);

    // Printed signature "Bob" directly on breadboard surface (in front, visible next to blue panel)
    const bobText = OpticalComponentFactory.createFlatText(
      'Bob',
      2.0,
      0.8,
      115,
      '#050810',
      'italic',
      '"Times New Roman", "Playfair Display", Georgia, serif'
    );
    bobText.position.set(5.0, tableHeight + 0.008, 1.25);
    this.scene.add(bobText);

    // ------------------------------------------
    // 3.1 Passive 50:50 Basis Selection Beam Splitter
    // Located at Bob's entrance (z = 0)
    // ------------------------------------------
    const bobBS = OpticalComponentFactory.createBeamSplitterCube('bob_passive_bs');
    bobBS.position.set(3.6, tableHeight, 0.0);
    this.scene.add(bobBS);
    this.interactiveObjects.push(bobBS);

    // ------------------------------------------
    // 3.2 Rectilinear Basis Arm (Z-Basis, Reflected Branch)
    // Directly enters Polarizing Beam Splitter (PBS 1)
    // ------------------------------------------
    const pbs1 = OpticalComponentFactory.createPBS('bob_pbs1');
    pbs1.position.set(3.6, tableHeight, -1.1);
    this.scene.add(pbs1);
    this.interactiveObjects.push(pbs1);

    // SPAD 1 (detects H in Z-basis: transmitted through PBS1 along -Z)
    const spad1 = OpticalComponentFactory.createSPAD('bob_spad1');
    spad1.position.set(3.6, tableHeight, -1.95);
    spad1.rotation.y = 0; // Aperture at +Z faces PBS1 at -1.1
    this.scene.add(spad1);
    this.interactiveObjects.push(spad1);

    // SPAD 2 (detects V in Z-basis: reflected 90° towards +X)
    const spad2 = OpticalComponentFactory.createSPAD('bob_spad2');
    spad2.position.set(4.5, tableHeight, -1.1);
    spad2.rotation.y = -Math.PI / 2; // Aperture rotated to -X faces PBS1 at 3.6
    this.scene.add(spad2);
    this.interactiveObjects.push(spad2);

    // ------------------------------------------
    // 3.3 Diagonal Basis Arm (X-Basis, Transmitted Branch along z = 0)
    // Passes through Spectral Filter (F) and HWP (22.5° fast axis) before PBS 2
    // ------------------------------------------
    const bobF = OpticalComponentFactory.createOpticalDisc('filter', 'bob_f');
    bobF.position.set(4.3, tableHeight, 0.0);
    bobF.rotation.y = Math.PI / 2;
    this.scene.add(bobF);
    this.interactiveObjects.push(bobF);

    const bobHWP = OpticalComponentFactory.createOpticalDisc('hwp', 'bob_hwp');
    bobHWP.position.set(4.95, tableHeight, 0.0);
    bobHWP.rotation.y = Math.PI / 2;
    bobHWP.rotation.z = Math.PI / 8; // 22.5° fast axis rotation for diagonal-to-rectilinear conversion
    this.bobHwpGroup = bobHWP;
    this.scene.add(bobHWP);
    this.interactiveObjects.push(bobHWP);

    // Magenta Polarizing Beam Splitter (PBS 2)
    const pbs2 = OpticalComponentFactory.createPBS('bob_pbs2');
    pbs2.position.set(5.75, tableHeight, 0.0);
    this.scene.add(pbs2);
    this.interactiveObjects.push(pbs2);

    // SPAD 3 (detects A in X-basis: reflected 90° towards -Z)
    const spad3 = OpticalComponentFactory.createSPAD('bob_spad3');
    spad3.position.set(5.75, tableHeight, -1.1);
    spad3.rotation.y = 0; // Aperture at +Z faces PBS2 at z = 0.0
    this.scene.add(spad3);
    this.interactiveObjects.push(spad3);

    // SPAD 4 (detects D in X-basis: transmitted along z = 0 towards +X)
    const spad4 = OpticalComponentFactory.createSPAD('bob_spad4');
    spad4.position.set(6.65, tableHeight, 0.0);
    spad4.rotation.y = -Math.PI / 2; // Aperture rotated to -X faces PBS2 at 5.75
    this.scene.add(spad4);
    this.interactiveObjects.push(spad4);

    // Initialize all beam paths
    this.updateBeams();
  }

  /**
   * Updates laser beam paths across Alice's combiner tree and Bob's 4-detector network.
   */
  public updateBeams(): void {
    this.beamRenderer.clear();
    const beamColor = LaserBeamRenderer.wavelengthToColor(850);
    const beamY = 0.32 + 0.50; // tableHeight + opticalHeight = 0.82

    // ==========================================
    // ALICE'S BEAM LINES:
    // ==========================================
    // Front line: Laser H (-7.2, 0.7) through polH (-6.4, 0.7) into BS1 (-5.0, 0.7)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(-7.2, beamY, 0.7),
      end: new THREE.Vector3(-5.0, beamY, 0.7),
      color: beamColor,
    });
    // Laser V (-5.0, 1.55) through polV (-5.0, 1.12) into BS1 (-5.0, 0.7)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(-5.0, beamY, 1.55),
      end: new THREE.Vector3(-5.0, beamY, 0.7),
      color: beamColor,
    });

    // Back line: Laser A (-7.2, -0.7) through polA (-6.4, -0.7) into BS2 (-5.0, -0.7)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(-7.2, beamY, -0.7),
      end: new THREE.Vector3(-5.0, beamY, -0.7),
      color: beamColor,
    });
    // Laser D (-5.0, -1.55) through polD (-5.0, -1.12) into BS2 (-5.0, -0.7)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(-5.0, beamY, -1.55),
      end: new THREE.Vector3(-5.0, beamY, -0.7),
      color: beamColor,
    });

    // Convergence from BS1 (front) and BS2 (back) into BS3 (center combiner at -2.8, 0.0)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(-5.0, beamY, 0.7),
      end: new THREE.Vector3(-2.8, beamY, 0.0),
      color: beamColor,
    });
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(-5.0, beamY, -0.7),
      end: new THREE.Vector3(-2.8, beamY, 0.0),
      color: beamColor,
    });

    // Main collinear modulation line through AM1, PM, AM2, exit optics (F, I):
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(-2.8, beamY, 0.0),
      end: new THREE.Vector3(2.0, beamY, 0.0),
      color: beamColor,
    });

    // FREE SPACE STRAIGHT BEAM: From Alice's Exit Iris (2.0, 0.0) to Bob's Entrance BS (3.6, 0.0)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(2.0, beamY, 0.0),
      end: new THREE.Vector3(3.6, beamY, 0.0),
      color: beamColor,
    });

    // ==========================================
    // BOB'S BEAM LINES:
    // ==========================================
    // Z-Basis Arm: Reflected at 90° from Bob BS (3.6, 0.0) into PBS 1 (3.6, -1.1)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(3.6, beamY, 0.0),
      end: new THREE.Vector3(3.6, beamY, -1.1),
      color: beamColor,
    });
    // PBS 1 to SPAD 1 (3.6, -1.95) [Horizontal polarization detection]
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(3.6, beamY, -1.1),
      end: new THREE.Vector3(3.6, beamY, -1.95),
      color: beamColor,
    });
    // PBS 1 to SPAD 2 (4.5, -1.1) [Vertical polarization detection]
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(3.6, beamY, -1.1),
      end: new THREE.Vector3(4.5, beamY, -1.1),
      color: beamColor,
    });

    // X-Basis Arm: Transmitted through Bob BS (3.6, 0.0) through F, HWP, into PBS 2 (5.75, 0.0)
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(3.6, beamY, 0.0),
      end: new THREE.Vector3(5.75, beamY, 0.0),
      color: beamColor,
    });
    // PBS 2 to SPAD 3 (5.75, -1.1) [Anti-diagonal polarization detection]
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(5.75, beamY, 0.0),
      end: new THREE.Vector3(5.75, beamY, -1.1),
      color: beamColor,
    });
    // PBS 2 to SPAD 4 (6.65, 0.0) [Diagonal polarization detection]
    this.beamRenderer.addBeamSegment({
      start: new THREE.Vector3(5.75, beamY, 0.0),
      end: new THREE.Vector3(6.65, beamY, 0.0),
      color: beamColor,
    });
  }

  public setSimulationState(stateLabel: 'H' | 'V' | 'D' | 'A', bobBasis: 'Z' | 'X', _eveActive?: boolean): void {
    this.activeStateLabel = stateLabel;
    this.bobBasis = bobBasis;

    if (this.bobHwpGroup) {
      // Half-Wave Plate fast axis oriented at 22.5° for diagonal-to-rectilinear basis rotation
      this.bobHwpGroup.rotation.z = bobBasis === 'X' ? (Math.PI / 8) : 0;
    }

    const arrow = this.photonMesh.children[2] as THREE.Mesh;
    if (arrow) {
      if (stateLabel === 'H') arrow.rotation.set(0, 0, Math.PI / 2);
      else if (stateLabel === 'V') arrow.rotation.set(0, 0, 0);
      else if (stateLabel === 'D') arrow.rotation.set(0, 0, Math.PI / 4);
      else arrow.rotation.set(0, 0, -Math.PI / 4);
    }
  }

  public update(timeSeconds: number, delta: number): void {
    this.beamRenderer.update(timeSeconds);

    // Traveling single photon packet along active beam trajectory
    this.photonProgress = (this.photonProgress + delta * 0.35) % 1.0;
    const beamY = 0.32 + 0.50;

    // Define waypoints along the straight physical path
    let waypoints: THREE.Vector3[] = [];

    if (this.activeStateLabel === 'H') {
      waypoints = [
        new THREE.Vector3(-7.2, beamY, 0.7),
        new THREE.Vector3(-5.0, beamY, 0.7),
        new THREE.Vector3(-2.8, beamY, 0.0),
        new THREE.Vector3(2.0, beamY, 0.0),
        new THREE.Vector3(3.6, beamY, 0.0),
      ];
    } else if (this.activeStateLabel === 'V') {
      waypoints = [
        new THREE.Vector3(-5.0, beamY, 1.55),
        new THREE.Vector3(-5.0, beamY, 0.7),
        new THREE.Vector3(-2.8, beamY, 0.0),
        new THREE.Vector3(2.0, beamY, 0.0),
        new THREE.Vector3(3.6, beamY, 0.0),
      ];
    } else if (this.activeStateLabel === 'A') {
      waypoints = [
        new THREE.Vector3(-7.2, beamY, -0.7),
        new THREE.Vector3(-5.0, beamY, -0.7),
        new THREE.Vector3(-2.8, beamY, 0.0),
        new THREE.Vector3(2.0, beamY, 0.0),
        new THREE.Vector3(3.6, beamY, 0.0),
      ];
    } else {
      waypoints = [
        new THREE.Vector3(-5.0, beamY, -1.55),
        new THREE.Vector3(-5.0, beamY, -0.7),
        new THREE.Vector3(-2.8, beamY, 0.0),
        new THREE.Vector3(2.0, beamY, 0.0),
        new THREE.Vector3(3.6, beamY, 0.0),
      ];
    }

    // Add Bob's detection arm based on measurement basis
    if (this.bobBasis === 'Z') {
      waypoints.push(new THREE.Vector3(3.6, beamY, -1.1));
      waypoints.push(this.activeStateLabel === 'H' ? new THREE.Vector3(3.6, beamY, -1.95) : new THREE.Vector3(4.5, beamY, -1.1));
    } else {
      waypoints.push(new THREE.Vector3(5.75, beamY, 0.0));
      waypoints.push(this.activeStateLabel === 'D' ? new THREE.Vector3(6.65, beamY, 0.0) : new THREE.Vector3(5.75, beamY, -1.1));
    }

    // Interpolate photon position along waypoints
    const totalSegments = waypoints.length - 1;
    const progressSegment = this.photonProgress * totalSegments;
    const segIndex = Math.min(Math.floor(progressSegment), totalSegments - 1);
    const segT = progressSegment - segIndex;

    const pA = waypoints[segIndex];
    const pB = waypoints[segIndex + 1];
    this.photonMesh.position.lerpVectors(pA, pB, segT);
    this.photonMesh.rotation.y = timeSeconds * 2.0;

    const halo = this.photonMesh.children[1] as THREE.Mesh;
    if (halo && halo.material instanceof THREE.MeshBasicMaterial) {
      const isDiag = this.activeStateLabel === 'D' || this.activeStateLabel === 'A';
      halo.material.color.setHex(isDiag ? 0xf59e0b : 0x38bdf8);
    }
  }

  public getInteractiveObjects(): THREE.Object3D[] {
    return this.interactiveObjects;
  }
}
