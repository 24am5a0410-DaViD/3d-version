import { Complex } from '../math/complex';
import { Matrix2x2 } from '../math/matrix2x2';
import { Vector2 } from '../math/vector2';

/**
 * Optical Elements represented via Jones Calculus and Quantum Transformation Matrices.
 */
export class Optics {
  /**
   * Linear Polarizer oriented at angle theta (radians).
   * J_pol(θ) = [ [cos²θ, cosθ sinθ], [cosθ sinθ, sin²θ] ]
   */
  static polarizer(thetaRad: number): Matrix2x2 {
    const c = Math.cos(thetaRad);
    const s = Math.sin(thetaRad);
    return Matrix2x2.fromReals(c * c, c * s, c * s, s * s);
  }

  /** Horizontal Polarizer (θ = 0) */
  static readonly POLARIZER_H = Optics.polarizer(0);

  /** Vertical Polarizer (θ = π/2) */
  static readonly POLARIZER_V = Optics.polarizer(Math.PI / 2);

  /** Diagonal Polarizer (θ = +π/4) */
  static readonly POLARIZER_D = Optics.polarizer(Math.PI / 4);

  /** Anti-Diagonal Polarizer (θ = -π/4) */
  static readonly POLARIZER_A = Optics.polarizer(-Math.PI / 4);

  /**
   * Half-Wave Plate (HWP) with fast axis at angle theta (radians).
   * Imparts a phase difference of π between orthogonal polarization components.
   * J_HWP(θ) = [ [cos 2θ, sin 2θ], [sin 2θ, -cos 2θ] ]
   */
  static halfWavePlate(thetaRad: number): Matrix2x2 {
    const c2 = Math.cos(2 * thetaRad);
    const s2 = Math.sin(2 * thetaRad);
    return Matrix2x2.fromReals(c2, s2, s2, -c2);
  }

  /**
   * Quarter-Wave Plate (QWP) with fast axis at angle theta (radians).
   * Imparts a phase difference of π/2 between orthogonal components.
   */
  static quarterWavePlate(thetaRad: number): Matrix2x2 {
    const c = Math.cos(thetaRad);
    const s = Math.sin(thetaRad);
    // Standard QWP matrix e^(-i π/4) * [ [cos²θ + i sin²θ, (1 - i) sinθ cosθ], ... ]
    return new Matrix2x2(
      new Complex(c * c, s * s),
      new Complex((1 - 0) * s * c, -s * c),
      new Complex((1 - 0) * s * c, -s * c),
      new Complex(s * s, c * c)
    );
  }

  /**
   * Phase Modulator (PM) imparting relative phase shift phi (radians) on horizontal axis.
   * J_PM(φ) = [ [e^(iφ), 0], [0, 1] ]
   */
  static phaseModulator(phiRad: number): Matrix2x2 {
    return new Matrix2x2(
      Complex.fromPolar(1, phiRad),
      Complex.ZERO,
      Complex.ZERO,
      Complex.ONE
    );
  }

  /**
   * Amplitude Modulator / Optical Attenuator (AM).
   * Attenuates field amplitude by sqrt(transmission), where transmission T in [0, 1].
   * Used in BB84 transmitters to attenuate laser pulses down to mean photon number μ << 1.
   */
  static attenuator(transmission: number): Matrix2x2 {
    const factor = Math.sqrt(Math.max(0, Math.min(1, transmission)));
    return Matrix2x2.fromReals(factor, 0, 0, factor);
  }

  /**
   * Ideal 50:50 Non-Polarizing Beam Splitter (BS).
   * Spatial 2-mode unitary coupling: 1/√2 [ [1, i], [i, 1] ]
   */
  static readonly BEAM_SPLITTER_5050 = new Matrix2x2(
    new Complex(1 / Math.SQRT2, 0),
    new Complex(0, 1 / Math.SQRT2),
    new Complex(0, 1 / Math.SQRT2),
    new Complex(1 / Math.SQRT2, 0)
  );

  /**
   * Polarizing Beam Splitter (PBS).
   * Transmits Horizontal polarization (|H⟩ = |0⟩) to port 0,
   * Reflects Vertical polarization (|V⟩ = |1⟩) to port 1.
   */
  static pbsSplit(state: Vector2): { portH: Vector2; portV: Vector2; probH: number; probV: number } {
    const projH = state.applyMatrix(Optics.POLARIZER_H);
    const projV = state.applyMatrix(Optics.POLARIZER_V);
    const probH = projH.normSq();
    const probV = projV.normSq();
    return {
      portH: projH.normalize(),
      portV: projV.normalize(),
      probH,
      probV,
    };
  }

  /**
   * Single-Photon Avalanche Diode (SPAD) detection model.
   * Takes an incoming photon state or pulse, detector quantum efficiency η,
   * dark count probability per gate pDark, and returns whether an avalanche breakdown occurred.
   */
  static spadDetect(
    incomingIntensity: number,
    quantumEfficiency: number = 0.65,
    darkCountProb: number = 1e-4,
    randomSample: number = Math.random()
  ): boolean {
    const detectionProb = 1 - (1 - darkCountProb) * Math.exp(-quantumEfficiency * incomingIntensity);
    return randomSample < detectionProb;
  }
}
