import React, { useState } from 'react';
import { useAppStore } from '../state/store';
import { CURRICULUM } from '../lessons/curriculum';
import { MathFormula } from './MathFormula';
import { 
  BookOpen, 
  Sparkles, 
  Target, 
  Bookmark, 
  ChevronLeft, 
  ChevronRight
} from 'lucide-react';

export const CurriculumSidebar: React.FC = () => {
  const { currentLessonId, dualDepthMode, setDualDepthMode } = useAppStore();
  const [collapsed, setCollapsed] = useState(false);

  const lesson = CURRICULUM[currentLessonId] || CURRICULUM[0];

  return (
    <aside
      className={`fixed top-16 right-6 z-20 max-w-sm w-full bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-2xl transition-all duration-300 overflow-hidden text-slate-100 ${
        collapsed ? 'translate-x-[calc(100%-48px)] opacity-80' : 'translate-x-0'
      }`}
    >
      {/* Top Header & Collapse Toggle */}
      <div className="flex items-center justify-between p-3.5 bg-slate-800/80 border-b border-slate-700">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1 rounded-lg hover:bg-slate-700 text-slate-300 hover:text-white transition flex items-center space-x-1"
        >
          {collapsed ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
          {collapsed && <span className="text-xs font-bold uppercase tracking-wider">Lesson Guide</span>}
        </button>

        {!collapsed && (
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-blue-950 text-blue-400 border border-blue-800">
              Module {lesson.id} of 9
            </span>
          </div>
        )}
      </div>

      {!collapsed && (
        <div className="p-4 space-y-4 max-h-[calc(100vh-280px)] overflow-y-auto">
          {/* Title & Subtitle */}
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">{lesson.title}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{lesson.subtitle}</p>
          </div>

          {/* Dual-Depth Toggle: ELI12 vs Show Me The Math */}
          <div className="grid grid-cols-2 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setDualDepthMode('eli12')}
              className={`flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition ${
                dualDepthMode === 'eli12'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Explain Like I'm 12</span>
            </button>
            <button
              onClick={() => setDualDepthMode('math')}
              className={`flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition ${
                dualDepthMode === 'math'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span>Show Me The Math</span>
            </button>
          </div>

          {/* Explanatory Body */}
          <div className="text-xs leading-relaxed text-slate-300">
            {dualDepthMode === 'eli12' ? (
              <div className="bg-slate-800/40 p-3.5 rounded-xl border border-slate-800/80 space-y-2">
                <div className="font-semibold text-amber-300 flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Intuitive Analogy</span>
                </div>
                <p>{lesson.eli12Intuition}</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-2">
                  <div className="font-bold text-cyan-300 text-[11px] uppercase tracking-wider">
                    {lesson.formalMathTitle}
                  </div>
                  <div className="py-1 text-center overflow-x-auto">
                    <MathFormula block math={lesson.formalMathLatex} />
                  </div>
                </div>

                <div className="space-y-1.5 pl-2 border-l-2 border-cyan-500/40">
                  {lesson.formalMathDerivation.map((step, idx) => (
                    <p key={idx} className="text-[11px] text-slate-300 leading-snug">
                      • {step}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Interactive Challenge Prompt */}
          <div className="bg-cyan-950/40 border border-cyan-700/50 p-3 rounded-xl space-y-1 text-xs">
            <div className="flex items-center space-x-1.5 text-cyan-300 font-bold uppercase tracking-wider text-[10px]">
              <Target className="w-3.5 h-3.5" />
              <span>Interactive Mission Goal</span>
            </div>
            <p className="text-slate-200 text-[11px]">{lesson.interactiveGoal}</p>
          </div>

          {/* Citations & Source Papers */}
          <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
            <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider flex items-center space-x-1">
              <Bookmark className="w-3 h-3 text-slate-400" />
              <span>Academic References</span>
            </span>
            {lesson.references.map((ref, idx) => (
              <div key={idx} className="text-[10px] text-slate-400 flex items-start space-x-1">
                <span>[{idx + 1}]</span>
                <span className="text-slate-300 font-medium">"{ref.title}"</span> — {ref.citation} ({ref.year})
              </div>
            ))}
          </div>
        </div>
      )}
    </aside>
  );
};
