import React, { useEffect, useRef, useState } from 'react';
import { SceneManager } from './scenes/SceneManager';
import { useAppStore } from './state/store';
import { Vector2 } from './core/math/vector2';

import { NavigationHeader } from './ui/NavigationHeader';
import { MetricsHUD } from './ui/MetricsHUD';
import { CurriculumSidebar } from './ui/CurriculumSidebar';
import { ComponentInspector } from './ui/ComponentInspector';
import { BlueMathPanel } from './ui/BlueMathPanel';
import { SandboxControls } from './ui/SandboxControls';
import { QuizModal } from './ui/QuizModal';
import { BB84ProtocolApp } from './bb84-protocol/BB84ProtocolApp';

export const App: React.FC = () => {
  // Master Section State: 'testbench' (3D Tabletop Setup) vs 'bb84-protocol' (WISER Challenge & Streamlit)
  const [activeMasterSection, setActiveMasterSection] = useState<'testbench' | 'bb84-protocol'>('testbench');
  
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const sceneManagerRef = useRef<SceneManager | null>(null);

  const {
    activeSceneId,
    satelliteZoomMode,
    aliceSelectedState,
    bobSelectedBasis,
    eveActive,
    isContinuousRunning,
    stepSinglePulse,
    runBatchSimulation,
    setSelectedComponent,
  } = useAppStore();

  // Initialize Three.js WebGL SceneManager
  useEffect(() => {
    if (!canvasContainerRef.current) return;

    const manager = new SceneManager(canvasContainerRef.current, {
      onSelectComponent: (comp) => setSelectedComponent(comp),
    });
    sceneManagerRef.current = manager;

    // Initial batch simulation to populate telemetry HUD
    runBatchSimulation(100);

    return () => {
      manager.dispose();
      sceneManagerRef.current = null;
    };
  }, []);

  // Sync Scene Selection
  useEffect(() => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setScene(activeSceneId);
    }
  }, [activeSceneId]);

  // Sync Satellite Zoom Mode
  useEffect(() => {
    if (sceneManagerRef.current && activeSceneId === 'satellite') {
      sceneManagerRef.current.setSatelliteZoom(satelliteZoomMode);
    }
  }, [satelliteZoomMode, activeSceneId]);

  // Sync Alice/Bob/Eve state in BB84 tabletop scene & Bloch sphere
  useEffect(() => {
    if (!sceneManagerRef.current) return;

    sceneManagerRef.current.bb84Scene.setSimulationState(
      aliceSelectedState,
      bobSelectedBasis,
      eveActive
    );

    // Map Alice's state to Bloch sphere
    let blochVec = Vector2.H;
    if (aliceSelectedState === 'V') blochVec = Vector2.V;
    else if (aliceSelectedState === 'D') blochVec = Vector2.D;
    else if (aliceSelectedState === 'A') blochVec = Vector2.A;
    sceneManagerRef.current.setBlochState(blochVec);
  }, [aliceSelectedState, bobSelectedBasis, eveActive]);

  // Continuous pulse loop when enabled
  useEffect(() => {
    if (!isContinuousRunning) return;
    const interval = setInterval(() => {
      stepSinglePulse();
    }, 600);
    return () => clearInterval(interval);
  }, [isContinuousRunning, stepSinglePulse]);

  const [showHUD, setShowHUD] = useState<boolean>(false);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#141822] select-none font-sans">
      {/* 3D WebGL Canvas Viewport (Kept mounted to preserve Three.js state) */}
      <div 
        ref={canvasContainerRef} 
        className={`absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing ${
          activeMasterSection === 'testbench' ? 'block' : 'hidden'
        }`}
      />

      {/* MASTER SECTION SWITCHER NAVBAR */}
      <header className="fixed top-3 left-1/2 -translate-x-1/2 z-[60] flex items-center bg-slate-900/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-700/80 shadow-2xl">
        <button
          onClick={() => setActiveMasterSection('testbench')}
          className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition ${
            activeMasterSection === 'testbench'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25 ring-1 ring-blue-400/50'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="Switch to 3D Tabletop Optical Testbench"
        >
          <span>🔬</span>
          <span>3D Optical Testbench</span>
          <span className="hidden sm:inline text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950/80 text-blue-200 border border-blue-400/30">
            Hardware
          </span>
        </button>

        <div className="w-[1px] h-5 bg-slate-700 mx-1.5" />

        <button
          onClick={() => setActiveMasterSection('bb84-protocol')}
          className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition ${
            activeMasterSection === 'bb84-protocol'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/25 ring-1 ring-indigo-400/50'
              : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
          }`}
          title="Switch to WISER BB84 Protocol Application"
        >
          <span>⚛️</span>
          <span>BB84 Protocol App</span>
          <span className="hidden sm:inline text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-950/80 text-indigo-200 border border-indigo-400/30">
            WISER Lab
          </span>
        </button>
      </header>

      {/* SECTION 1: 3D OPTICAL TESTBENCH OVERLAYS */}
      {activeMasterSection === 'testbench' && (
        <>
          {/* Floating View Mode Switcher */}
          <div className="fixed top-4 right-4 z-50 flex items-center space-x-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-xl">
            <button
              onClick={() => setShowHUD(false)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                !showHUD 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              📷 Exact Reference View
            </button>
            <button
              onClick={() => setShowHUD(true)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                showHUD 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              📊 Interactive Lab HUD
            </button>
          </div>

          {/* UI Overlays: Visible in HUD mode */}
          {showHUD && (
            <>
              <NavigationHeader />
              <MetricsHUD />
              <CurriculumSidebar />
              <ComponentInspector />
              <SandboxControls />
            </>
          )}
          <BlueMathPanel />
          <QuizModal />
        </>
      )}

      {/* SECTION 2: BB84 PROTOCOL APPLICATION (WISER CHALLENGE & STREAMLIT) */}
      {activeMasterSection === 'bb84-protocol' && (
        <div className="absolute inset-0 w-full h-full z-40 bg-[#0f172a] overflow-auto">
          <BB84ProtocolApp onBackToTestbench={() => setActiveMasterSection('testbench')} />
        </div>
      )}
    </div>
  );
};

export default App;
