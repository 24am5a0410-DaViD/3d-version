import { describe, it, expect } from 'vitest';
import { Complex } from '../core/math/complex';
import { Matrix2x2 } from '../core/math/matrix2x2';
import { Vector2 } from '../core/math/vector2';
import { Optics } from '../core/optics/jones';
import { BB84Engine } from '../core/protocol/bb84';
import { Channels } from '../core/channels/channel';

describe('Quantum Physics & Linear Algebra Core', () => {
  it('correctly calculates complex arithmetic', () => {
    const a = new Complex(3, 4);
    const b = new Complex(1, -2);
    const sum = a.add(b);
    expect(sum.r).toBe(4);
    expect(sum.i).toBe(2);

    const prod = a.mul(b); // (3+4i)(1-2i) = 3 - 6i + 4i - 8i^2 = 11 - 2i
    expect(prod.r).toBe(11);
    expect(prod.i).toBe(-2);
    expect(a.absSq()).toBe(25);
  });

  it('validates canonical BB84 states and Bloch sphere coordinates', () => {
    // |H> = |0> -> (0, 0, 1) North pole
    const blochH = Vector2.H.toBlochCoordinates();
    expect(blochH.z).toBeCloseTo(1, 5);
    expect(blochH.x).toBeCloseTo(0, 5);
    expect(blochH.y).toBeCloseTo(0, 5);

    // |V> = |1> -> (0, 0, -1) South pole
    const blochV = Vector2.V.toBlochCoordinates();
    expect(blochV.z).toBeCloseTo(-1, 5);

    // |+> = |D> -> (1, 0, 0) +X axis
    const blochD = Vector2.D.toBlochCoordinates();
    expect(blochD.x).toBeCloseTo(1, 5);
    expect(blochD.y).toBeCloseTo(0, 5);
    expect(blochD.z).toBeCloseTo(0, 5);

    // |-> = |A> -> (-1, 0, 0) -X axis
    const blochA = Vector2.A.toBlochCoordinates();
    expect(blochA.x).toBeCloseTo(-1, 5);
    expect(blochA.y).toBeCloseTo(0, 5);
    expect(blochA.z).toBeCloseTo(0, 5);
  });

  /**
   * EXACT PROOF FROM REFERENCE IMAGE 2:
   * [M+, M0] = |+><+| |0><0| - |0><0| |+><+|
   *          = 1/2 [ [0, -1], [1, 0] ] != 0
   */
  it('verifies non-commuting measurement operators from Image 2', () => {
    const M_plus = Vector2.D.projector(); // |+><+|
    const M_zero = Vector2.H.projector(); // |0><0|

    const commutator = Matrix2x2.commutator(M_plus, M_zero);

    // Theoretical expected result: 1/2 * [ [0, -1], [1, 0] ]
    const expected = Matrix2x2.fromReals(0, -0.5, 0.5, 0);

    expect(commutator.equals(expected, 1e-6)).toBe(true);
    expect(commutator.isZero()).toBe(false); // Does NOT commute!
  });

  it('verifies optical Jones transformations (HWP at 45 deg flips H to V)', () => {
    // Half-wave plate at 45° (π/4)
    const hwp45 = Optics.halfWavePlate(Math.PI / 4);
    const transformedH = Vector2.H.applyMatrix(hwp45);

    // Should transform |H> to |V>
    expect(transformedH.probabilityOf(Vector2.V)).toBeCloseTo(1.0, 5);
    expect(transformedH.probabilityOf(Vector2.H)).toBeCloseTo(0.0, 5);
  });

  it('runs BB84 without Eve and achieves ~0% QBER and ~50% sifting', () => {
    const sim = BB84Engine.runSimulation({
      pulseCount: 1000,
      eveInterceptRate: 0.0,
      channelLossDb: 0.0,
      detectorEfficiency: 1.0,
      darkCountRate: 0.0,
      abortThreshold: 0.11,
      seed: 9999,
    });

    // Sifting should be ~50% (between 42% and 58%)
    const siftingRatio = sim.siftedBits / sim.totalSent;
    expect(siftingRatio).toBeGreaterThan(0.42);
    expect(siftingRatio).toBeLessThan(0.58);

    // Zero Eve and ideal channel -> 0% QBER
    expect(sim.qber).toBe(0.0);
    expect(sim.aborted).toBe(false);
    expect(sim.secretKeyLength).toBeGreaterThan(0);
  });

  it('proves theoretical ~25% QBER under full Intercept-Resend attack', () => {
    const sim = BB84Engine.runSimulation({
      pulseCount: 4000,
      eveInterceptRate: 1.0, // 100% intercept-resend
      channelLossDb: 0.0,
      detectorEfficiency: 1.0,
      darkCountRate: 0.0,
      abortThreshold: 0.11, // 11% standard security threshold
      seed: 777,
    });

    // Expected theoretical QBER is 25% (0.25)
    expect(sim.qber).toBeGreaterThan(0.22);
    expect(sim.qber).toBeLessThan(0.28);
    // Protocol must trigger abort!
    expect(sim.aborted).toBe(true);
    expect(sim.secretKeyLength).toBe(0);
  });

  it('computes realistic satellite link budget vs exponential fiber loss', () => {
    // Terrestrial fiber @ 850 nm over 100 km
    const fiber100km = Channels.fiberTransmission(100, 850);
    // Loss is 220 dB -> transmittance is 10^-22
    expect(fiber100km.lossDb).toBeCloseTo(220, 5);
    expect(fiber100km.transmittance).toBeLessThan(1e-20);

    // Satellite at 550 km LEO orbit (Jinan-1 specs)
    const satLink = Channels.satelliteLinkBudget(550, 0.18, 1.0, 850);
    // Total free-space link loss is around 25-35 dB, which is billions of times higher transmission than 100km fiber!
    expect(satLink.totalLossDb).toBeGreaterThan(20);
    expect(satLink.totalLossDb).toBeLessThan(45);
    expect(satLink.transmittance).toBeGreaterThan(1e-5);
  });
});
