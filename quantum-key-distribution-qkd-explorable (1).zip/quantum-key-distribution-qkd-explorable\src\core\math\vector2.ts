import { Complex } from './complex';
import { Matrix2x2 } from './matrix2x2';

/**
 * 2D Complex State Vector / Jones Vector.
 * Represents qubit state |ψ⟩ = c0|0⟩ + c1|1⟩ = [c0, c1]^T
 * In optical polarization:
 *   |0⟩ = |H⟩ (horizontal)
 *   |1⟩ = |V⟩ (vertical)
 */
export class Vector2 {
  readonly c0: Complex;
  readonly c1: Complex;

  constructor(c0: Complex, c1: Complex) {
    this.c0 = c0;
    this.c1 = c1;
  }

  // Canonical BB84 States
  /** Horizontal Polarization |H⟩ = |0⟩ */
  static readonly H = new Vector2(Complex.ONE, Complex.ZERO);
  /** Vertical Polarization |V⟩ = |1⟩ */
  static readonly V = new Vector2(Complex.ZERO, Complex.ONE);
  /** Diagonal (+45°) Polarization |D⟩ = |+⟩ = 1/√2 (|0⟩ + |1⟩) */
  static readonly D = new Vector2(
    new Complex(1 / Math.SQRT2, 0),
    new Complex(1 / Math.SQRT2, 0)
  );
  /** Anti-Diagonal (-45°) Polarization |A⟩ = |-⟩ = 1/√2 (|0⟩ - |1⟩) */
  static readonly A = new Vector2(
    new Complex(1 / Math.SQRT2, 0),
    new Complex(-1 / Math.SQRT2, 0)
  );

  /** Right-Hand Circular Polarization |R⟩ = 1/√2 (|H⟩ - i|V⟩) */
  static readonly R = new Vector2(
    new Complex(1 / Math.SQRT2, 0),
    new Complex(0, -1 / Math.SQRT2)
  );
  /** Left-Hand Circular Polarization |L⟩ = 1/√2 (|H⟩ + i|V⟩) */
  static readonly L = new Vector2(
    new Complex(1 / Math.SQRT2, 0),
    new Complex(0, 1 / Math.SQRT2)
  );

  /** Inner product ⟨this|other⟩ */
  inner(other: Vector2): Complex {
    return this.c0.conj().mul(other.c0).add(this.c1.conj().mul(other.c1));
  }

  /** Outer product |this⟩⟨other| returning a 2x2 matrix */
  outer(other: Vector2): Matrix2x2 {
    return new Matrix2x2(
      this.c0.mul(other.c0.conj()),
      this.c0.mul(other.c1.conj()),
      this.c1.mul(other.c0.conj()),
      this.c1.mul(other.c1.conj())
    );
  }

  /** Projector M = |this⟩⟨this| */
  projector(): Matrix2x2 {
    return this.outer(this);
  }

  /** Multiplies a 2x2 matrix by this vector: M|ψ⟩ */
  applyMatrix(m: Matrix2x2): Vector2 {
    return new Vector2(
      m.m00.mul(this.c0).add(m.m01.mul(this.c1)),
      m.m10.mul(this.c0).add(m.m11.mul(this.c1))
    );
  }

  normSq(): number {
    return this.c0.absSq() + this.c1.absSq();
  }

  norm(): number {
    return Math.sqrt(this.normSq());
  }

  normalize(): Vector2 {
    const n = this.norm();
    if (n < 1e-12) return new Vector2(Complex.ZERO, Complex.ZERO);
    return new Vector2(this.c0.scale(1 / n), this.c1.scale(1 / n));
  }

  /**
   * Probability of obtaining state |other⟩ when measuring |this⟩ (Born's Rule):
   * P = |⟨other|this⟩|²
   */
  probabilityOf(other: Vector2): number {
    const dot = other.inner(this);
    return dot.absSq();
  }

  /**
   * Computes coordinates on the Bloch sphere (x, y, z) where:
   * x = 2 * Re(c0* · c1)
   * y = 2 * Im(c0* · c1)
   * z = |c0|² - |c1|²
   */
  toBlochCoordinates(): { x: number; y: number; z: number; theta: number; phi: number } {
    const norm = this.norm();
    if (norm < 1e-9) return { x: 0, y: 0, z: 1, theta: 0, phi: 0 };
    const n0 = this.c0.scale(1 / norm);
    const n1 = this.c1.scale(1 / norm);

    const cross = n0.conj().mul(n1);
    const x = 2 * cross.r;
    const y = 2 * cross.i;
    const z = n0.absSq() - n1.absSq();

    const theta = Math.acos(Math.max(-1, Math.min(1, z)));
    const phi = Math.atan2(y, x);

    return { x, y, z, theta, phi };
  }

  equals(other: Vector2, tolerance: number = 1e-6): boolean {
    return this.c0.equals(other.c0, tolerance) && this.c1.equals(other.c1, tolerance);
  }

  toLatex(): string {
    const fmt = (c: Complex) => {
      if (Math.abs(c.i) < 1e-5) return c.r.toFixed(3);
      if (Math.abs(c.r) < 1e-5) return `${c.i < 0 ? '-' : ''}${Math.abs(c.i).toFixed(3)}i`;
      return `${c.r.toFixed(3)}${c.i >= 0 ? '+' : ''}${c.i.toFixed(3)}i`;
    };
    return `\\begin{pmatrix} ${fmt(this.c0)} \\\\ ${fmt(this.c1)} \\end{pmatrix}`;
  }
}
