import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

// Attach to window for standalone HTML scripts
(window as any).THREE = THREE;
(window as any).OrbitControls = OrbitControls;
