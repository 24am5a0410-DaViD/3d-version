import React from 'react';
import { useAppStore } from '../state/store';
import { ShieldCheck, ShieldAlert, Key, Activity, Check, X } from 'lucide-react';

export const MetricsHUD: React.FC = () => {
  const { simulationResult, recentPulses, abortThreshold } = useAppStore();

  const totalSent = simulationResult?.totalSent ?? 0;
  const totalDetected = simulationResult?.totalDetected ?? 0;
  const siftedBits = simulationResult?.siftedBits ?? 0;
  const qber = simulationResult?.qber ?? 0;
  const isAborted = simulationResult?.aborted ?? false;
  const secretKeyLength = simulationResult?.secretKeyLength ?? 0;
  const finalSecretKey = simulationResult?.finalSecretKey ?? '';

  const qberPercent = (qber * 100).toFixed(1);
  const abortPercent = (abortThreshold * 100).toFixed(0);

  return (
    <div className="fixed top-16 left-6 z-30 max-w-sm w-full space-y-3 pointer-events-auto">
      {/* Primary Status Card */}
      <div className={`p-4 rounded-2xl border backdrop-blur-md transition-all shadow-xl ${
        isAborted
          ? 'bg-rose-950/80 border-rose-500/80 text-rose-100 shadow-rose-900/30 animate-pulse'
          : 'bg-slate-900/85 border-slate-700/80 text-slate-100'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            {isAborted ? (
              <ShieldAlert className="w-5 h-5 text-rose-400" />
            ) : (
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            )}
            <span className="font-bold text-xs uppercase tracking-wider">
              {isAborted ? 'PROTOCOL ABORTED' : 'SECURE QUANTUM CHANNEL'}
            </span>
          </div>
          <div className="text-[11px] px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 font-mono">
            Limit: {abortPercent}%
          </div>
        </div>

        {/* QBER and Sifted Metrics Grid */}
        <div className="grid grid-cols-2 gap-2 mt-3 text-center">
          <div className="bg-slate-950/50 p-2 rounded-xl border border-slate-800">
            <div className="text-[10px] uppercase text-slate-400 font-medium">QBER (Error Rate)</div>
            <div className={`text-xl font-extrabold font-mono ${
              qber > abortThreshold ? 'text-rose-400' : 'text-emerald-400'
            }`}>
              {qberPercent}%
            </div>
          </div>

          <div className="bg-slate-950/50 p-2 rounded-xl border border-slate-800">
            <div className="text-[10px] uppercase text-slate-400 font-medium">Sifted Bits (Det: {totalDetected})</div>
            <div className="text-xl font-extrabold font-mono text-cyan-400">
              {siftedBits} <span className="text-xs text-slate-500 font-normal">/ {totalSent}</span>
            </div>
          </div>
        </div>

        {/* Distilled Secret Key Display */}
        <div className="mt-3 pt-3 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
            <span className="flex items-center space-x-1">
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span>Distilled Secret Key ({secretKeyLength} bits):</span>
            </span>
          </div>
          <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-amber-300 break-all select-all min-h-[36px] flex items-center">
            {finalSecretKey ? (
              <span>0x{finalSecretKey}</span>
            ) : isAborted ? (
              <span className="text-rose-400 text-[11px] italic">Destroyed due to eavesdropping threat</span>
            ) : (
              <span className="text-slate-500 text-[11px] italic">Awaiting pulse distillation...</span>
            )}
          </div>
        </div>
      </div>

      {/* Mini Pulse Reconciliation Table */}
      <div className="bg-slate-900/85 border border-slate-800/80 p-3 rounded-2xl backdrop-blur-md shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>Sifting Table (Recent Pulses)</span>
          </span>
          <span className="text-[10px] text-slate-500 font-mono">Last {recentPulses.length}</span>
        </div>

        <div className="overflow-x-auto max-h-36 overflow-y-auto pr-1">
          <table className="w-full text-center text-[10px] font-mono">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800">
                <th className="py-1">#</th>
                <th>Alice</th>
                <th>Eve</th>
                <th>Bob</th>
                <th>Match</th>
                <th>Sifted</th>
              </tr>
            </thead>
            <tbody>
              {recentPulses.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-3 text-slate-500 italic">Press "Step Pulse" to transmit</td>
                </tr>
              ) : (
                recentPulses.map((p) => (
                  <tr key={p.id} className="border-b border-slate-800/40 hover:bg-slate-800/30">
                    <td className="py-0.5 text-slate-500">{p.id}</td>
                    <td>
                      <span className="font-bold text-cyan-400">{p.aliceBit}</span>
                      <span className="text-slate-400 text-[9px] ml-0.5">({p.aliceBasis === 'Z' ? '+' : '×'})</span>
                    </td>
                    <td>
                      {p.eveIntercepted ? (
                        <span className="text-rose-400 font-bold">Spy</span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </td>
                    <td>
                      {p.bobDetected && p.bobBit !== undefined ? (
                        <>
                          <span className={p.isError ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                            {p.bobBit}
                          </span>
                          <span className="text-slate-400 text-[9px] ml-0.5">({p.bobBasis === 'Z' ? '+' : '×'})</span>
                        </>
                      ) : (
                        <span className="text-slate-600">Lost</span>
                      )}
                    </td>
                    <td>
                      {p.basesMatch ? (
                        <Check className="w-3 h-3 text-emerald-400 mx-auto" />
                      ) : (
                        <X className="w-3 h-3 text-slate-600 mx-auto" />
                      )}
                    </td>
                    <td>
                      {p.isSifted ? (
                        <span className={`px-1 rounded text-[9px] font-bold ${
                          p.isError ? 'bg-rose-900/60 text-rose-300' : 'bg-emerald-900/60 text-emerald-300'
                        }`}>
                          {p.isError ? 'ERR' : 'OK'}
                        </span>
                      ) : (
                        <span className="text-slate-600 text-[9px]">Drop</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
