/**
 * bb84Data.ts — Theory modules, adaptive quiz bank, evaluation tests, personas,
 * roadmap, open source citations, and educational content from WISER BB84 Lab.
 */

export interface TheorySection {
  id: number;
  title: string;
  subtitle: string;
  summary: string;
  takeaways: string[];
  content: string;
}

export const THEORY_SECTIONS: TheorySection[] = [
  {
    id: 1,
    title: '1. What is a Bit?',
    subtitle: 'From classical states to quantum superposition',
    summary: 'Classical bits exist deterministically as 0 or 1. Qubits exist as vectors in a 2D Hilbert space.',
    takeaways: [
      'A classical bit is an answer to a yes/no question.',
      'A qubit is a state vector |ψ⟩ = α|0⟩ + β|1⟩.',
      'Measurement irreversibly collapses the state onto the basis vector.',
    ],
    content: `A bit is the simplest unit of information: a choice between two mutually exclusive alternatives, written 0 and 1. In a computer, bits are stored as voltage levels or magnetic domains. In quantum mechanics, a bit can be encoded into physical degrees of freedom of a single photon, such as its polarization angle. Unlike classical bits, quantum states obey the superposition principle until measured.`,
  },
  {
    id: 2,
    title: '2. The One-Time Pad',
    subtitle: 'Information-theoretic secrecy vs computational complexity',
    summary: 'The Vernam cipher provides perfect secrecy if and only if the key is truly random, never reused, and as long as the message.',
    takeaways: [
      'C = P ⊕ K guarantees Shannon perfect secrecy.',
      'Classical public-key cryptosystems (RSA, ECC) rely on computational hardness that quantum computers break.',
      'The key distribution problem: how to share a random key without an eavesdropper intercepting it.',
    ],
    content: `In 1917, Gilbert Vernam invented the One-Time Pad (OTP). Claude Shannon mathematically proved in 1949 that if key K is uniformly random, used once, and kept secret, the ciphertext C reveals zero information about the plaintext P. The fatal weakness of the OTP in classical communication has always been key exchange: how can Alice send the key to Bob without an eavesdropper intercepting it? This is exactly the problem QKD solves.`,
  },
  {
    id: 3,
    title: '3. Polarisation & Conjugate Bases',
    subtitle: 'Why measurement destroys quantum information',
    summary: 'Rectilinear (+) and Diagonal (×) are non-commuting conjugate bases separated by 45°.',
    takeaways: [
      'Rectilinear (+) basis encodes |H⟩ (0°) as 0 and |V⟩ (90°) as 1.',
      'Diagonal (×) basis encodes |D⟩ (45°) as 0 and |A⟩ (135°) as 1.',
      'Measuring a (+) photon in the (×) basis yields 50/50 random output and erases the original polarization.',
    ],
    content: `Polarization describes the oscillation plane of a photon's electric field. BB84 uses four polarization states organized into two non-orthogonal bases: Rectilinear (+) and Diagonal (×). Because |⟨H|D⟩|² = 1/2, a photon prepared in |H⟩ measured with diagonal filters has an equal 50% probability of collapsing to |D⟩ or |A⟩. The Heisenberg uncertainty principle and No-Cloning Theorem prevent measuring both bases simultaneously.`,
  },
  {
    id: 4,
    title: '4. The BB84 Protocol',
    subtitle: 'Bennett and Brassard (1984) five-step workflow',
    summary: 'Preparation, Transmission, Measurement, Sifting, and Error Estimation.',
    takeaways: [
      'Alice prepares photons in random states across random bases.',
      'Bob measures each photon in an independently chosen basis.',
      'They publicly announce bases (not bits) and discard mismatches (~50% sifting rate).',
      'They sample a subset to measure Quantum Bit Error Rate (QBER).',
    ],
    content: `Charles Bennett and Gilles Brassard published BB84 in 1984. The protocol relies on quantum mechanics rather than mathematical difficulty:
1. Alice generates random bits and chooses random bases (+ or ×).
2. Alice sends polarized photons over a quantum channel.
3. Bob measures incoming photons in his independently chosen random bases.
4. Sifting: Alice and Bob publicly announce bases over an authenticated channel. Only bits where bases matched are retained (~50% of total).
5. Error Estimation: A fraction of sifted bits are revealed to calculate QBER.`,
  },
  {
    id: 5,
    title: '5. The Eavesdropper & Why QBER = p/4',
    subtitle: 'The intercept-resend attack and mathematical error footprint',
    summary: 'Eve measuring a fraction p of photons unavoidably introduces a QBER of p / 4.',
    takeaways: [
      'No-Cloning prevents Eve from copying photons unnoticed.',
      'If Eve intercepts, she guesses wrong basis 50% of the time.',
      'When Eve guesses wrong and Bob measures in Alice’s basis, Bob gets a bit error 50% of the time.',
      'Total Error Rate = p × 1/2 × 1/2 = p/4 (25% for full intercept).',
    ],
    content: `Suppose Eve executes an Intercept-Resend attack on a fraction p of photons.
Because Eve does not know Alice's basis, she chooses randomly between + and ×.
- 50% of the time Eve chooses the correct basis: she reads the bit correctly and resends the exact state. No error occurs.
- 50% of the time Eve chooses the wrong basis: the photon collapses into Eve's basis.
When Alice and Bob's bases agree, Bob measures this altered photon in Alice's basis:
- 50% of those times Bob gets the correct bit by chance.
- 50% of those times Bob gets the wrong bit (bit flip error).
Therefore, the error rate introduced into the sifted key is:
QBER = p × (1/2) × (1/2) = p / 4.
When Eve intercepts 100% of photons (p = 1.0), QBER is exactly 25.00%!`,
  },
  {
    id: 6,
    title: '6. The Math of QKD & Shor–Preskill Bound',
    subtitle: 'Information distillation, privacy amplification, and 11% threshold',
    summary: 'Above 11.00% QBER, classical post-processing cannot distill a provably secure key.',
    takeaways: [
      'Shor–Preskill security proof establishes the 11% error tolerance limit.',
      'Error correction (CASCADE, Winnow) reconciles bit discrepancies.',
      'Privacy amplification hashes the reconciled key to eliminate Eve’s mutual information.',
      'If QBER > 11%, Alice and Bob must abort the key exchange.',
    ],
    content: `In 2000, Peter Shor and John Preskill proved the unconditional security of BB84 against all collective and coherent quantum attacks. The asymptotic secret key generation rate is:
R = 1 - 2·h(QBER), where h(x) is binary Shannon entropy.
When QBER ≈ 11.00%, h(0.11) ≈ 0.5, and R drops to 0. Above 11%, Eve possesses more mutual information with Alice and Bob than Alice and Bob share after error correction, making secure key distillation mathematically impossible.`,
  },
];

export interface QuizQuestion {
  id: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  topic: string;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export const QUIZ_BANK: QuizQuestion[] = [
  {
    id: 1,
    difficulty: 'beginner',
    topic: 'Classical vs Quantum',
    question: 'What fundamental property of quantum physics gives QKD an advantage over classical schemes like RSA?',
    options: [
      'Quantum computers calculate algorithms faster.',
      'Quantum states cannot be copied without disturbance (No-Cloning Theorem).',
      'Photons travel faster than classical signals.',
      'Qubits carry infinite storage capacity.',
    ],
    correct: 1,
    explanation: 'The No-Cloning Theorem states that unknown quantum states cannot be duplicated. Any measurement attempts disturb the state, leaving detectable errors.',
  },
  {
    id: 2,
    difficulty: 'beginner',
    topic: 'Sifted Key Length',
    question: 'In a clean channel with perfect equipment, what fraction of sent photons survive the sifting phase?',
    options: ['About 10%', 'About 25%', 'About 50%', '100% of them'],
    correct: 2,
    explanation: 'Alice and Bob each independently select bases randomly. Because there are 2 bases, they agree 50% of the time, discarding the other 50%.',
  },
  {
    id: 3,
    difficulty: 'beginner',
    topic: 'Public Basis Announcement',
    question: 'Why does publicly announcing measurement bases over an open channel not reveal the secret key to Eve?',
    options: [
      'The public channel is encrypted.',
      'They announce only which bases were used (+ or ×), never the measured bit values (0 or 1).',
      'Eve has already finished listening.',
      'The bases are sent backwards in time.',
    ],
    correct: 1,
    explanation: 'Announcing a basis reveals how a photon was measured, not which state was detected. For example, + basis could mean |H⟩ (bit 0) or |V⟩ (bit 1). The bit remains secret.',
  },
  {
    id: 4,
    difficulty: 'intermediate',
    topic: 'Eavesdropping Error Rate',
    question: 'If Eve intercepts 100% of photons using an intercept-resend attack on a noiseless channel, what is the expected QBER?',
    options: ['0.00%', '11.00%', '25.00%', '50.00%'],
    correct: 2,
    explanation: 'Eve chooses the wrong basis 50% of the time. When Alice and Bob agree on basis, Bob has a 50% chance of a bit error on those corrupted photons: 0.5 × 0.5 = 0.25 (25%).',
  },
  {
    id: 5,
    difficulty: 'intermediate',
    topic: 'Shor-Preskill Bound',
    question: 'What is the theoretical maximum QBER threshold above which BB84 must abort because privacy amplification fails?',
    options: ['5.00%', '11.00%', '25.00%', '50.00%'],
    correct: 1,
    explanation: 'The Shor-Preskill bound is approximately 11%. Above this rate, Eve’s potential information exceeds the mutual information between Alice and Bob.',
  },
  {
    id: 6,
    difficulty: 'advanced',
    topic: 'Decoy State Modulation',
    question: 'Why are weak coherent laser pulses augmented with decoy states in practical QKD testbeds?',
    options: [
      'To increase laser pulse velocity through air.',
      'To detect and defend against Photon Number Splitting (PNS) attacks on multi-photon pulses.',
      'To eliminate the need for Bob to have single-photon detectors.',
      'To convert rectilinear polarization to diagonal polarization automatically.',
    ],
    correct: 1,
    explanation: 'Real diode lasers emit Poissonian pulses where multi-photon pulses allow Eve to keep a photon without disturbing the other. Decoy-state modulation varies pulse intensity (μ, ν, ω) to bound multi-photon yield.',
  },
];

export const EVALUATION_QUESTIONS = [
  {
    id: 1,
    topic: 'BB84 Protocol',
    question: 'In the standard BB84 protocol, how many photon polarization states does Alice use to encode bits?',
    options: ['2 states (0°, 90°)', '4 states (0°, 90°, 45°, 135°)', '8 states', 'Unlimited continuous states'],
    answer: 1,
    explanation: 'Alice uses two conjugate bases (Rectilinear + and Diagonal ×), totaling 4 polarization states (0°, 90°, 45°, 135°).',
  },
  {
    id: 2,
    topic: 'Quantum Security',
    question: 'What fundamental principle prevents an eavesdropper from secretly copying quantum states?',
    options: ['Heisenberg Uncertainty Principle', 'No-Cloning Theorem', 'Quantum Entanglement', "Shor's Algorithm"],
    answer: 1,
    explanation: 'The No-Cloning Theorem proves that an arbitrary unknown quantum state cannot be duplicated perfectly.',
  },
  {
    id: 3,
    topic: 'Intercept-Resend Footprint',
    question: 'In intercept-resend eavesdropping on an ideal noiseless channel, what is Eve’s expected error contribution to the sifted key?',
    options: ['0%', '12.5%', '25%', '50%'],
    answer: 2,
    explanation: 'Eve chooses the wrong basis 50% of the time, causing Bob to detect a bit flip 50% of those times, yielding an overall 25% QBER.',
  },
  {
    id: 4,
    topic: 'Security Threshold',
    question: 'Under Shor–Preskill security proofs, what is the maximum allowable QBER for distilling a secure key?',
    options: ['4.5%', '11.0%', '25.0%', '33.3%'],
    answer: 1,
    explanation: 'The Shor–Preskill security bound is ~11%. Above this, private key distillation is impossible.',
  },
];

export const PERSONAS = [
  {
    role: 'Undergraduate Student',
    domain: 'Computer Science & Physics',
    needs: 'Needs visual, tangible insight into why eavesdropping leaves an undeniable physical trace without complex linear algebra.',
    quote: '"Seeing Eve’s wrong-basis measurement collapse the photon and watching the QBER spike to 25% made the concept click immediately."',
  },
  {
    role: 'Graduate Researcher',
    domain: 'Quantum Cryptography',
    needs: 'Requires rigorous parameter sweeps, Shor–Preskill threshold validations, and decoy-state analysis.',
    quote: '"The ability to run vectorised 1000-photon batches and plot theoretical QBER = p/4 against live simulation is great for quick sanity checks."',
  },
  {
    role: 'Cybersecurity Engineer',
    domain: 'Enterprise Security Architecture',
    needs: 'Transitioning from RSA/ECC to Post-Quantum Cryptography (PQC) and QKD hardware integration.',
    quote: '"It clarifies the exact boundary where physical hardware security ends and classical privacy amplification begins."',
  },
  {
    role: 'Educator & Professor',
    domain: 'Higher Education Instruction',
    needs: 'Needs a zero-friction, browser-based lab with classroom presets and student learning gain metrics.',
    quote: '"The pre/post assessment and live single-photon walkthrough allow my students to master BB84 in a single 50-minute lab session."',
  },
];

export const ROADMAP_PHASES = [
  {
    phase: 'Phase 1: Interactive Foundation',
    status: 'Completed',
    milestones: [
      'Pure-browser vectorized BB84 simulation engine',
      'Real-time sifting, QBER calculation, and ledger view',
      'Single-photon 5-step polarization walkthrough',
    ],
  },
  {
    phase: 'Phase 2: Mathematical Rigour',
    status: 'Completed',
    milestones: [
      'Closed-form QBER = p/4 parameter sweep verification',
      'Shor–Preskill 11% security threshold validation',
      'Adaptive quiz bank with level progression and hints',
    ],
  },
  {
    phase: 'Phase 3: Hardware Testbed Emulation',
    status: 'Completed',
    milestones: [
      'Tabletop optical testbench with laser diode modules, polarizers, NPBS cubes, and SPADs',
      'Free-space optical link and decoy-state AM/PM modulation emulation',
      'Full integration of WISER Education Challenge with 3D testbench',
    ],
  },
  {
    phase: 'Phase 4: Global Classroom & PQC',
    status: 'In Progress',
    milestones: [
      'Multi-protocol support: E91 entanglement and B92 protocol',
      'Post-Quantum Hybrid (QKD + Kyber/ML-KEM) key exchange pipeline',
      'Multi-language global localization (EN, ES, FR, DE, ZH, HI)',
    ],
  },
];
