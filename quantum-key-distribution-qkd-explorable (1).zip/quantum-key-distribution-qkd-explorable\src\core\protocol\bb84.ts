import { Vector2 } from '../math/vector2';
import { SeededRNG } from '../rng';
import { EveAttacks, Basis, Bit } from '../attacks/eve';

export interface PulseRecord {
  id: number;
  aliceBit: Bit;
  aliceBasis: Basis;
  encodedState: Vector2;
  eveIntercepted: boolean;
  eveBasis?: Basis;
  eveBit?: Bit;
  bobBasis: Basis;
  bobDetected: boolean;
  bobBit?: Bit;
  basesMatch: boolean;
  isSifted: boolean;
  isError: boolean;
}

export interface BB84SimulationResult {
  pulses: PulseRecord[];
  totalSent: number;
  totalDetected: number;
  siftedBits: number;
  errorCount: number;
  qber: number; // Quantum Bit Error Rate (0.0 to 1.0)
  aborted: boolean;
  abortThreshold: number;
  correctedKeyLength: number;
  secretKeyLength: number;
  aliceRawBits: Bit[];
  bobRawBits: Bit[];
  aliceSiftedBits: Bit[];
  bobSiftedBits: Bit[];
  finalSecretKey: string;
}

export interface BB84Params {
  pulseCount: number;
  eveInterceptRate: number; // 0.0 (no Eve) to 1.0 (full intercept-resend)
  channelLossDb: number;    // e.g. 0 to 40 dB
  detectorEfficiency: number; // e.g. 0.65
  darkCountRate: number;    // e.g. 1e-4
  abortThreshold: number;   // e.g. 0.11 (11% Shor-Preskill security bound)
  seed?: number;
}

export class BB84Engine {
  /**
   * Encodes a bit and basis into the corresponding quantum polarization state.
   */
  static encode(bit: Bit, basis: Basis): Vector2 {
    if (basis === 'Z') {
      return bit === 0 ? Vector2.H : Vector2.V;
    } else {
      return bit === 0 ? Vector2.D : Vector2.A;
    }
  }

  /**
   * Simulates Bob's measurement of an incoming state in his chosen basis.
   */
  static measure(state: Vector2, basis: Basis, rng: SeededRNG): Bit {
    if (basis === 'Z') {
      const probH = state.probabilityOf(Vector2.H);
      return rng.next() < probH ? 0 : 1;
    } else {
      const probD = state.probabilityOf(Vector2.D);
      return rng.next() < probD ? 0 : 1;
    }
  }

  /**
   * Runs a complete BB84 protocol simulation round.
   */
  static runSimulation(params: BB84Params): BB84SimulationResult {
    const rng = new SeededRNG(params.seed ?? 1337);
    const pulses: PulseRecord[] = [];
    const channelTransmittance = Math.pow(10, -params.channelLossDb / 10);

    const aliceSiftedBits: Bit[] = [];
    const bobSiftedBits: Bit[] = [];
    let errorCount = 0;

    for (let i = 0; i < params.pulseCount; i++) {
      // 1. Alice picks random bit and basis
      const aliceBit: Bit = rng.nextBit();
      const aliceBasis: Basis = rng.nextBool() ? 'Z' : 'X';
      const encodedState = BB84Engine.encode(aliceBit, aliceBasis);

      // 2. Eve attack in transit
      let transmittedState = encodedState;
      let eveIntercepted = false;
      let eveBasis: Basis | undefined;
      let eveBit: Bit | undefined;

      if (params.eveInterceptRate > 0) {
        const attack = EveAttacks.interceptResend(encodedState, params.eveInterceptRate, rng);
        if (attack.intercepted) {
          eveIntercepted = true;
          eveBasis = attack.eveBasis;
          eveBit = attack.eveMeasuredBit;
          transmittedState = attack.transmittedState;
        }
      }

      // 3. Channel Transmission & Bob Detection
      // Loss check: does photon arrive at Bob's detector?
      const photonArrived = rng.next() < (channelTransmittance * params.detectorEfficiency);
      const darkCount = rng.next() < params.darkCountRate;
      const bobDetected = photonArrived || darkCount;

      // 4. Bob chooses basis and measures
      const bobBasis: Basis = rng.nextBool() ? 'Z' : 'X';
      let bobBit: Bit | undefined;

      if (bobDetected) {
        if (photonArrived) {
          bobBit = BB84Engine.measure(transmittedState, bobBasis, rng);
        } else {
          // Pure dark count gives random bit
          bobBit = rng.nextBit();
        }
      }

      // 5. Sifting: Bases match?
      const basesMatch = aliceBasis === bobBasis;
      const isSifted = bobDetected && basesMatch && bobBit !== undefined;
      let isError = false;

      if (isSifted && bobBit !== undefined) {
        aliceSiftedBits.push(aliceBit);
        bobSiftedBits.push(bobBit);
        if (aliceBit !== bobBit) {
          isError = true;
          errorCount++;
        }
      }

      pulses.push({
        id: i + 1,
        aliceBit,
        aliceBasis,
        encodedState,
        eveIntercepted,
        eveBasis,
        eveBit,
        bobBasis,
        bobDetected,
        bobBit,
        basesMatch,
        isSifted,
        isError,
      });
    }

    const siftedBits = aliceSiftedBits.length;
    const qber = siftedBits > 0 ? errorCount / siftedBits : 0;
    const aborted = qber > params.abortThreshold && siftedBits >= 10;

    // Post-processing simulation:
    // Error correction parity leakage ~ f * h(QBER) where f ≈ 1.15
    const h = (p: number) => {
      if (p <= 0 || p >= 1) return 0;
      return -p * Math.log2(p) - (1 - p) * Math.log2(1 - p);
    };

    const ecLeakageFraction = Math.min(1.0, 1.15 * h(qber));
    const correctedBits = Math.floor(siftedBits * (1 - ecLeakageFraction));

    // Privacy amplification shrinks key to remove Eve's potential Rényi entropy / information
    const paShrinkFraction = Math.min(1.0, 2.0 * h(qber));
    const secretKeyLength = aborted ? 0 : Math.max(0, Math.floor(correctedBits * (1 - paShrinkFraction)));

    // Generate final secret key hex string from matched bits
    let finalSecretKey = '';
    if (!aborted && secretKeyLength > 0) {
      const bitsToUse = aliceSiftedBits.slice(0, secretKeyLength);
      let hexAcc = 0;
      for (let j = 0; j < bitsToUse.length; j++) {
        hexAcc = (hexAcc << 1) | bitsToUse[j];
        if ((j + 1) % 4 === 0 || j === bitsToUse.length - 1) {
          finalSecretKey += hexAcc.toString(16).toUpperCase();
          hexAcc = 0;
        }
      }
    }

    return {
      pulses,
      totalSent: params.pulseCount,
      totalDetected: pulses.filter((p) => p.bobDetected).length,
      siftedBits,
      errorCount,
      qber,
      aborted,
      abortThreshold: params.abortThreshold,
      correctedKeyLength: Math.max(0, correctedBits),
      secretKeyLength,
      aliceRawBits: pulses.map((p) => p.aliceBit),
      bobRawBits: pulses.filter((p) => p.bobDetected).map((p) => p.bobBit!),
      aliceSiftedBits,
      bobSiftedBits,
      finalSecretKey,
    };
  }
}
